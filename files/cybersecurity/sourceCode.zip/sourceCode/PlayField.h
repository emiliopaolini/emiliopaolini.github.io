//
// Created by emilio on 20/06/20.
//

#include <sys/types.h>

#ifndef CYBERSECPROJECT_PLAYFIELD_H
#define CYBERSECPROJECT_PLAYFIELD_H

#define playerSymbol1 'X'
#define playerSymbol2 'O'
#define NROWS 6
#define NCOLUMNS 7

class PlayField {
private:

    char playField[NROWS][NCOLUMNS];


    bool isColumnFull(int column);
    //return true if game is over, false otherwise
    bool checkField(int row, int column,char playerSymbol);
public:
    bool playing;
    PlayField();
    void print();

    //return -1 in case of not valid column, 0 in case of valid, 1 if the game is over
    int insertToken(int column,char playerSymbol);
};

#endif