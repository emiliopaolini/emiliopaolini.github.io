//
// Created by baccios on 09/04/20.
//

#include "FourRowClient.h"
#include <string>
#include <iostream>
#include <map>
#include <unistd.h>

using namespace std;

FourRowClient::FourRowClient(const char* username, const char *servAddr, uint16_t servPort) {
    /*Assume parameters are already sanitized*/
    strcpy(this->serverAddress, servAddr);
    strcpy(this->username, username);
    this->serverPort = servPort;
    this->status = WAITING_INIT;
    launch();
}

void FourRowClient::launch() {

    sockaddr_in sv_addr;
    /* Socket creation */
    this->servSock = socket(AF_INET, SOCK_STREAM, 0);

    /* Creating socket address */
    memset(&sv_addr, 0, sizeof(sv_addr));
    sv_addr.sin_family= AF_INET;
    sv_addr.sin_port= htons(this->serverPort);
    inet_pton(AF_INET, this->serverAddress, &sv_addr.sin_addr);

    //Connect to the server
    int ret = connect(this->servSock, (sockaddr*)&sv_addr, sizeof(sv_addr));
    if(ret != 0) {
        cerr<<"Couldn't connect with the server. Closing..."<<endl;
        exit(-1);
    }

    //From now on the client is connected with the server

    //send its own username to the server to authenticate //TODO: merge this in secure authentication
    int messageLen = strlen(this->username) + 1;
    ret = send(this->servSock, (const void*) this->username, messageLen, 0);
    if(ret < messageLen) {
        cerr<<"The user couldn't authenticate due to socket errors"<<endl;
    }

    //TODO: authentication [SECURITY]

    //TODO: session key establishment [SECURITY]


   do {}
   while(testStatusAndHandle() != -1);


}


int FourRowClient::waitOrChallenge() {
    cout<<"Do you want to challenge a user or just wait to be challenged?"<<endl;
    cout<<"type 0 to wait, 1 to challenge someone, 2 to log off from the server"<<endl;
    int decision;
    bool goodDecision = false;
    while(!goodDecision)
    {
        cin >> decision;
        if ((decision != 0 && decision != 1 && decision!=2) || cin.fail()) {
            cout << "Please type a valid number"<<endl;
        }
        else {
            goodDecision = true;
        }
    }
    if(decision == 2) decision = -1;
    return decision;
}


//returns the index of the user to be challenged
int FourRowClient::showAndPromptUsers() {

    if(activeUsersSize == 1) {
        cout<<"There are no other active users at the moment. Please try later"<<endl;
        return -1;
    }

    for(int i = 0; i<activeUsersSize; ++i) {
        cout<<i+1<<") "<<activeUsers[i]<<endl;
    }
    cout<<"Type the user you want to challenge and press Enter > ";
    char input[USERNAME_MAXSIZE];
    cin.ignore(); //ignore last \n character
    while(true) {
        cin.getline(input, USERNAME_MAXSIZE);
        for(int i = 0; i<activeUsersSize; ++i) {
            if(strcmp(input, this->username) == 0) { //user typed his own name
                break;
            }
            else if(strcmp(activeUsers[i], input) == 0) {
                cout<<"Challenging "<<input<<endl;
                return i;
            }
            //p2p connection established
        }
        cout<<"The username you typed wasn't correct, please try again"<<endl;
    }
    return -1;
}

//returns -1 in case of error
int FourRowClient::challenge(const char *username) {
    char message[USERNAME_MAXSIZE + 10]; //10 == strlen("challenge ")
    strcpy(message, "challenge ");
    strcat(message, username);

    int messageLen = strlen(message) + 1;
    int ret = send(this->servSock, (const void*) message, messageLen, 0);
    if(ret < messageLen) {
        cerr<<"couldn't send the challenge properly. Aborting...";
        return -1;
    }
    return 0;
}

int FourRowClient::challengeReceived(const char *username){
    cout<<"You receive a challenge from "<<username<<endl;
    cout<<"Type 1 to accept, 0 otherwise"<<endl;
    int response;
    bool goodDecision = false;
    while(!goodDecision)
    {
        cin >> response;
        if ((response != 0 && response != 1 ) || cin.fail()) {
            cout << "Please type a valid number"<<endl;
        }
        else {
            goodDecision = true;
        }
    }
    return response;
}

int FourRowClient::sendStatus(int decision){
    char status[12];
    if(decision == 0) {
        strcpy(status, "waiting");
    }
    else if (decision == 1) {
        strcpy(status,"challenging");
    }
    else {
        strcpy(status,"quit");
    }

    int statusLen = strlen(status) + 1;
    int ret = send(this->servSock, (const void*) status, statusLen, 0);
    if(ret < statusLen) {
        cerr<<"couldn't send the status properly. Aborting...";
        close(this->servSock);
        return -1;
    }
    return 0;
}


int FourRowClient::testStatusAndHandle() {

    int ret;

    switch(this->status) {
        case WAITING_INIT:
            ret = handleWAITING_INIT();
            break;
        case TO_BE_ASKED:
            ret = handleTO_BE_ASKED();
            break;
        case WAITING:
            ret = handleWAITING();
            break;
        case CHALLENGED:
            ret = handleCHALLENGED();
            break;
        case CHALLENGING:
            ret = handleCHALLENGING();
            break;
        case WAITING_RESPONSE:
            ret = handleWAITING_RESPONSE();
            break;
        case RESPONSE_ARRIVED:
            ret = handleRESPONSE_ARRIVED();
            break;
        case WAITING_FOR_P2P_ADDRESS:
            ret = handleWAITING_FOR_P2P_ADDRESS();
            break;
        case READY_TO_PLAY:
            ret = handleREADY_TO_PLAY();
            break;
        case PLAYING:
            ret = handlePLAYING();
            break;
        case GAME_OVER:
            ret = handleGAME_OVER();
            break;
        case QUITTING:
            cout<<"Quitting the application"<<endl;
            close(this->servSock);
            ret = -1;
            break;
        default:
            ret = -1;
            break;
    }

    return ret;
}

int FourRowClient::handleWAITING_INIT() {
    if(!waitForInitialize())
        this->status = QUITTING;
    else
        this->status = TO_BE_ASKED;

    return 1;
}

int FourRowClient::handleTO_BE_ASKED() {
    int ret;

    //ask user what he/she wants to do
    int decision = waitOrChallenge();

    //tell the server the decision outcome ("waiting, "challenging" or "quit");
    sendStatus(decision);

    //update the user status
    this->status = (decision == 0) ? WAITING : (decision == 1) ? CHALLENGING : QUITTING;

    return 1;

}

int FourRowClient::handleCHALLENGING() {

    //receive from server list of active users
    char buffer[MAX_USERS_TO_SEND * USERNAME_MAXSIZE];
    int len = MAX_USERS_TO_SEND * USERNAME_MAXSIZE;
    int ret = recv(this->servSock, (void*)buffer, len, 0);

    if(ret <= 0 || (ret % USERNAME_MAXSIZE != 0)) {
        cerr<<"error while reading or socket has been closed. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }
    this->activeUsersSize = ret / USERNAME_MAXSIZE;
    for(int i = 0; i<this->activeUsersSize; ++i) {
        strcpy(this->activeUsers[i], buffer + i*USERNAME_MAXSIZE);
    }

    //Send a challenge request to the server. Format: "challenge $username"
    int challengedUser = showAndPromptUsers();
    if (challengedUser == -1) {
        this->status = QUITTING;
        return 1;
    }

    //here the user is challenging another user: "challenge $username"
    ret = challenge(activeUsers[challengedUser]);

    if (ret == -1) {
        //error during challenge
        this->status = QUITTING;
        return 1;
    }

    this->status = WAITING_RESPONSE;

    return 1;

}

int FourRowClient::handleWAITING_RESPONSE() {
    int ret;

    cout<<"Waiting for a response by the challenged user..."<<endl;

    //waiting for the response to the challenge just sent
    char responseToSentChallenge[11];//ok->challenge accepted, ko-> challenge refused, initialize-> opponent is now offline
    int responseToSentChallengeLen = 11;

    ret = recv(this->servSock, (void *) responseToSentChallenge, responseToSentChallengeLen, 0);

    if (ret <= 1) {
        cerr << "error while receiving a response for the sent challenge. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    if(isInitializeMsg(responseToSentChallenge)) {
        cout<<"The user you challenged is now offline and cannot be challenged."<<endl;
        this->status = TO_BE_ASKED;
        return 1;
    }


    if (strcmp("ok", responseToSentChallenge) == 0) {
        this->status = RESPONSE_ARRIVED;
        return 1;
    }

    else if (strcmp("ko", responseToSentChallenge) == 0) {
        //challenge refused
        cout<<"The opponent refused your challenge."<<endl;
        this->status = WAITING_INIT;
        return 1;
    }

    else if (strcmp("error", responseToSentChallenge) == 0) {
        cout<< "The user that you want to challenge cannot receive challenges at the moment"<< endl;
        cout << "Try to challenge another user" << endl;
        this->status = WAITING_INIT;
        return 1;
    }

    //format error
    cerr << "wrong result message format. Aborting..." << endl;
    this->status = QUITTING;
    return 1;



}

int FourRowClient::handleRESPONSE_ARRIVED() {

    cout<<"The challenge has been accepted! Communicating our address to the opponent..."<<endl;

    //response arrived and challenge was accepted
    //preparing a new structure for p2p communication
    //and sending this structure to the server
    int p2pSocket = socket(AF_INET, SOCK_STREAM, 0);
    char address[16];
    uint16_t port = 0;
    sockaddr_in addrP2p;
    strcpy(address,"127.0.0.1");
    memset(&addrP2p, 0, sizeof(addrP2p));
    addrP2p.sin_family = AF_INET;
    addrP2p.sin_port = htons(port);
    inet_pton(AF_INET, address, &addrP2p.sin_addr);

    int ret = bind(p2pSocket, (sockaddr * ) & addrP2p, sizeof(addrP2p));
    if (ret != 0) {
        cerr << "Couldn't bind p2p socket. Closing..." << endl;
        this->status = QUITTING;
        return 1;

    }
    /*Setting the socket in listening mode for connections*/
    ret = listen(p2pSocket, 10);
    if (ret != 0) {
        cerr << "Couldn't set the socket in listening mode. Closing..." << endl;
        this->status = QUITTING;
        return 1;
    }

    //set the address with the assigned port
    socklen_t len = sizeof(addrP2p);
    if (getsockname(p2pSocket, (struct sockaddr *)&addrP2p, &len) == -1) {
        cerr<<"Error retrieving the listening address. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    ret = send(this->servSock, (const void *) &addrP2p, sizeof(addrP2p), 0);
    if (ret < sizeof(addrP2p)) {
        cerr << "Error in sending the addrP2p. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    this->status = READY_TO_PLAY;
    this->listeningSock = p2pSocket;
    return 1;

}

int FourRowClient::handleREADY_TO_PLAY() {

    //accept connection from the other peer on the listening socket
    sockaddr_in opponent_addr;
    int opponent_addr_len = sizeof(opponent_addr);
    cout<<"Waiting for the opponent..."<<endl;
    int new_sock = accept(this->listeningSock, (sockaddr *) &opponent_addr, (socklen_t*)&opponent_addr_len);
    if (new_sock == -1) {
        cerr << "A problem occurred while accepting a connection from the opponent. Closing..." << endl;
        this->status = QUITTING;
        return 1;
    }
    this->gameSocket = new_sock;

    //TODO: authenticate user [SECURITY]

    this->isChallenger = true;
    this->status = PLAYING;
    return 1;
}

int FourRowClient::handleWAITING() {
    int ret;

    //user is waiting for a challenge
    char challengeBuffer[13 + USERNAME_MAXSIZE]; // The longest string possible is "challengedBy $username"
    int challengeLen = 13 + USERNAME_MAXSIZE;
    //At this point we wait for a challenge

    ret = recv(this->servSock, (void *) challengeBuffer, challengeLen, 0);
    if (ret <= 0) {
        cerr << "error while waiting for a challenge. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    //use strings to have useful methods
    string challengeMsg(challengeBuffer);

    //cout<<"challenge msg: "<<challengeBuffer<<endl; //DEBUG
    string delimiter = " ";
    string opcode = challengeMsg.substr(0, challengeMsg.find(delimiter));
    //cout<<"opcode: "<<opcode<<endl; //DEBUG
    if (opcode.compare("challengedBy") != 0) {
        cerr << "wrong format of challengedBy. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }
    string otherUser = challengeMsg.substr(challengeMsg.find(delimiter) + 1, challengeMsg.length());


    if (otherUser == "" || otherUser.length() >= USERNAME_MAXSIZE) { //format error
        cerr << "server did not send a correct challenge format" << endl;
        this->status = QUITTING;
        return 1;
    }

    this->status = CHALLENGED;
    strcpy(this->opponent, otherUser.c_str());
    return 1;
}

int FourRowClient::handleCHALLENGED() {

    //challenge received, ask the user if he wants to accept it or not
    int challengeAccepted = challengeReceived(this->opponent); //ask user how to respond to the challenge

    //creating the message response for the challenge
    char response[7 + USERNAME_MAXSIZE]; //"accept $username" or "refuse $username"
    int responseLen;
    if (challengeAccepted == 1) {
        strcpy(response, "accept ");
    } else {
        strcpy(response, "refuse ");
    }
    strcat(response, this->opponent);
    responseLen = strlen(response) + 1;
    //sending the response
    int ret = send(this->servSock, (const void *) response, responseLen, 0);
    if (ret < responseLen) {
        cerr << "Error in sending the response. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    if (challengeAccepted == 1) {
        this->status = WAITING_FOR_P2P_ADDRESS;
    }
    else {
        this->status = WAITING_INIT;
    }
    return 1;

}

int FourRowClient::handleWAITING_FOR_P2P_ADDRESS() {
    int ret;

    //waiting for the message containing the listening address for p2p communication
    sockaddr_in playerAddress;
    int len = sizeof(playerAddress); //"initialize" is always shorter than sizeof(sockaddr_in)

    ret = recv(this->servSock, (void *) &playerAddress, len, 0);

    //check if an initialize message arrived
    if(ret == strlen("initialize") + 1) {
        if (isInitializeMsg((const char *) &playerAddress)) {
            this->status = TO_BE_ASKED;
            return 1;
        }
    }

    if (ret < len) {
        cerr << "error while receiving the other player address. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    /* Socket creation */
    this->gameSocket = socket(AF_INET, SOCK_STREAM, 0);

    //Connect to the server
    ret = connect(this->gameSocket, (sockaddr*)&playerAddress, sizeof(playerAddress));
    if(ret != 0) {
        cerr<<"Couldn't connect with the opponent. Closing..."<<endl;
        this->status = GAME_OVER;
        return 1;
    }

    //TODO: authenticate user [SECURITY]

    this->isChallenger = false;
    this->status = PLAYING;
    return 1;

}

int FourRowClient::handlePLAYING() {
    field = new PlayField();
    //TODO: play
    int i = 0;
    if(isChallenger) {
        cout<<"Hello, I am the challenger and I am playing!"<<endl;
        while(field->playing) {
            //challenging Player -> waits for the first move of the adversary
            field->print();
            int res;
            cout << "Waiting for the move of the adversary...." << endl;
            res = receiveMove();
            if (res < 0) {
                cerr << "received an invalid column. Aborting..." << endl;
                close(gameSocket);
                return -1;
            } else {
                if (res == 0) {
                    //keep playing
                    field->print();
                    res = sendMove();
                    if (res < 0) {
                        cerr << "error in sending the column. Aborting..." << endl;
                        close(gameSocket);
                        return -1;
                    }
                }
            }
        }
    }else{
        cout<<"Hello, I am the challenged user and I am playing!"<<endl;
        while(field->playing) {
            field->print();
            //the waiting player starts the game
            int res;
            res = sendMove();
            if (res < 0) {
                cerr << "error in sending the column. Aborting..." << endl;
                close(gameSocket);
                return -1;
            } else {
                if (res == 0) {
                    if (field->playing) {
                        //keep playing
                        field->print();
                        cout << "Waiting for the move of the adversary...." << endl;
                        int result = receiveMove();
                        if (result < 0) {
                            cerr << "error in receivings..." << endl;
                            close(gameSocket);
                            return -1;
                        }
                    }
                }
            }
        }
    }
    field->print();
    delete field;
    this->status = GAME_OVER;
    return 1;

}

int FourRowClient::checkInputColumn(){
    int column;
    cout<<"In quale colonna vuoi inserire il gettone?"<<endl;
    bool goodDecision = false;
    while(!goodDecision) {
        cin >> column;
        if (field->insertToken(column, playerSymbol1) >= 0){
            goodDecision = true;
        }
    }
    return column;

}

int FourRowClient::sendMove(){
    int column = checkInputColumn();

    char columnMessage[10];//10==strlen(column: $column)+1
    strcpy(columnMessage, "column: ");
    strcat(columnMessage, to_string(column).c_str());

    int columnMessageLength = strlen(columnMessage) + 1;
    int ret = send(gameSocket, (const void*) columnMessage, columnMessageLength, 0);
    if (ret < columnMessageLength) {
        cerr << "Error in sending the column Message. Aborting..." << endl;
        close(gameSocket);
        return -1;
    }
    return 0;
}

int FourRowClient::receiveMove(){
    char columnMessage[10]; // The longest string possible is "column: $column"
    int columnMessageLength = 10;
    int ret = recv(gameSocket, (void *) columnMessage, columnMessageLength, MSG_WAITALL);
    if (ret < columnMessageLength) {
        cerr << "error while receiving the move from the adversary for a challenge. Aborting..." << endl;
        close(gameSocket);
        return -1;
    }
    string columnMsg(columnMessage);
    cout<<"column Msg: "<<columnMessage<<endl;//DEBUG
    string delimiter = " ";
    string firstWord = columnMsg.substr(0,columnMsg.find(delimiter));
    if(firstWord.compare("column:")!=0){
        cerr<<"wrong column message format. Aborting connection..."<<endl;
        close(gameSocket);
        return -1;
    }
    int column = stoi(columnMsg.substr(columnMsg.find(delimiter)+1, columnMsg.size()));
    return field->insertToken(column, playerSymbol2);
}


int FourRowClient::handleGAME_OVER() {

    //close all p2p connections
    if(isChallenger) {
        close(listeningSock);
    }
    close(gameSocket);

    //the game is over and server must be notified
    const char* gameOverMsg = "game over";
    int len = strlen(gameOverMsg) + 1;
    int ret = send(this->servSock, (const void*)gameOverMsg, len, 0);

    if(ret < len) {
        cerr<<"couldn't send game over message to the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    this->status = WAITING_INIT; //server always sends an init message after a game ends
    return 1;

}


bool FourRowClient::isInitializeMsg(const char* msg) {
    return (strcmp(msg, "initialize") == 0);
}

bool FourRowClient::waitForInitialize() {
    char initMsg[11];
    int  initLen = 11;
    int ret = recv(this->servSock, (void*)initMsg, initLen, 0);
    if(ret < 11)
        return false;
    if(!strcmp("initialize", initMsg))
        return true;
    return false;
}




























