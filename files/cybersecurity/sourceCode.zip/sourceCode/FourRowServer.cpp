//
// Created by baccios on 20/06/20.
//
#include <cstring>
#include <iostream>
#include <thread>
#include "FourRowServer.h"

FourRowServer::FourRowServer(const char *addr, uint16_t port, const char *userFileName) {
    /*assumes not tainted parameters. (parameters are sanitized in main function)*/
    strcpy(this->address, addr);
    this->port = port;
    this->users = loadUsers(userFileName);
    launch();
}

/*Put the server online and listening for connections*/
void FourRowServer::launch() {
    /*Socket creation*/
    this->listeningSocket = socket(AF_INET, SOCK_STREAM, 0);
    int option = 1;
    setsockopt(this->listeningSocket, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));


    /*Address structure creation*/
    sockaddr_in my_addr;
    memset(&my_addr, 0, sizeof(my_addr) );
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(this->port);
    inet_pton(AF_INET, this->address, &my_addr.sin_addr);

    /*Binding listeningSocket to its address*/
    int ret = bind(this->listeningSocket, (sockaddr*)&my_addr, sizeof(my_addr));
    if(ret != 0) {
        cerr<<"Couldn't bind listening socket. Closing..."<<endl;
        exit(-1);
    }
    /*Setting the socket in listening mode for connections*/
    ret = listen(this->listeningSocket, 10);
    if(ret != 0) {
        cerr<<"Couldn't set the socket in listening mode. Closing..."<<endl;
        exit(-1);
    }


    while(1) {
        sockaddr_in cl_addr;
        int cl_addr_len = sizeof(cl_addr);
        cout<<"Server is opening a new listener for connections"<<endl;
        int new_sock = accept(this->listeningSocket, (sockaddr *) &cl_addr, (socklen_t*)&cl_addr_len);
        if (new_sock == -1) {
            cerr << "A problem occurred while accepting a new connection. Closing..." << endl;
            exit(-1);
        }

        //create a new thread to handle the new connection

        thread handler (&FourRowServer::handleConnection, this, new_sock, cl_addr);
        handler.detach();
    }
}

void FourRowServer::loadPublicKey(const char* username){
    string fileName(username);
    fileName = "./" + fileName + ".pem";

    //FILE* file = fopen(fileName.c_str());
}

void FourRowServer::handleConnection(int dataSocket, sockaddr_in cl_addr) {

    user* currentUser = NULL; //initialized after authentication

    //receive the client's username //TODO: merge this in secure authentication
    char username[USERNAME_MAXSIZE];
    int ret = recv(dataSocket, (void*)username, USERNAME_MAXSIZE, 0); //can be done in non thread safe mode since user isn't visible to other threads
    if(ret<=0){
        cerr<<"error while receiving the username. Aborting connection..."<<endl;
        close(dataSocket);
        return;
    }
    cout<<"username: "<<username<<endl;
    //TODO: authentication [SECURITY]
    loadPublicKey(username);


    //Update active users list
    for (vector<user>::iterator it = this->users->begin() ; it != this->users->end(); ++it) {

        if(!strcmp(it->username, username)) { //if user correspond

            //Fill socket and mutex of the active client
            it->socket = dataSocket;
            it->statusMutex = new mutex;
            it->statusCV = new condition_variable;
            it->status = TO_BE_ASKED; //default value, to avoid challenges received at this time

            activeUsersMutex.lock();
            this->activeUsers.insert(pair<string, user*> (it->username, &(*it)));
            activeUsersMutex.unlock();

            currentUser = &(*it); //save the user for future reference
        }
    }

    //TODO: session key establishment [SECURITY]


    do {}
    while(testStatusAndHandle(currentUser, cl_addr) != -1);

}

int FourRowServer::testStatusAndHandle(user* currentUser, sockaddr_in& cl_addr) {

    unique_lock<mutex> lock(*currentUser->statusMutex);
    int ret;

    switch(currentUser->status) {

        case TO_BE_ASKED:
            ret = handleTO_BE_ASKED(currentUser);
            break;
        case WAITING:
            ret = handleWAITING(currentUser, lock);
            break;
        case CHALLENGED:
            ret = handleCHALLENGED(currentUser);
            break;
        case CHALLENGING:
            ret = handleCHALLENGING(currentUser);
            break;
        case WAITING_RESPONSE:
            ret = handleWAITING_RESPONSE(currentUser, lock);
            break;
        case RESPONSE_ARRIVED:
            ret = handleRESPONSE_ARRIVED(currentUser);
            break;
        case WAITING_FOR_P2P_ADDRESS:
            ret = handleWAITING_FOR_P2P_ADDRESS(currentUser, lock);
            break;
        case READY_TO_PLAY:
            ret = handleREADY_TO_PLAY(currentUser);
            break;
        case PLAYING:
            ret = handlePLAYING(currentUser);
            break;
        default:
            ret = -1;
            break;
    }

    lock.unlock();
    return ret;
}

int FourRowServer::handleTO_BE_ASKED(user* currentUser) {

    int ret;

    cout<<"sending to "<<currentUser->username<<" the initialization message..."<<endl; //DEBUG
    //protocol initialization (useful to reset the communication status in case of need from any status)
    char initializeMsg[11] = "initialize";
    int initLen = strlen(initializeMsg) + 1;
    ret = send(currentUser->socket, initializeMsg, initLen, 0);
    if(ret != initLen) {
        cerr<<"couldn't initialize the communication. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    string delimiter = " ";
    //wait for the client to choose its behavior (if it challenges or just waits)
    char clientStatus [12]; // "waiting" or "challenging" or "quit"

    ret = recv(currentUser->socket, (void*)clientStatus, 12, 0);

    if(ret <= 0) {
        cerr<<"couldn't receive client status. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    if(!strcmp(clientStatus, "waiting")) { //the user waits to be challenged
        currentUser->status = WAITING;
        return 1;
    }

    if(!strcmp(clientStatus, "challenging")) { //the user wants to challenge someone
        currentUser->status = CHALLENGING;
        return 1;
    }

    if(!strcmp(clientStatus, "quit")) { //the user wants to quit
        cout<<currentUser->username<<" is quitting. Closing the connection."<<endl; //DEBUG
        closeAndLogOut(currentUser);
        return -1;
    }

    cerr<<"The status format was incorrect. Aborting connection..."<<endl;
    closeAndLogOut(currentUser);
    return -1;

}

int FourRowServer::handleCHALLENGING(user* currentUser) {
    int ret;

    cout<<"waiting for a challenge from "<<currentUser->username<<endl;

    //send the list of active users
    activeUsersMutex.lock();
    char * buffer = new char[activeUsers.size()*USERNAME_MAXSIZE];
    int len = activeUsers.size()*USERNAME_MAXSIZE;
    cout<<"sending to "<<currentUser->username<<" the list of "<<activeUsers.size()<<" active users..."<<endl; //DEBUG
    activeUsersMutex.unlock();

    //cout<<"There are "<< activeUsers.size()<< " active users at the moment"<<endl; //DEBUG

    len = activeUsers.size() <= MAX_USERS_TO_SEND ? len : MAX_USERS_TO_SEND*USERNAME_MAXSIZE;
    int index = 0;
    for(map<string, user*>::iterator i = activeUsers.begin(); i != activeUsers.end(); ++i) {
        strcpy(buffer + (index*USERNAME_MAXSIZE),i->first.c_str());
        index++;
    }
    ret = send(currentUser->socket, (const void*)buffer, len, 0);
    //buffer has extinguished its purpose
    delete[] buffer;
    if(ret != len) {
        cerr<<"couldn't send the list of active users. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    //wait for a challenge message by the client
    char challengeMsg[USERNAME_MAXSIZE + 10];
    ret = recv(currentUser->socket, (void*)challengeMsg, USERNAME_MAXSIZE + 10, 0);
    if(ret<=0){
        cerr<<"error while receiving a challenge. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }
    string s(challengeMsg);
    string delimiter = " ";
    string firstWord = s.substr(0,s.find(delimiter));
    if(firstWord.compare("challenge")!=0){
        cerr<<"wrong challenge message format. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }
    string challengedUserName = s.substr(s.find(delimiter)+1,s.size());
    //received the challenge from a user, now sending the message of the challenge to the challenged user

    //check if the challenged user disconnected in the meantime
    user* challengedUser = NULL;
    bool challengedUserIsOffline = ! isOnline(challengedUserName.c_str(), challengedUser);

    if(challengedUserIsOffline) {
        cout<<"the challenged user is now offline"<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    strcpy(currentUser->challenger, challengedUserName.c_str()); //save the challenged username for future use

    if(challengedUser->status != WAITING) { //if the challenged user cannot receive challenges
        const char* errorMsg = "error";
        //send "error" message back to challenger
        ret = send(currentUser->socket, (const void*)errorMsg, strlen(errorMsg) + 1, 0);
        if(ret < strlen(errorMsg) + 1) {
            cerr<<"couldn't send error message to client. Aborting connection...";
            closeAndLogOut(currentUser);
            return -1;
        }
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    unique_lock<mutex> lock(*challengedUser->statusMutex);
    //otherwise we change the status of the other user to CHALLENGED
    challengedUser->status = CHALLENGED;
    strcpy(challengedUser->challenger, currentUser->username);
    lock.unlock();
    currentUser->status = WAITING_RESPONSE;
    challengedUser->statusCV->notify_one(); //and we wake up its thread


    return 1;


}

int FourRowServer::handleWAITING(user* currentUser, unique_lock<mutex> &lock) {

    cout << currentUser->username << " is now waiting to be challenged" << endl; //DEBUG

    int ret;

    //going to sleep until a challenge arrives
    while (currentUser->status == WAITING) {
        currentUser->statusCV->wait(lock);
    }

    return 1;
}

int FourRowServer::handleCHALLENGED(user* currentUser) {
    int ret;

    cout << currentUser->username << " has been challenged by " <<currentUser->challenger<<endl; //DEBUG

    //check if the challenger is still online
    user* challenger;
    bool challengerIsOffline = ! isOnline(currentUser->challenger, challenger);

    if(challengerIsOffline) {
        cout<<"The challenger is now offline."<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    //At this point someone has challenged this user and its username is saved in challenger field
    char challengedMsg[USERNAME_MAXSIZE+13];//13=strlen("challengedBy")

    strcpy(challengedMsg, "challengedBy ");
    strcat(challengedMsg, currentUser->challenger);
    int challengedLen = strlen(challengedMsg) + 1;

    ret = send(currentUser->socket, (const void*) challengedMsg, challengedLen, 0);
    if(ret != challengedLen) {
        cerr<<"Couldn't forward the challenge to the other user. Aborting connection ..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    //now we wait for the response to the challenge
    char challengeResponse[USERNAME_MAXSIZE + 7];//7=strlen("accept/refuse ")

    ret = recv(currentUser->socket, (void*)challengeResponse, USERNAME_MAXSIZE + 7, 0);

    if(ret<=0){
        cerr<<"error while receiving a challenge response. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    string challengeResponseString(challengeResponse);
    string response = challengeResponseString.substr(0,challengeResponseString.find(" "));
    //challengerusername contains the name of the name that challenged the currentUser. It's used to avoid the
    //case in which multiple users simultaneously challenge the currentUser and we don't know to who he is answering
    string challengerUsername = challengeResponseString.substr(challengeResponseString.find(" ")+1,challengeResponseString.size());

    if(strcmp(currentUser->challenger, challengerUsername.c_str())) { //the user didn't accept a challenge for the expected user
        cerr<<"User answered to a challenge for the wrong challenger. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    challenger->statusMutex->lock();

    challenger->status = RESPONSE_ARRIVED;

    if(response.compare("accept")==0){
        challenger->challengeAccepted = true;
    }

    else if (response.compare("refuse")==0){
        challenger->challengeAccepted = false;
        currentUser->status = TO_BE_ASKED;
        challenger->statusMutex->unlock();
        challenger->statusCV->notify_one();
        return 1;
    }

    challenger->statusMutex->unlock();
    challenger->statusCV->notify_one();
    currentUser->status = WAITING_FOR_P2P_ADDRESS;

    return 1;

}

int FourRowServer::handleWAITING_RESPONSE(user* currentUser, unique_lock<mutex>& lock) {

    cout<<"user "<<currentUser->username<<" is waiting for a response to its challenge"<<endl; //DEBUG

    //wait until a response arrives
    while (currentUser->status == WAITING_RESPONSE) {
        currentUser->statusCV->wait(lock);
    }

    return 1;
}

int FourRowServer::handleRESPONSE_ARRIVED(user* currentUser) {
    int ret;

    cout<<"user "<<currentUser->username<<" has received a response for its challenge"<<endl; //DEBUG

    //check if the challenged user is still online
    user* challenged;
    bool challengedIsOffline = ! isOnline(currentUser->challenger, challenged);

    if(challengedIsOffline) {
        cout<<"The challenged  user is now offline."<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    //now we are sure the response has arrived
    if(currentUser->challengeAccepted) {
        const char* acceptedMessage = "ok";
        int accMsgLen = strlen(acceptedMessage) + 1;
        //notify the challenger so that it opens a listening socket for P2P
        ret = send(currentUser->socket, (const void*)acceptedMessage, accMsgLen, 0);
        if(ret<accMsgLen) {
            cerr<<"error while notifying an accepted challenge. Aborting connection..."<<endl;
            closeAndLogOut(currentUser, challenged);
            return -1;
        }

        //challenger sends back the address and port of its listening socket
        sockaddr_in p2pAddress;
        ret = recv(currentUser->socket, (void*)&p2pAddress, sizeof(p2pAddress), 0);
        if(ret<sizeof(p2pAddress)) {
            cerr<<"Format error while receiving a P2P address from a challenger. Aborting connection..."<<endl;
            closeAndLogOut(currentUser, challenged);
            return -1;
        }

        unique_lock<mutex> lock(*challenged->statusMutex);

        challenged->status = READY_TO_PLAY;
        challenged->challengerAddress = p2pAddress;

        lock.unlock();
        challenged->statusCV->notify_one();

        currentUser->status = PLAYING;
        return 1;

    }

    //in this case the challenge was rejected
    const char* refusedMessage = "ko";
    int refMsgLen = strlen(refusedMessage) + 1;

    //notify the challenger so that it knows the challenge has been refused
    ret = send(currentUser->socket, (const void*)refusedMessage, refMsgLen, 0);
    if(ret<refMsgLen) {
        cerr<<"error while notifying a refused challenge. Aborting connection..."<<endl;
        closeAndLogOut(currentUser); //no need to reinitialize challenged user connection since it does by default in this situation
        return -1;
    }

    currentUser->status = TO_BE_ASKED;
    return 1;

}

int FourRowServer::handleREADY_TO_PLAY(user* currentUser) {

    cout<<"Forwarding p2p address to the challenged user"<<endl; //DEBUG

    //check if the challenger is still online
    user* challenger;
    bool challengerIsOffline = ! isOnline(currentUser->challenger, challenger);

    if(challengerIsOffline) {
        cout<<"The challenger is now offline."<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    int ret = send(currentUser->socket, (const void *)&currentUser->challengerAddress, sizeof(currentUser->challengerAddress), 0);
    if(ret<sizeof(currentUser->challengerAddress)) {
        cerr<<"error while forwarding the ip address. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    currentUser->status = PLAYING;

    return 1;

}

int FourRowServer::handlePLAYING(user* currentUser) {
    int ret;

    cout<<"waiting that user "<<currentUser->username<< " ends its current game"<<endl; //DEBUG

    //wait for game over message from the client before going on
    const char* expectedGameOverMsg = "game over";
    char gameOverMsg[10];
    int expectedLen = strlen(expectedGameOverMsg) + 1;
    ret = recv(currentUser->socket, (void*)gameOverMsg, expectedLen, 0);
    if(ret<expectedLen || strcmp(expectedGameOverMsg, gameOverMsg)) {
        cerr<<"Format error while receiving a game over message. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    currentUser->status = TO_BE_ASKED;

    return 1;

}

int FourRowServer::handleWAITING_FOR_P2P_ADDRESS(user* currentUser, unique_lock<mutex>& lock) {

    cout<<"challenged user "<<currentUser->username<<" is waiting for the opponent IP address"<<endl; //DEBUG

    while(currentUser->status==WAITING_FOR_P2P_ADDRESS) {
        currentUser->statusCV->wait(lock);
    }

    return 1;

}

bool FourRowServer::isOnline(const char* username, user* &dest) {
    //check if the challenger is still online
    activeUsersMutex.lock();
    dest = NULL;
    bool userIsOffline = (activeUsers.find(username) == activeUsers.end());

    if(!userIsOffline) {
        dest = activeUsers[username];
    }
    activeUsersMutex.unlock();

    return !userIsOffline;
}



























