//
// Created by baccios on 20/06/20.
//

#ifndef CYBERSECURITYPROJECT_NEWFOURROWSERVER_H
#define CYBERSECURITYPROJECT_NEWFOURROWSERVER_H


#include <sys/types.h>
#include <sys/param.h>
#include <unistd.h>
#include <map>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include "user.h"
#include "constants.h"

using namespace std;
/*
 * This class implements the server of the application.
*/
class FourRowServer {

private:

    //port and listening IP address, in dotted notation (e.g. 192.168.1.1)
    char address[16];
    uint16_t port;
    int listeningSocket;

    //registered users
    vector<user> *users;

    //active users (map to retrieve them faster (O(logn)))
    map<string, user*> activeUsers;
    mutex activeUsersMutex;

    /*Put the server online and listening for connections, automatically called by the constructor*/
    void launch();
    /*Handle a connection through a data listeningSocket*/
    void handleConnection(int dataSocket, sockaddr_in cl_addr);

    /*called in an infinite while loop inside "handleConnection" after the user is correctly logged in*/
    int testStatusAndHandle(user* currentUser, sockaddr_in &cl_addr);

    /*
     * SECURITY METHODS
     */
    void loadPublicKey(const char* username);


    /*
     * UTILITY HANDLERS
     */
    int handleTO_BE_ASKED(user* currentUser);
    int handleWAITING(user* currentUser, unique_lock<mutex>& lock);
    int handleCHALLENGED(user* currentUser);
    int handleCHALLENGING(user* currentUser);
    int handleWAITING_RESPONSE(user* currentUser, unique_lock<mutex>& lock);
    int handleRESPONSE_ARRIVED(user* currentUser);
    int handleWAITING_FOR_P2P_ADDRESS(user* currentUser, unique_lock<mutex>& lock);
    int handleREADY_TO_PLAY(user* currentUser);
    int handlePLAYING(user* currentUser);

    //check if a user is online by its username and if so save a reference in dest
    bool isOnline(const char* username, user* &dest);

    /*
     * UTILITY INLINE METHODS
     */

    /*Close the user socket and log him/her out in thread safe mode. Optional parameter is an eventual user whose connection to be reinitialized*/
    int closeAndLogOut(user* usr, user* toBeInitialized = NULL) {
        int ret;

        ret = close(usr->socket);

        activeUsersMutex.lock();
        activeUsers.erase(usr->username);
        activeUsersMutex.unlock();

        if(toBeInitialized) {
            unique_lock<mutex> lock(*toBeInitialized->statusMutex);
            toBeInitialized->status = TO_BE_ASKED;
            lock.unlock();
            toBeInitialized->statusCV->notify_one();
        }

        return ret;
    }

public:
    //The constructor initializes the server and opens a listening listeningSocket
    FourRowServer(const char* addr, uint16_t port, const char *userFileNam);
};


#endif //CYBERSECURITYPROJECT_NEWFOURROWSERVER_H
