//
// Created by emilio on 20/06/20.
//

#include "PlayField.h"
#include <iostream>
#include "color.h"
using namespace std;

PlayField::PlayField() {
    playing = true;
    for(int i = 0; i < NROWS; i ++) {
        for(int j = 0; j < NCOLUMNS; j ++) {
            playField[i][j] = ' ';
        }
    }
}
void PlayField::print(){
    for(int i = 0; i < NROWS; i ++) {
        for(int j = 0; j < NCOLUMNS; j ++) {
            cout<<BOLDGREEN<<"|"<<RESET<<" "<<BOLDRED<<playField[i][j]<<" "<<RESET;
        }
        cout<<BOLDGREEN<<"|"<<endl<<RESET;

    }
    for(int i = 0; i < NCOLUMNS; i ++) {
        cout<<BOLDBLUE<<"  "<<i<<" "<<RESET;
    }
    cout<<endl;
}

bool PlayField::isColumnFull(int column){
    if(playField[0][column] != ' ') return true;
    return false;
}

int PlayField::insertToken(int column,char playerSymbol){
    if(column >= NCOLUMNS || column < 0) {
        cout<<"The column doesn't exist"<<endl;
        return -1;
    }
    if(isColumnFull(column)) {
        cout<<"Cannot insert the token since the column is full!"<<endl;
        return -1;
    }
    for(int i = NROWS-1; i >= 0; i --) {
        if( playField[i][column] == ' ') {
            playField[i][column] = playerSymbol;
            if(checkField(i, column, playerSymbol)){
                cout<<"Partita finita"<<endl;
                playing = false;
                return 1;
            }
            return 0;
        }
    }
    return -1;
}

bool PlayField::checkField(int row,int column,char playerSymbol) {

    //check left horizontally
    int count = 0;
    for(int i = column; i >= 0; i --) {
        if(playField[row][i] == playerSymbol) {
            count ++;
        }
    }
    //check right horizontally
    for(int i = column+1; i < NCOLUMNS; i ++) {
        if(playField[row][i] == playerSymbol) {
            count ++;
        }
    }
    if(count >= 4) {
        cout<<"VINTO ORIZZONTALMENTE"<<endl;
        return true;
    }

    //check down vertically
    count = 0;
    for(int i = row; i >= 0; i --) {
        if(playField[i][column] == playerSymbol) {
            count ++;
        }
    }
    //check up vertically
    for(int i = row+1; i < NROWS; i ++) {
        if(playField[i][column] == playerSymbol) {
            count ++;
        }
    }
    if(count >= 4) {
        cout<<"VINTO VERTICALMENTE"<<endl;
        return true;
    }

    count = 0;
    int sum = row + column;
    //check up diagonally left
    for(int i = row; i >= 0; i --) {
        for(int j = column; j >= 0; j --) {
            if(playField[i][j] == playerSymbol) {

                if( (i + j) == sum)
                    count ++;
            }
        }

        sum -= 2;
    }

    sum = row + column +2;
    //check down diagonally right
    for(int i = row+1; i < NROWS; i ++) {
        for(int j = column+1; j < NCOLUMNS; j ++) {
            if(playField[i][j] == playerSymbol) {
                if( (i + j) == sum)
                    count ++;
            }
        }
        sum += 2;
    }
    if(count >= 4) {
        cout<<"WIN DIAGONALLY UP LEFT ,DOWN RIGHT"<<endl;
        return true;
    }
    count = 0;


    sum = row + column;
    //check up diagonally right
    for(int i = row ; i >= 0; i --) {
        for(int j = column; j < NCOLUMNS ; j ++) {
            if(playField[i][j] == playerSymbol) {
                if(i + j == sum)
                    count ++;
            }
        }
    }
    //check down diagonally left
    for(int i = row+1; i < NROWS; i ++) {
        for(int j = column-1; j >= 0; j --) {
            if(playField[i][j] == playerSymbol) {
                if(i + j == sum)
                    count ++;
            }
        }
    }
    if(count >= 4) {
        cout<<"WIN DIAGONALLY DOWN LEFT ,UP RIGHT"<<endl;
        return true;
    }
    return false;
}