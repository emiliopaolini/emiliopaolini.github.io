//
// Created by baccios on 10/04/20.
//

#ifndef CYBERSECPROJECT_USER_H
#define CYBERSECPROJECT_USER_H
#include <fstream>
#include <vector>
#include <netinet/in.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <cstring>
#include <mutex>
#include <condition_variable>
#include "constants.h"
#include <openssl/evp.h>

using namespace std;

struct user {
    char username[USERNAME_MAXSIZE];
    int socket;

    // the user chooses if he wants to challenge someone or be challenged at the beginning and at the end of each game
    // status contains the current status of the user
    mutex* statusMutex;
    condition_variable* statusCV;
    int status;

    char challenger[USERNAME_MAXSIZE]; //contains either the challenged username or the challenger's, depending on the case
    bool challengeAccepted;
    sockaddr_in challengerAddress;

    //security fields
    EVP_PKEY* pubkey;

};

/*Load all registered users from a file into a vector. (To be called when the server is created)
 * Return NULL in case of failure.
*/
vector<user>* loadUsers(const char *filename);


#endif
