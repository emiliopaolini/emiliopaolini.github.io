//
// Created by emilio on 20/06/20.
//

#include <iostream>
#include "PlayField.h"
#include <cstring>
using namespace std;
int main() {
    PlayField playField;
    int i = 0;
    while(playField.playing) {
        //the waiting player starts the game
        int res;
        while(true){
            res = sendMove();
            if(res<0){
                cerr<<"error in sending the column. Aborting..."<<endl;
                close(P2pSocket);
                return -1;
            }
            else{
                if(res==0){
                    //keep playing
                    playField.print();
                    int result = sendMove();
                    if(result<0){
                        cerr<<"received an invalid column. Aborting..."<<endl;
                        close(P2pSocket);
                        return -1;
                    }
                    else{
                        if(result==0){
                            //keep playing
                            playField.print();
                            res = sendMove();
                            playField.print();
                        }
                        else{
                            if(result==1){
                                //game is over
                                break;
                            }
                        }
                    }
                    playField.print();
                }
            }
        }
        //challenging Player -> waits for the first move of the adversary
        int res;
        while(true){
            res = receiveMove();
            if(result<0){
                cerr<<"received an invalid column. Aborting..."<<endl;
                close(P2pSocket);
                return -1;
            }
            else{
                if(result==0){
                    //keep playing
                    playField.print();
                    res = sendMove();
                    if(res<0){
                        cerr<<"error in sending the column. Aborting..."<<endl;
                        close(P2pSocket);
                        return -1;
                    }
                    else{
                        playField.print();
                    }
                }
                else{
                    if(result==1){
                        //game is over
                        break;
                    }
                }
            }
        }
    }


    int sendMove(){
        int column;
        cout<<"In quale colonna vuoi inserire il gettone?"<<endl;
        bool goodDecision = false;
        while(!goodDecision)
        {
            cin>>column;
            if (playField.insertToken(column, playerSymbol1)>=0);
            goodDecision = true;
        }
        char columnMessage[9];//9==strlen(column: $column)
        strcpy(columnMessage, "column: ");
        strcat(columnMessage, to_string(column).c_str());

        int columnMessageLength = strlen(columnMessage) + 1;
        int ret = send(P2pSocket, (const void*) columnMessage, columnMessageLength, 0);
        if (ret < columnMessageLength) {
            cerr << "Error in sending the column Message. Aborting..." << endl;
            close(P2pSocket);
            return -1;
        }
        return 0;
    }

    int receiveMove(){
        char columnMessage[9]; // The longest string possible is "column: $column"
        int columnMessageLength = 9;
        ret = recv(P2pSocket, (void *) columnMessage, columnMessageLength, 0);
        if (ret <= columnMessageLength) {
            cerr << "error while receiving the move from the adversary for a challenge. Aborting..." << endl;
            close(P2pSocket);
            return -1;
        }
        string columnMsg(columnMessage);

        string delimiter = " ";
        string firstWord = s.substr(0,s.find(delimiter));
        if(firstWord.compare("column:")!=0){
            cerr<<"wrong column message format. Aborting connection..."<<endl;
            close(P2pSocket);
            return -1;
        }
        int column = stoi(columnMsg.substr(columnMsg.find(delimiter)+1, columnMsg.size()));
        return result = playField.insertToken(column, playerSymbol2);

    }
}