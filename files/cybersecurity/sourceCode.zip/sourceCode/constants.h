//
// Created by baccios on 24/06/20.
//

#ifndef CYBERSECURITYPROJECT_CONSTANTS_H
#define CYBERSECURITYPROJECT_CONSTANTS_H

const unsigned int USERNAME_MAXSIZE = 16;
const unsigned int MAX_USERS_TO_SEND = 64;

const int TO_BE_ASKED = -1;
const int WAITING = 0;
const int CHALLENGED = 1;
const int CHALLENGING = 2;
const int WAITING_RESPONSE = 3;
const int RESPONSE_ARRIVED = 4;
const int WAITING_FOR_P2P_ADDRESS = 5;
const int READY_TO_PLAY = 6;
const int PLAYING = 7;

//only used in client
const int QUITTING = 8;
const int WAITING_INIT = 9;
const int GAME_OVER = 10;

#endif //CYBERSECURITYPROJECT_CONSTANTS_H
