//
// Created by baccios on 10/04/20.
//
#include "user.h"

/*Load all registered users from a file into a vector. (To be called when the server is created)
 * Return NULL in case of failure.
*/
vector<user>* loadUsers(const char *filename) {
    //TODO: sanitize filename
    ifstream userFile;
    userFile.open(filename);
    if(!userFile.is_open()) {
          return NULL;
    }

    //create the data structure
    vector<user> *userList = new vector<user>;
    while(1) {
        user current;
        for(int i = 0; i < 2; ++i) {
            switch(i) {
                case 0:
                    userFile.getline(current.username, USERNAME_MAXSIZE);
                    if(userFile.fail() && userFile.eof()) { //in this case there are no more users to read
                        return userList;
                    }
                    else if(userFile.fail()) { //in this case an error occurred
                        delete userList;
                        return NULL;
                    }
                    break;
                case 1:
                    //TODO: save public key
                    break;
                default:
                    break;
            }
        }
        userList->push_back(current);
    }

}
