#include <iostream>

#include "FourRowClient.h"
#include "FourRowServer.h"
#include "cstring"

using namespace std;


int main( int argc, char** argv) {
    std::cout << "Hello, Barils!" << std::endl;
    //TODO add argc argv and pass these parameters as arguments

    if (argc < 2) {
        cout << "usage; 0->server, 1->client from command line" << endl;
        return 0;
    }

    if(strcmp(argv[1], "1") == 0) {

        FourRowServer server("127.0.0.1", 9000, "userFile");

    }
    if(strcmp(argv[1], "2") == 0)
        FourRowClient client("emilio","127.0.0.1",9000);
    if(strcmp(argv[1], "3") == 0)
        FourRowClient client("baccio","127.0.0.1",9000);
    return 0;
}
