//
// Created by baccios on 09/04/20.
//

#ifndef CYBERSECPROJECT_FOURROWCLIENT_H
#define CYBERSECPROJECT_FOURROWCLIENT_H

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <cstring>
#include "constants.h"
#include "PlayField.h"
#include "SecurityManager.h"

class FourRowClient {
private:


    PlayField* field;
    SecurityManager securityManager;
    char username[USERNAME_MAXSIZE];

    //opponent info
    char opponent[USERNAME_MAXSIZE];

    bool isChallenger; //used in game to decide who sends the first message in p2p communication

    client_status status; //contains the current status of user connection

    char serverAddress[16];
    uint16_t serverPort;

    //active users
    char activeUsers[MAX_USERS_TO_SEND][USERNAME_MAXSIZE];
    int activeUsersSize;

    //Server socket identifier, initialized on launch()
    int servSock;
    //P2P socket identifier, initialized after the connection with another client
    int gameSocket;
    //listening socket for p2p connections.
    int listeningSock;
    //p2p address of the opponent
    sockaddr_in oppoAddr;

    //key with the server
    unsigned char* keyWithServer;
    const int keyLength = SecurityManager::SYMMETRIC_KEY_LEN;

    //key with the client
    unsigned char* keyWithClient;
    unsigned char iv_client[MAX_IV_LEN];
    const int keyClientLen = SecurityManager::SYMMETRIC_KEY_LEN;

    //iv
    unsigned char* iv;
    const int ivLength = EVP_CIPHER_iv_length(SecurityManager::SYMMETRIC_CIPHER);

    //sequence number
    uint16_t seq_num;
    uint16_t p2p_seq_num;

    unsigned char* myNonce;
    int myNonceLength;
    //opponent Nonce
    unsigned char* opponentNonce;

    EVP_PKEY* priv_key; //client private key

    EVP_PKEY* opponent_key; //opponent public key
    BIO* oppo_pkey_bio; //BIO pointer to free opponent public key when needed

    //Starts a connection with the server. It's automatically called by the constructor
    void launch();

    //send the status to the server to let it know if i'm waiting or i want to challenge someone
    int sendStatus(int decision);

    //Send a challenge to an active user
    int challenge(const char *username);

    /*INTERFACE METHODS*/

    //Show the list of active users and asks the user to choose one. Return the index of chosen user
    int showAndPromptUsers();
    //Ask user to wait for a challenge (return 0) or challenge a user(return 1) or quit (return -1)
    int waitOrChallenge();
    //The user has received a challenge, asks for the response
    int challengeReceived(const char *username);

    //called in an infinite loop: checks the user status and reacts in consequence, eventually changing the status
    int testStatusAndHandle();


    /*
     * UTILITY HANDLERS
     */
    int handleWAITING_INIT();
    int handleTO_BE_ASKED();
    int handleWAITING();
    int handleCHALLENGED();
    int handleCHALLENGING();
    int handleWAITING_RESPONSE();
    int handleRESPONSE_ARRIVED();
    int handleHANDSHAKE_CHALLENGER();
    int handleHANDSHAKE_CHALLENGED();
    int handleHANDSHAKE_PREPARATION();
    int handlePLAYING();
    int handleGAME_OVER();


    //return 0 if no error,-1 in case of error
    int sendMove();
    //return -1 in case of error,0 in case of valid move, 1 if the game is over
    int receiveMove();
    int checkInputColumn();

    //Perform the handshake protocol with the server
    bool performFRAH();
    //check if a message is an initialize from the server
    bool isInitializeMsg(const char* msg);
    //wait for an initialize message. Return true in case of success, false in case of format errors
    bool waitForInitialize();

public:
    FourRowClient(const char* username, const char *servAddr, uint16_t servPort);

};


#endif //CYBERSECPROJECT_FOURROWCLIENT_H