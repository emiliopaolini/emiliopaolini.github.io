//
// Created by baccios on 20/06/20.
//
#include <cstring>
#include <iostream>
#include <thread>
#include "FourRowServer.h"

#define CERTIFICATE_FILE "./certs/server_cert.pem"


EVP_PKEY* FourRowServer::server_pkey = NULL;
mutex* FourRowServer::privkey_mtx = new mutex;

FourRowServer::FourRowServer(const char *addr, uint16_t port, const char *userFileName) {
    /*assumes not tainted parameters. (parameters are sanitized in main function)*/

    //prompt user for private key file password
    server_pkey = get_privkey();

    strcpy(this->address, addr);
    this->port = port;
    this->users = loadUsers(userFileName);
    launch();
}

EVP_PKEY* FourRowServer::get_privkey() {
    privkey_mtx->lock();
    if(server_pkey) {
        privkey_mtx->unlock();
        return server_pkey;
    }

    server_pkey = SecurityManager::readPrivateKey("./serverPrivKey/server_key.pem");
    privkey_mtx->unlock();
    return server_pkey;
}

int FourRowServer::closeAndLogOut(user* usr, user* toBeInitialized) {
    int ret;

    ret = close(usr->socket);

    activeUsersMutex.lock();
    activeUsers.erase(usr->username);
    activeUsersMutex.unlock();

    EVP_PKEY_free(usr->pubkey);
    memset(usr->enc_key, 0, SecurityManager::SYMMETRIC_KEY_LEN); //erase everything
    memset(usr->iv, 0, EVP_CIPHER_iv_length(SecurityManager::SYMMETRIC_CIPHER));
    delete [] usr->enc_key;

    if(toBeInitialized) {
        unique_lock<mutex> lock(*toBeInitialized->statusMutex);
        toBeInitialized->status = TO_BE_ASKED;
        lock.unlock();
        toBeInitialized->statusCV->notify_one();
    }

    return ret;
}

/*Put the server online and listening for connections*/
void FourRowServer::launch() {
    /*Socket creation*/
    this->listeningSocket = socket(AF_INET, SOCK_STREAM, 0);
    int option = 1;
    setsockopt(this->listeningSocket, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));


    /*Address structure creation*/
    sockaddr_in my_addr;
    memset(&my_addr, 0, sizeof(my_addr) );
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(this->port);
    inet_pton(AF_INET, this->address, &my_addr.sin_addr);

    /*Binding listeningSocket to its address*/
    int ret = bind(this->listeningSocket, (sockaddr*)&my_addr, sizeof(my_addr));
    if(ret != 0) {
        cerr<<"Couldn't bind listening socket. Closing..."<<endl;
        exit(-1);
    }
    /*Setting the socket in listening mode for connections*/
    ret = listen(this->listeningSocket, 10);
    if(ret != 0) {
        cerr<<"Couldn't set the socket in listening mode. Closing..."<<endl;
        exit(-1);
    }


    while(1) {
        sockaddr_in cl_addr;
        int cl_addr_len = sizeof(cl_addr);
        cout<<"Server is opening a new listener for connections"<<endl;
        int new_sock = accept(this->listeningSocket, (sockaddr *) &cl_addr, (socklen_t*)&cl_addr_len);
        if (new_sock == -1) {
            cerr << "A problem occurred while accepting a new connection. Closing..." << endl;
            exit(-1);
        }

        //create a new thread to handle the new connection

        thread handler (&FourRowServer::handleConnection, this, new_sock, cl_addr);
        handler.detach();
    }
}

EVP_PKEY* FourRowServer::loadPublicKey(const char* username){
    string fileName(username);
    fileName = "./pubKeys/" + fileName + ".pem";
    return SecurityManager::readPublicKey(fileName.c_str());
}

void FourRowServer::handleConnection(int dataSocket, sockaddr_in cl_addr) {

    char cl_addr_str [INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(cl_addr.sin_addr), cl_addr_str, INET_ADDRSTRLEN);
    cout<<"A client is now connected from IP address "<<cl_addr_str<<endl; //DEBUG

    user* currentUser = NULL; //initialized after authentication
    unsigned char* encr_key = NULL; //pointer to the symmetric key

    if(performFRAH(dataSocket, currentUser, encr_key)) {
        do {}
        while (testStatusAndHandle(currentUser, cl_addr) != -1);
    }

}

int FourRowServer::testStatusAndHandle(user* currentUser, sockaddr_in& cl_addr) {

    unique_lock<mutex> lock(*currentUser->statusMutex);
    int ret;

    switch(currentUser->status) {

        case TO_BE_ASKED:
            ret = handleTO_BE_ASKED(currentUser);
            break;
        case WAITING:
            ret = handleWAITING(currentUser, lock);
            break;
        case CHALLENGED:
            ret = handleCHALLENGED(currentUser);
            break;
        case CHALLENGING:
            ret = handleCHALLENGING(currentUser, cl_addr);
            break;
        case WAITING_RESPONSE:
            ret = handleWAITING_RESPONSE(currentUser, lock);
            break;
        case RESPONSE_ARRIVED:
            ret = handleRESPONSE_ARRIVED(currentUser);
            break;
        case WAITING_FOR_P2P_ADDRESS:
            ret = handleWAITING_FOR_P2P_ADDRESS(currentUser, lock);
            break;
        case HANDSHAKE_PREPARATION:
            ret = handleHANDSHAKE_PREPARATION(currentUser);
            break;
        case PLAYING:
            ret = handlePLAYING(currentUser);
            break;
        default:
            ret = -1;
            break;
    }

    lock.unlock();
    return ret;
}

int FourRowServer::handleTO_BE_ASKED(user* currentUser) {

    int ret;

    cout<<"sending to "<<currentUser->username<<" the initialization message..."<<endl; //DEBUG
    //protocol initialization (useful to reset the communication status in case of need from any status)
    char initializeMsg[11] = "initialize";
    int initLen = sizeof(initializeMsg);
    ret = SecurityManager::sendEncrypted(
            currentUser->socket,
            initializeMsg,
            initLen,
            currentUser->enc_key,
            currentUser->iv,
            currentUser->seq_num++
            );
    if(ret != initLen) {
        cerr<<"couldn't initialize the communication. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    string delimiter = " ";
    //wait for the client to choose its behavior (if it challenges or just waits)
    char clientStatus [12]; // "waiting" or "challenging" or "quit"

    ret = SecurityManager::receiveDecrypted(
            currentUser->socket,
            (void*)clientStatus,
            sizeof(clientStatus),
            currentUser->enc_key,
            currentUser->iv,
            currentUser->seq_num++
            );

    //SANITIZED
    clientStatus[11] = '\0';

    if(ret <= 0) {
        cerr<<"couldn't receive client status. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    if(!strcmp(clientStatus, "waiting")) { //the user waits to be challenged
        currentUser->status = WAITING;
        return 1;
    }

    if(!strcmp(clientStatus, "challenging")) { //the user wants to challenge someone
        currentUser->status = CHALLENGING;
        return 1;
    }

    if(!strcmp(clientStatus, "quit")) { //the user wants to quit
        cout<<currentUser->username<<" is quitting. Closing the connection."<<endl; //DEBUG
        closeAndLogOut(currentUser);
        return -1;
    }

    cerr<<"The status format was incorrect. Aborting connection..."<<endl;
    closeAndLogOut(currentUser);
    return -1;

}

int FourRowServer::handleCHALLENGING(user* currentUser, sockaddr_in& cl_addr) {
    int ret;

    cout<<"waiting for a challenge from "<<currentUser->username<<endl;

    //send the list of active users
    activeUsersMutex.lock();
    char * buffer = new char[activeUsers.size()*USERNAME_MAXSIZE];
    int len = activeUsers.size()*USERNAME_MAXSIZE;
    cout<<"sending to "<<currentUser->username<<" the list of "<<activeUsers.size()<<" active users..."<<endl; //DEBUG
    activeUsersMutex.unlock();

    //cout<<"There are "<< activeUsers.size()<< " active users at the moment"<<endl; //DEBUG

    len = activeUsers.size() <= MAX_USERS_TO_SEND ? len : MAX_USERS_TO_SEND*USERNAME_MAXSIZE;
    int index = 0;
    for(map<string, user*>::iterator i = activeUsers.begin(); i != activeUsers.end(); ++i) {
        strcpy(buffer + (index*USERNAME_MAXSIZE),i->first.c_str());
        index++;
    }
    ret = SecurityManager::sendEncrypted(
            currentUser->socket,
            (const void*)buffer,
            len,
            currentUser->enc_key,
            currentUser->iv,
            currentUser->seq_num++
            );
    //buffer has extinguished its purpose
    delete[] buffer;
    if(ret != len) {
        cerr<<"couldn't send the list of active users. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    //wait for a challenge message by the client
    char challengeMsg[USERNAME_MAXSIZE + 10];
    ret = SecurityManager::receiveDecrypted(
                currentUser->socket,
                (void*)challengeMsg,
                USERNAME_MAXSIZE + 10,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    if(ret<=0){
        cerr<<"error while receiving a challenge. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    //SANITIZED
    challengeMsg[sizeof(challengeMsg) - 1] = '\0';

    string s(challengeMsg);
    string delimiter = " ";
    string firstWord = s.substr(0,s.find(delimiter));
    if(firstWord.compare("challenge")!=0){
        cerr<<"wrong challenge message format. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }
    string challengedUserName = s.substr(s.find(delimiter)+1,s.size());
    //received the challenge from a user, now sending the message of the challenge to the challenged user

    //check if the challenged user disconnected in the meantime
    user* challengedUser = NULL;
    bool challengedUserIsOffline = ! isOnline(challengedUserName.c_str(), challengedUser);

    if(challengedUserIsOffline) {
        cout<<"the challenged user is now offline"<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    //no need to sanitize
    strcpy(currentUser->challenger, challengedUserName.c_str()); //save the challenged username for future use

    if(challengedUser->status != WAITING) { //if the challenged user cannot receive challenges
        const char* errorMsg = "error";
        //send "error" message back to challenger
        ret = SecurityManager::sendEncrypted(
                    currentUser->socket,
                    (const void*)errorMsg,
                    strlen(errorMsg) + 1,
                    currentUser->enc_key,
                    currentUser->iv,
                    currentUser->seq_num++
                );
        if(ret < strlen(errorMsg) + 1) {
            cerr<<"couldn't send error message to client. Aborting connection...";
            closeAndLogOut(currentUser);
            return -1;
        }
        currentUser->status = TO_BE_ASKED;
        return 1;
    }


    unique_lock<mutex> lock(*challengedUser->statusMutex);
    //otherwise we change the status of the other user to CHALLENGED
    challengedUser->status = CHALLENGED;
    //no need to sanitize
    strcpy(challengedUser->challenger, currentUser->username);

    lock.unlock();
    currentUser->status = WAITING_RESPONSE;
    challengedUser->statusCV->notify_one(); //and we wake up its thread
    currentUser->challengerAddress = cl_addr;

    return 1;

}

int FourRowServer::handleWAITING(user* currentUser, unique_lock<mutex> &lock) {

    cout << currentUser->username << " is now waiting to be challenged" << endl; //DEBUG

    //going to sleep until a challenge arrives
    while (currentUser->status == WAITING) {
        cv_status timeoutCheck = currentUser->statusCV->wait_for(lock,20s);
        if(timeoutCheck == cv_status::timeout) {
            currentUser->status = TO_BE_ASKED;
        }
    }

    return 1;
}

int FourRowServer::handleCHALLENGED(user* currentUser) {
    int ret;

    cout << currentUser->username << " has been challenged by " <<currentUser->challenger<<endl; //DEBUG

    //check if the challenger is still online
    user* challenger;
    bool challengerIsOffline = ! isOnline(currentUser->challenger, challenger);

    if(challengerIsOffline) {
        cout<<"The challenger is now offline."<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    //At this point someone has challenged this user and its username is saved in challenger field
    char challengedMsg[USERNAME_MAXSIZE+13];//13=strlen("challengedBy")

    strcpy(challengedMsg, "challengedBy ");
    strcat(challengedMsg, currentUser->challenger);
    int challengedLen = strlen(challengedMsg) + 1;

    ret = SecurityManager::sendEncrypted(
                currentUser->socket,
                (const void*) challengedMsg,
                challengedLen,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    if(ret != challengedLen) {
        cerr<<"Couldn't forward the challenge to the other user. Aborting connection ..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    //now we wait for the response to the challenge
    char challengeResponse[USERNAME_MAXSIZE + 7];//7=strlen("accept/refuse ")

    ret = SecurityManager::receiveDecrypted(
                currentUser->socket,
                (void*)challengeResponse,
                USERNAME_MAXSIZE + 7,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );

    if(ret<=0){
        cerr<<"error while receiving a challenge response. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    //SANITIZING
    challengeResponse[USERNAME_MAXSIZE + 6] = '\0';

    string challengeResponseString(challengeResponse);
    string response = challengeResponseString.substr(0,challengeResponseString.find(" "));
    //challengerusername contains the name of the name that challenged the currentUser. It's used to avoid the
    //case in which multiple users simultaneously challenge the currentUser and we don't know to who he is answering
    string challengerUsername = challengeResponseString.substr(challengeResponseString.find(" ")+1,challengeResponseString.size());

    if(strcmp(currentUser->challenger, challengerUsername.c_str())) { //the user didn't accept a challenge for the expected user
        cerr<<"User answered to a challenge for the wrong challenger. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, challenger);
        return -1;
    }

    challenger->statusMutex->lock();

    challenger->status = RESPONSE_ARRIVED;

    if(response.compare("accept")==0){
        challenger->challengeAccepted = true;
    }

    else if (response.compare("refuse")==0){
        challenger->challengeAccepted = false;
        currentUser->status = TO_BE_ASKED;
        challenger->statusMutex->unlock();
        challenger->statusCV->notify_one();
        return 1;
    }

    challenger->statusMutex->unlock();
    challenger->statusCV->notify_one();
    currentUser->status = WAITING_FOR_P2P_ADDRESS;

    return 1;

}

int FourRowServer::handleWAITING_RESPONSE(user* currentUser, unique_lock<mutex>& lock) {

    cout<<"user "<<currentUser->username<<" is waiting for a response to its challenge"<<endl; //DEBUG

    //wait until a response arrives
    while (currentUser->status == WAITING_RESPONSE) {
        currentUser->statusCV->wait(lock);
    }

    return 1;
}

int FourRowServer::handleRESPONSE_ARRIVED(user* currentUser) {
    int ret;

    cout<<"user "<<currentUser->username<<" has received a response for its challenge"<<endl; //DEBUG

    //check if the challenged user is still online
    user* challenged;
    bool challengedIsOffline = ! isOnline(currentUser->challenger, challenged);

    if(challengedIsOffline) {
        cout<<"The challenged  user is now offline."<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    //now we are sure the response has arrived
    if(currentUser->challengeAccepted) {
        const char* acceptedMessage = "ok";
        int accMsgLen = strlen(acceptedMessage) + 1;
        //notify the challenger so that it opens a listening socket for P2P
        ret = SecurityManager::sendEncrypted(
                    currentUser->socket,
                    (const void*)acceptedMessage,
                    accMsgLen,
                    currentUser->enc_key,
                    currentUser->iv,
                    currentUser->seq_num++
                );
        if(ret<accMsgLen) {
            cerr<<"error while notifying an accepted challenge. Aborting connection..."<<endl;
            closeAndLogOut(currentUser, challenged);
            return -1;
        }

        //challenger sends back the address and port of its listening socket
        sockaddr_in p2pAddress;
        ret = SecurityManager::receiveDecrypted(
                    currentUser->socket,
                    (void*)&p2pAddress,
                    sizeof(p2pAddress),
                    currentUser->enc_key,
                    currentUser->iv,
                    currentUser->seq_num++
                );

        if(ret<sizeof(p2pAddress)) {
            cerr<<"Format error while receiving a P2P address from a challenger. Aborting connection..."<<endl;
            closeAndLogOut(currentUser, challenged);
            return -1;
        }

        int ivLength;
        unsigned char* iv = (unsigned char *)SecurityManager::generateIV(ivLength);
        memcpy((void*)currentUser->iv_p2p, (const void*)iv, ivLength);

        unique_lock<mutex> lock(*challenged->statusMutex);

        challenged->status = HANDSHAKE_PREPARATION;
        challenged->challengerAddress = p2pAddress;
        memcpy((void*)challenged->iv_p2p, (const void*)iv, ivLength);

        lock.unlock();
        challenged->statusCV->notify_one(); //Awake the challenged user from WAITING_FOR_P2P_ADDRESS status

        delete [] iv;
        currentUser->status = HANDSHAKE_PREPARATION;
        return 1;

    }

    //in this case the challenge was rejected
    const char* refusedMessage = "ko";
    int refMsgLen = strlen(refusedMessage) + 1;

    //notify the challenger so that it knows the challenge has been refused
    ret = SecurityManager::sendEncrypted(
                currentUser->socket,
                (const void*)refusedMessage,
                refMsgLen,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    if(ret<refMsgLen) {
        cerr<<"error while notifying a refused challenge. Aborting connection..."<<endl;
        closeAndLogOut(currentUser); //no need to reinitialize challenged user connection since it does by default in this situation
        return -1;
    }

    currentUser->status = TO_BE_ASKED;
    return 1;

}

int FourRowServer::handleHANDSHAKE_PREPARATION(user* currentUser) {

    int MAX_MSG_SIZE = SecurityManager::NONCE_LENGTH;
    MAX_MSG_SIZE += SERIAL_KEY_SIZE > DH_PARAMS_SIZE ? SERIAL_KEY_SIZE : DH_PARAMS_SIZE;

    unsigned char msg[MAX_MSG_SIZE];

    //check if the challenger is still online
    user* opponent;
    bool challengerIsOffline = ! isOnline(currentUser->challenger, opponent);

    if(challengerIsOffline) {
        cout<<"The challenger is now offline."<<endl;
        currentUser->status = TO_BE_ASKED;
        return 1;
    }

    cout<<"Waiting for Nonce from the client"<<endl; //DEBUG
    int ret = SecurityManager::receiveDecrypted(
                currentUser->socket,
                (void*) msg,
                SecurityManager::NONCE_LENGTH,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    if(ret < SecurityManager::NONCE_LENGTH) {
        cerr<<"Could not receive the sequence number from the client. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }


    currentUser->nonceMutex->lock();
    memcpy((void*)currentUser->nonce, msg, SecurityManager::NONCE_LENGTH);

    currentUser->nonceSent=true;
    //cout<<"Received nonce: "<<buffer<<" from: "<<currentUser->username<<endl; //DEBUG
    currentUser->nonceMutex->unlock();
    currentUser->nonceCV->notify_one();
    cout<<"received nonce"<<endl;


    cout<<"Forwarding opponent address to "<<currentUser->username<<endl; //DEBUG
    int addressLen = sizeof(currentUser->challengerAddress);
    memcpy((void*)msg, (const void*)&currentUser->challengerAddress, addressLen);

    //sending {Seq_num, ip_addr}
    ret = SecurityManager::sendEncrypted(
                currentUser->socket,
                (const void*)msg,
                addressLen,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    if(ret<sizeof(currentUser->challengerAddress)) {
        cerr<<"error while forwarding the ip address. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }
    EVP_PKEY* opponent_pubkey = loadPublicKey(opponent->username); //reload to avoid mutual exclusion issues
    if(!opponent_pubkey) {
        cerr<<"Could not load opponent public key (internal error). Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }

    BIO* bio;
    long pubkey_len = 0;
    unsigned char* serial_key = (unsigned char *)SecurityManager::serializeKey(opponent_pubkey, pubkey_len, bio);
    if(!serial_key || pubkey_len != SERIAL_KEY_SIZE) {
        cerr<<"Could not serialize opponent key or format is not correct. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }
    memcpy((void*)msg, (const void*)serial_key, pubkey_len); //prepare the buffer

    //send the opponent's public key
    ret = SecurityManager::sendEncrypted(
                currentUser->socket,
                (const void*)msg,
                pubkey_len,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    EVP_PKEY_free(opponent_pubkey);
    BIO_free(bio); //this also frees the serialized key
    if(ret < pubkey_len) {
        cerr<<"Could not forward a public key to the client. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }



    //sending IV that client will use with the other client in encrypted communication
    int ivLength = EVP_CIPHER_iv_length(SecurityManager::SYMMETRIC_CIPHER);
    memcpy((void*)msg, (const void*)currentUser->iv_p2p, ivLength); //prepare the buffer

    ret = SecurityManager::sendEncrypted(
            currentUser->socket,
            (const void*)msg,
            ivLength,
            currentUser->enc_key,
            currentUser->iv,
            currentUser->seq_num++
    );

    if(ret<ivLength){
        cerr<<"Couldn't send iv to the client. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }



    cout<<"Sending Diffie Hellman parameters to "<<currentUser->username<<endl; //DEBUG
    //now send the Diffie Hellman parameters g,p
    //we use standard parameters, but in future releases we could use custom ones

    //serialize parameters
    DH* params = DH_get_2048_224();
    long ser_params_len;
    unsigned char* ser_params = (unsigned char *)SecurityManager::serializeDHParams(params, ser_params_len, bio);
    if(!ser_params || ser_params_len != DH_PARAMS_SIZE) {
        cerr<<"Could not serialize Diffie Hellman parameters. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }
    memcpy((void*)msg, (const void*)ser_params, ser_params_len); //prepare the buffer

    //cout<<endl<<"DH parameters serialized stay on "<<ser_params_len<<" bytes"<<endl; //DEBUG
    //send Diffie Hellman parameters

    ret = SecurityManager::sendEncrypted(
            currentUser->socket,
            (const void*)msg,
            ser_params_len,
            currentUser->enc_key,
            currentUser->iv,
            currentUser->seq_num++
    );

    DH_free(params);
    BIO_free(bio);

    if(ret < ser_params_len) {
        cerr<<"Could not forward DH parameters to the client. Aborting connection..."<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }


    //check if the other user nonce is arrived
    opponent->nonceMutex->lock();
    while(opponent->nonceSent==false) {
        unique_lock<mutex> lock(*opponent->statusMutex);
        //if it is not arrived, wait for it
        cout<<"nonce is not yet arrived, waiting"<<endl;
        opponent->nonceCV->wait(lock);
    }
    opponent->nonceMutex->unlock();

    memcpy((void*)msg, (const void*)opponent->nonce, SecurityManager::NONCE_LENGTH);
    //send to currentUser the other user nonce
    ret = SecurityManager::sendEncrypted(
            currentUser->socket,
            (const void*)msg,
            SecurityManager::NONCE_LENGTH,
            currentUser->enc_key,
            currentUser->iv,
            currentUser->seq_num++
    );
    if(ret < SecurityManager::NONCE_LENGTH) {
        cerr<<"Error in sending the nonce to the other user"<<endl;
        closeAndLogOut(currentUser, opponent);
        return -1;
    }


    currentUser->status = PLAYING; //users will now talk in P2P and play


    return 1;

}

int FourRowServer::handlePLAYING(user* currentUser) {
    int ret;

    cout<<"waiting that user "<<currentUser->username<< " ends its current game"<<endl; //DEBUG

    //wait for game over message from the client before going on
    const char* expectedGameOverMsg = "game over";
    char gameOverMsg[10];
    int expectedLen = strlen(expectedGameOverMsg) + 1;
    ret = SecurityManager::receiveDecrypted(
                currentUser->socket,
                (void*)gameOverMsg,
                expectedLen,
                currentUser->enc_key,
                currentUser->iv,
                currentUser->seq_num++
            );
    //SANITIZING
    gameOverMsg[9] = '\0';
    if(ret<expectedLen || strcmp(expectedGameOverMsg, gameOverMsg)) {
        cerr<<"Format error while receiving a game over message. Aborting connection..."<<endl;
        closeAndLogOut(currentUser);
        return -1;
    }

    currentUser->status = TO_BE_ASKED;

    return 1;

}

//this status is necessary since the address of the challenger listening socket must be received before forwarding it
//to the challenged user. (Since the port is unknown to the server)
int FourRowServer::handleWAITING_FOR_P2P_ADDRESS(user* currentUser, unique_lock<mutex>& lock) {

    cout<<"challenged user "<<currentUser->username<<" is waiting for the opponent IP address"<<endl; //DEBUG

    while(currentUser->status==WAITING_FOR_P2P_ADDRESS) {
        currentUser->statusCV->wait(lock);
    }

    return 1;
}

bool FourRowServer::isOnline(const char* username, user* &dest) {
    //check if the challenger is still online
    activeUsersMutex.lock();
    dest = NULL;
    bool userIsOffline = (activeUsers.find(username) == activeUsers.end());

    if(!userIsOffline) {
        dest = activeUsers[username];
    }
    activeUsersMutex.unlock();

    return !userIsOffline;
}


bool FourRowServer::performFRAH(int dataSocket, user* &currentUser, unsigned char* &symmetric_key) {

    /**********
     * Begin Four Row Authentication Handshake
     **********/

    SecurityManager security;

    unsigned char* premaster = NULL;
    unsigned char NonceA [SecurityManager::NONCE_LENGTH];
    unsigned char* NonceB = NULL;
    unsigned char* digest = NULL;
    unsigned int digestLen = 0;
    unsigned char* digestSign = NULL;
    int signLen = 0;
    char temp_username[USERNAME_MAXSIZE];
    EVP_PKEY* user_pub = NULL; //public key of the user, to be loaded then
    EVP_PKEY* server_privkey = NULL;
    currentUser = NULL;

    unsigned char buffer[1024]; //utility buffer to store handshake messages

    //Waiting for M1
    int ret = recv(dataSocket, (void*)NonceA, SecurityManager::NONCE_LENGTH, 0);
    if(ret < SecurityManager::NONCE_LENGTH) {
        cerr<<"Error while receiving the client nonce (M1)"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }


    //Sending M2

    NonceB = (unsigned char *)security.generateNonce(ret);
    if(ret != SecurityManager::NONCE_LENGTH) {
        cerr<<"Server mismatch in nonce length. Critical error."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }
    ret = send(dataSocket, (const void *)NonceB, SecurityManager::NONCE_LENGTH, 0);
    if(ret < SecurityManager::NONCE_LENGTH) {
        cerr<<"Error while sending the server nonce nonce (M2)"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //receive M3 ("username")
    ret = recv(dataSocket, (void*)temp_username, USERNAME_MAXSIZE, 0);
    if (ret <= 0) {
        cerr<<"Couldn't receive the client username. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }
    temp_username[USERNAME_MAXSIZE - 1] = '\0'; //sanitizing the input, now we are sure that username contains a string
    user_pub = loadPublicKey(temp_username);
    if(!user_pub) {
        cerr<<"The username is not registered. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //check if user is already active
    activeUsersMutex.lock();
    if(activeUsers.find(temp_username) != activeUsers.end()) {
        cerr<<temp_username<<" is already logged. Aborting connection"<<endl;
        activeUsersMutex.unlock();
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }
    activeUsersMutex.unlock();


    //retrieve the user
    for (vector<user>::iterator it = this->users->begin() ; it != this->users->end(); ++it) {

        if(!strcmp(it->username, temp_username)) { //if user correspond

            //Fill socket and mutex of the active client
            it->socket = dataSocket;
            it->statusMutex = new mutex;
            it->statusCV = new condition_variable;
            it->nonceMutex = new mutex;
            it->nonceCV = new condition_variable;
            it->status = TO_BE_ASKED; //default value, to avoid challenges received at this time
            it->pubkey = user_pub;
            it->seq_num = 0;

            currentUser = &(*it); //save the user for future reference
        }
    }

    if(!currentUser) {
        cerr<<"User could not be found for a server internal error. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //receive M4 (client public key)
    //need to serialize the user public key to know how many bytes to receive
    long serial_key_len;
    BIO* bio;
    SecurityManager::serializeKey(user_pub, serial_key_len,bio); //don't store the return value since we won't use it
    BIO_free(bio);

    ret = recv(dataSocket, buffer, (size_t)serial_key_len, 0);
    if(ret != serial_key_len) {
        cerr<<"The public key size does not match. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    EVP_PKEY* received_key = SecurityManager::deserializeKey((unsigned char *)buffer, serial_key_len,bio);


    if(SecurityManager::compareKeys(user_pub, received_key) == 0) { //if public key does not match
        cerr<<"The public key does not match. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    BIO_free(bio);
    EVP_PKEY_free(received_key); //It is only a copy of the key we have

    //Sending server certificate (M5)
    X509* server_cert = SecurityManager::readCertificate(CERTIFICATE_FILE);
    if(server_cert == NULL) {
        cerr<<"Couldn't load my own certificate. Aborting..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;

    }

    long serialized_cert_len;
    char* serialized_cert = SecurityManager::serializeCert(server_cert, serialized_cert_len, bio);
    ret = send(dataSocket, (const void*) serialized_cert, (size_t)serialized_cert_len, 0);
    if(ret != serialized_cert_len) {
        cerr<<"Couldn't send my certificate to a client. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    BIO_free(bio);
    X509_free(server_cert);


    //now send the Diffie Hellman parameters g,p (M6)
    //we use standard parameters, but in future releases we could use custom ones

    DH* params = DH_get_2048_224();

    //init context
    SecurityManager securityManager;
    //securityManager.initDHParams(params);

    //serialize parameters
    long ser_params_len;
    unsigned char* ser_params = (unsigned char *)SecurityManager::serializeDHParams(params, ser_params_len, bio);
    if(!ser_params || ser_params_len != DH_PARAMS_SIZE) {
        cerr<<"Could not serialize Diffie Hellman parameters. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }
    memcpy((void*)buffer, (const void*)ser_params, ser_params_len); //prepare the buffer

    BIO* dh_bio;
    DH* dh = securityManager.deserializeDHParams(ser_params, ser_params_len, dh_bio);
    if(!dh) {
        cerr<<"The DH params deserialized. Aborting..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    securityManager.initDHParams(dh, dh_bio);
    securityManager.generate_DH_privKey();

    //send Diffie Hellman parameters

    ret = send(
            currentUser->socket,
            (const void*)buffer,
            ser_params_len,
            0
    );

    BIO_free(bio);

    if(ret < ser_params_len) {
        cerr<<"Could not forward DH parameters to the client. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //get the serialized DH public key
    long dh_pubkey_len;
    unsigned char* serial_dh_pubkey = (unsigned char *)securityManager.getSerializedDH_pubkey(dh_pubkey_len);
    if(!serial_dh_pubkey) {
        cerr<<"Could not serialize the DH public key. Aborting...";
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }
    uint32_t dh_pubkey_len_std = dh_pubkey_len;


    //Receive client DH public key (M7)

    //first the length...
    uint32_t client_dh_pubkey_len;
    ret = recv(currentUser->socket, (void*)&client_dh_pubkey_len, sizeof(client_dh_pubkey_len), MSG_WAITALL);
    if(ret < sizeof(client_dh_pubkey_len) || client_dh_pubkey_len > 2048) {
        close(dataSocket);
        cerr<<"Could not receive client DH public key length. Returning to main menu..."<<endl;
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }


    //...and then we wait for the real dh key
    unsigned char* client_dh_pubkey = new unsigned char[client_dh_pubkey_len];
    ret = recv(currentUser->socket, (void*)client_dh_pubkey, client_dh_pubkey_len, MSG_WAITALL);
    if(ret <= 0) {
        close(dataSocket);
        cerr<<"Could not receive client DH public key. Returning to main menu..."<<endl;
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //initialize the digest used to verify client signature
    if(!security.digestInit()) {
        cerr<<"Could not init an hashing context. Aborting..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //Adding M7 to the digest
    if(!security.digestUpdate((const void *)&client_dh_pubkey_len, sizeof(uint32_t))) {
        cerr<<"Could not update the hashing context with client pubkey length. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    if(!security.digestUpdate((const void *)client_dh_pubkey, ret)) {
        cerr<<"Could not update the hashing context with client public key. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //adding my nonce to the digest
    if(!security.digestUpdate((const void *)NonceB, SecurityManager::NONCE_LENGTH)) {
        cerr<<"Could not update the hashing context with my nonce. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //Now the digest is ready to be finalized
    unsigned int client_digestLen;
    unsigned char* client_digest = (unsigned char*)security.digestFinal(client_digestLen);
    if(client_digest == NULL) {
        cerr<<"Could not finalize the digest for M7 and M8"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, currentUser->enc_key, user_pub);
        return false;
    }

    //Waiting for client signature (M7)
    int signature_length = EVP_PKEY_size(user_pub);

    ret = recv(dataSocket, (void*)buffer, signature_length, 0);
    if(ret < 256) { //minimum acceptable size
        cerr<<"Could not receive the signed digest from the client. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, currentUser->enc_key, user_pub);
        return false;
    }

    bool verified = SecurityManager::verifySignature(user_pub, buffer, ret, client_digest, client_digestLen);
    if(!verified) {
        cerr<<"The client signature was not correct. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, currentUser->enc_key, user_pub);
        return false;
    }

    //From now on the client is authenticated

    //Now we send the DH public key (length | pubkey) (M8)
    ret = send(currentUser->socket, (const void*)&dh_pubkey_len_std, sizeof(dh_pubkey_len_std), 0);
    if(ret < sizeof(dh_pubkey_len_std)) {
        cerr<<"Could not send your serialized DH public key length to the client. Aborting connection"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //and then the rest of the message
    ret = send(currentUser->socket, (const void*)serial_dh_pubkey, dh_pubkey_len, 0);
    if(ret < dh_pubkey_len) {
        cerr<<"Could not send your serialized DH public key to the client. Aborting connection"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //let's compute the digest to be signed
    //initialize the digest used to verify client signature
    if(!security.digestInit()) {
        cerr<<"Could not init an hashing context. Aborting..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //update the digest with M8:
    if(!security.digestUpdate((const void *)&dh_pubkey_len_std, sizeof(uint32_t))) {
        cerr<<"Could not update the hashing context with client DH pubkey length. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }
    if(!security.digestUpdate((const void *)serial_dh_pubkey, ret)) {
        cerr<<"Could not update the hashing context with client DH pubkey. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //add the client nonce to the digest
    if(!security.digestUpdate((const void *)NonceA, SecurityManager::NONCE_LENGTH)) {
        cerr<<"Could not update the hashing context with client nonce. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    digest = (unsigned char*)security.digestFinal(digestLen);
    if(digest == NULL) {
        cerr<<"Could not finalize the digest for M8"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, currentUser->enc_key, user_pub);
        return false;
    }

    //Sending signature to the client  (M8)
    digestSign = SecurityManager::signature(server_pkey,digest,digestLen,signLen);
    if(!digestSign) {
        cerr<<"Could not create the signature of the final digest"<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, currentUser->enc_key, user_pub);
        return false;
    }

    ret = send(dataSocket, digestSign, signLen, 0);
    if(ret < signLen) {
        cerr<<"Could not send the digest signature to the client. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, currentUser->enc_key, user_pub);
        return false;
    }


    //save client DH public key
    if(!securityManager.saveOpponentDH_pubkey(client_dh_pubkey, client_dh_pubkey_len)) {
        cerr<<"server public key format not acceptable. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    //Now we can derive the shared key
    ret = securityManager.deriveDH_SharedSecret();
    if(!ret) {
        cerr<<"Could not derive DH shared secret. Aborting connection..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    unsigned int symm_key_len = 0;
    void* symm_key = securityManager.getDH_SymmetricKey(symm_key_len);

    if( !symm_key || symm_key_len != SecurityManager::SYMMETRIC_KEY_LEN) {
        cerr<<"Could not derive the symmetric key. Aborting..."<<endl;
        close(dataSocket);
        cleanHeap(NonceB, premaster, digest, digestSign, NULL, user_pub);
        return false;
    }

    currentUser->enc_key = (unsigned char*) symm_key;
    currentUser->iv = (unsigned char*)securityManager.deriveIV(NonceA, NonceB);

    securityManager.DH_CTX_free();
    delete[] client_dh_pubkey;

    //we can delete the allocated space for nonces and premaster
    delete [] NonceB;
    delete [] premaster;
    NonceB = NULL;
    premaster = NULL;

    cout<<"a new user has been authenticated: "<<temp_username<<endl; //DEBUG

    //clean heap (not the enc_key and user public key)
    cleanHeap(NonceB, premaster, digest, digestSign, NULL, NULL);

    //update the list of active users
    activeUsersMutex.lock();
    this->activeUsers.insert(pair<string, user*> (currentUser->username, currentUser));
    activeUsersMutex.unlock();

    return true;
    /**********
     * End of Four Row Authentication Handshake
     **********/

}


void FourRowServer::cleanHeap(
            unsigned char* NonceB,
            unsigned char* premaster,
            unsigned char* digest,
            unsigned char* digestSign,
            unsigned char* enc_key,
            EVP_PKEY* user_pub
        ) {
    if(NonceB)
        delete [] NonceB;
    if(premaster)
        delete [] premaster;
    if(digest)
        delete [] digest;
    if(digestSign)
        delete [] digestSign;
    if(enc_key)
        delete [] enc_key;
    if(user_pub)
        EVP_PKEY_free(user_pub);
}






















