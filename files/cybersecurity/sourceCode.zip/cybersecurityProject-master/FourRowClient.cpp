//
// Created by baccios on 09/04/20.
//

#include "FourRowClient.h"
#include <string>
#include <iostream>
#include <unistd.h>

using namespace std;

const uint16_t CLIENT_DEFAULT_LISTENING_PORT = 3030;

FourRowClient::FourRowClient(const char* username, const char *servAddr, uint16_t servPort) {
    /*Assume parameters are already sanitized*/
    strcpy(this->serverAddress, servAddr);
    strcpy(this->username, username);
    this->serverPort = servPort;
    this->status = WAITING_INIT;
    this->seq_num = 0;

    opponent_key = NULL;
    oppo_pkey_bio = NULL;

    launch();
}

void FourRowClient::launch() {

    sockaddr_in sv_addr;
    /* Socket creation */
    this->servSock = socket(AF_INET, SOCK_STREAM, 0);

    /* Creating socket address */
    memset(&sv_addr, 0, sizeof(sv_addr));
    sv_addr.sin_family= AF_INET;
    sv_addr.sin_port= htons(this->serverPort);
    inet_pton(AF_INET, this->serverAddress, &sv_addr.sin_addr);

    //Connect to the server
    int ret = connect(this->servSock, (sockaddr*)&sv_addr, sizeof(sv_addr));
    if(ret != 0) {
        cerr<<"Couldn't connect with the server. Closing..."<<endl;
        exit(-1);
    }

    //From now on the client is connected with the server

    if(!performFRAH()) {
        cerr<<"Couldn't perform FRAH protocol"<<endl;
        exit(-1);
    }

    cout<<"Welcome "<<username<<"!"<<endl;

    do {}
    while(testStatusAndHandle() != -1);


}

bool FourRowClient::performFRAH() {


    //send nonce to the server

    int nonce_length = 0;
    unsigned char* nonce = (unsigned char*)securityManager.generateNonce(nonce_length);
    int ret = send(this->servSock, (const void*) nonce, nonce_length, 0);
    if(ret < nonce_length) {
        cerr<<"Error in sending the nonce to the server..closing"<<endl;
        this->status = QUITTING;
        close(this->servSock);
        return false;
    }


    //receive nonce from the server
    unsigned char nonce_received[securityManager.NONCE_LENGTH];

    ret = recv(this->servSock, (void*)nonce_received, securityManager.NONCE_LENGTH, MSG_WAITALL);
    if(ret<securityManager.NONCE_LENGTH){
        cerr<<"Error in receiving the nonce from the server"<<endl;
        this->status = QUITTING;
        close(this->servSock);
        return false;
    }


    //send the public key of the client to the server with the username of the client
    //sending to the server the username of the client with the public key of this client
    int messageLen = strlen(this->username) + 1;
    ret = send(this->servSock, (const void*) this->username, messageLen, 0);
    if(ret < messageLen) {
        this->status = QUITTING;
        cerr<<"Error in sending the username to the server"<<endl;
        close(this->servSock);
        return false;
    }


    //sending to the server the pubkey
    //reading public key from the file
    string s(this->username);
    s = "./pubKeys/"+s+".pem";
    EVP_PKEY* pubKey = securityManager.readPublicKey(s);
    if(!pubKey){
        this->status = QUITTING;
        cerr<<"Public key doesn't contain anything.."<<endl;
        close(this->servSock);
        return false;
    }

    long length = 0;
    BIO* bio;
    char* buffer = securityManager.serializeKey(pubKey,length,bio);

    ret = send(this->servSock, (const void*) buffer, length, 0);

    if(ret < length) {
        this->status = QUITTING;
        cerr<<"Error in sending the serialized pubKey"<<endl;
        close(this->servSock);
        return false;
    }

    BIO_free(bio);

    //receive server certificate and verify it
    unsigned char bufferForSerializedCertificate[SERVER_CERTIFICATE_MAX_SIZE];

    ret = recv(this->servSock, (void *) bufferForSerializedCertificate, SERVER_CERTIFICATE_MAX_SIZE, 0);
    if(ret<=0){
        this->status = QUITTING;
        cerr<<"Error in receiving the server certificate"<<endl;
        close(this->servSock);
        return false;
    }


    X509* serverCertificate = securityManager.deserializeCert(bufferForSerializedCertificate,ret,bio);
    if(!serverCertificate){
        cerr<<"Server certificate null"<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }
    X509* CAcert = securityManager.readCertificate("./certs/"+CA_CERTIFICATE_NAME);
    if(!CAcert){
        cerr<<"CAcert doesn't contain anything.."<<endl;
        this->status = QUITTING;
        close(this->servSock);
        return false;
    }
    X509_CRL* CAcrl = securityManager.readCRL("./certs/"+CA_CRL_NAME);
    if(!CAcrl){
        this->status = QUITTING;
        cerr<<"CAcrl doesn't contain anything.."<<endl;
        close(this->servSock);
        return false;
    }
    if(!securityManager.verifyCertificate(CAcert,CAcrl,serverCertificate)){
        cerr<<"securityManager.verifyCertificate returned false.."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }

    //extract server pubKey from the certificate
    EVP_PKEY* serverPubKey = X509_get_pubkey(serverCertificate);
    if(!serverPubKey){
        cerr<<"error in extracting the server public key from the certificate"<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }

    //wait for Diffie Hellman parameters (M6)
    int len = DH_PARAMS_SIZE;
    ret = recv(servSock, (void*)buffer, len, MSG_WAITALL);
    if(ret < len) {
        cerr<<"Could not receive DH parameters from the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }


    BIO* dh_bio;
    DH* dh = securityManager.deserializeDHParams((unsigned char*)buffer, ret, dh_bio);
    if(!dh) {
        cerr<<"The DH params received from the server could not be deserialized. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    securityManager.initDHParams(dh, dh_bio);

    //generate the private key
    securityManager.generate_DH_privKey();

    //get the serialized public key
    long dh_pubkey_len;
    unsigned char* serial_dh_pubkey = (unsigned char *)securityManager.getSerializedDH_pubkey(dh_pubkey_len);
    if(!serial_dh_pubkey) {
        cerr<<"Could not serialize the DH public key. Aborting...";
        this->status = QUITTING;
        return 1;
    }

    //Now we send the DH public key (length | pubkey) (M7)
    uint32_t dh_pubkey_len_std = dh_pubkey_len;
    ret = send(servSock, (const void*)&dh_pubkey_len_std, sizeof(dh_pubkey_len_std), 0);
    if(ret < sizeof(dh_pubkey_len_std)) {
        cerr<<"Could not send your serialized DH public key length to the server. Returning to mein menu"<<endl;
        this->status = QUITTING;
        return 1;
    }

    //and then the rest of the message
    ret = send(servSock, (const void*)serial_dh_pubkey, dh_pubkey_len, 0);
    if(ret < dh_pubkey_len) {
        cerr<<"Could not send your serialized DH public key to the opponent. Returning to mein menu"<<endl;
        close(servSock);
        this->status = GAME_OVER;
        return 1;
    }

    //Initialize the digest to be signed
    if(!securityManager.digestInit()) {
        cerr<<"Could not init an hashing context. Aborting..."<<endl;
        this->status = QUITTING;
        close(this->servSock);
        return false;
    }

    //update the digest with M7:
    if(!securityManager.digestUpdate((const void *)&dh_pubkey_len_std, sizeof(uint32_t))) {
        cerr<<"Could not update the hashing context with server pubkey len. Aborting connection..."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }
    if(!securityManager.digestUpdate((const void *)serial_dh_pubkey, ret)) {
        cerr<<"Could not update the hashing context with server pubkey. Aborting connection..."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }

    //update the digest with server nonce
    if(!securityManager.digestUpdate((const void *)nonce_received, SecurityManager::NONCE_LENGTH)) {
        cerr<<"Could not update the hashing context with server nonce. Aborting connection..."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }


    //finalize digest and send the signature of it to the server (M7)
    unsigned int digestLength = 0;
    unsigned char* digest = (unsigned char*)securityManager.digestFinal(digestLength);
    if(!digest){
        this->status = QUITTING;
        cerr<<"Error in finalizing the digest..."<<endl;
        close(this->servSock);
        return false;
    }

    //retrieve client privKey
    EVP_PKEY* myPrivKey = securityManager.readPrivateKey("./privKeys/priv_"+string(username)+".pem");
    if(!myPrivKey) {
        this->status = QUITTING;
        cerr<<"Could not load my private key. Aborting connection..."<<endl;
        close(this->servSock);
        return false;
    }

    priv_key = myPrivKey; //saving for future use

    int signatureLength = 0;
    unsigned char* signature = securityManager.signature(myPrivKey,digest,digestLength,signatureLength);
    ret = send(this->servSock, (const void*) signature, signatureLength, 0);
    if(ret < signatureLength) {
        cerr<<"Error in sending the digital signature to the server..closing"<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }


    //Now we wait for server DH pubkey (M8)

    uint32_t serv_dh_pubkey_len;
    ret = recv(servSock, (void*)&serv_dh_pubkey_len, sizeof(serv_dh_pubkey_len), MSG_WAITALL);
    if(ret < sizeof(serv_dh_pubkey_len) || serv_dh_pubkey_len > 2048) {
        close(servSock);
        cerr<<"Could not receive server DH public key length. Returning to main menu..."<<endl;
        this->status = QUITTING;
        return false;
    }

    //and then we wait for the real dh key
    unsigned char* server_dh_pubkey = new unsigned char[serv_dh_pubkey_len];
    ret = recv(servSock, (void*)server_dh_pubkey, serv_dh_pubkey_len, MSG_WAITALL);
    if(ret <= 0) {
        close(servSock);
        cerr<<"Could not receive server DH public key. Returning to main menu..."<<endl;
        this->status = QUITTING;
        return false;
    }

    //creating a new digest to verify server signature
    if(!securityManager.digestInit()) {
        cerr<<"Could not init an hashing context. Aborting..."<<endl;
        this->status = QUITTING;
        close(this->servSock);
        return false;
    }

    //Adding M8 to the digest
    if(!securityManager.digestUpdate((const void *)&serv_dh_pubkey_len, sizeof(uint32_t))) {
        cerr<<"Could not update the hashing context with g,p. Aborting connection..."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }
    if(!securityManager.digestUpdate((const void *)server_dh_pubkey, ret)) {
        cerr<<"Could not update the hashing context with g,p. Aborting connection..."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }
    //add my nonce to the digest
    if(!securityManager.digestUpdate((const void *)nonce, SecurityManager::NONCE_LENGTH)) {
        cerr<<"Could not update the hashing context with my nonce. Aborting connection..."<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }

    //finalize digest to confront with server signature
    unsigned int serv_digestLength = 0;
    unsigned char* serv_digest = (unsigned char*)securityManager.digestFinal(serv_digestLength);
    if(!serv_digest){
        this->status = QUITTING;
        cerr<<"Error in finalizing the server digest..."<<endl;
        close(this->servSock);
        return false;
    }


    //receiving the digital signature and verify if it is equal (M8)
    signatureLength = EVP_PKEY_size(serverPubKey);
    unsigned char* signatureReceived = new unsigned char[signatureLength];
    ret = recv(this->servSock, signatureReceived, signatureLength, 0);
    if(ret < signatureLength) {
        this->status = QUITTING;
        cerr<<"Error in receiving the digital signature from the server..closing"<<endl;
        close(this->servSock);
        return false;
    }
    if(!securityManager.verifySignature(serverPubKey,signatureReceived,signatureLength, serv_digest, serv_digestLength)){
        cerr<<"Error in verifying the signature received from the server"<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }

    //At this point server has been authenticated and the symmetric key can be derived

    //save server DH public key
    if(!securityManager.saveOpponentDH_pubkey(server_dh_pubkey, serv_dh_pubkey_len)) {
        cerr<<"server public key format not acceptable. Returning to main menu..."<<endl;
        unsigned int digestLen;
        securityManager.digestFinal(digestLen); //free the context
        this->status = QUITTING;
        return false;
    }

    //Now we can derive the shared key
    ret = securityManager.deriveDH_SharedSecret();
    if(!ret) {
        cerr<<"Could not derive DH shared secret. Aborting..."<<endl;
        this->status = QUITTING;
        return false;
    }

    unsigned int symm_key_len = 0;
    void* symm_key = securityManager.getDH_SymmetricKey(symm_key_len);

    if( !symm_key || symm_key_len != SecurityManager::SYMMETRIC_KEY_LEN) {
        cerr<<"Could not derive the symmetric key. Aborting..."<<endl;
        this->status = QUITTING;
        return false;
    }


    this->keyWithServer = (unsigned char*)symm_key;
    this->iv = (unsigned char*)securityManager.deriveIV(nonce, nonce_received);

    securityManager.DH_CTX_free();

    //if this point is reached, FRAH protocol was successful->return true
    //at this point, client can communicate with the server in a secure way using keyWithServer
    return true;
}

int FourRowClient::waitOrChallenge() {
    //SANITIZED
    cout<<"Do you want to challenge a user or just wait to be challenged?"<<endl;
    cout<<"type 0 to wait, 1 to challenge someone, 2 to log off from the server"<<endl;
    cout<<"> ";
    string decision;
    int numericDecision;
    bool goodDecision = false;
    while(!goodDecision)
    {
        getline(cin,decision);
        try{
            numericDecision = stoi(decision);
        }catch (exception &err){
            cerr << "You must answer with a number"<<endl;
            cout << "> ";
            goodDecision=false;
            continue;
        }
        if (!cin || (decision != "0" && decision != "1" && decision!="2")) {
            cout << "Please type a valid number"<<endl;
            cout << "> ";
            if(!cin) {
                cin.clear();
            }
        }
        else {
            goodDecision = true;
        }
    }
    cin.clear();
    if(numericDecision == 2) numericDecision =  -1;
    return numericDecision;

}


//returns the index of the user to be challenged
int FourRowClient::showAndPromptUsers() {

    if(activeUsersSize == 1) {
        cout<<"There are no other active users at the moment. Please try later"<<endl;
        return -1;
    }

    cout<<endl<<"Here\'s a list of active users. Choose one to challenge!"<<endl;
    for(int i = 0; i<activeUsersSize; ++i) {
        cout<<i+1<<") "<<activeUsers[i];
        if(strncmp(username, activeUsers[i], USERNAME_MAXSIZE) == 0) {
            cout<<" (you)";
        }
        cout<<endl;
    }
    cout<<"Type the user you want to challenge and press Enter > ";
    string input;
    //SANITIZED
    //char input[USERNAME_MAXSIZE];
    //cin.ignore(); //ignore last \n character
    while(true) {
        getline(cin,input);
        for(int i = 0; i<activeUsersSize; ++i) {
            if(strcmp(input.c_str(), this->username) == 0) { //user typed his own name
                break;
            }
            else if(strcmp(activeUsers[i], input.c_str()) == 0) {
                cout<<"Challenging "<<input<<endl;
                return i;
            }
            //p2p connection established
        }
        cout<<"The username you typed wasn't correct, please try again > ";
    }
    return -1;
}

//returns -1 in case of error
int FourRowClient::challenge(const char *user) {
    char message[USERNAME_MAXSIZE + 10]; //10 == strlen("challenge ")
    strcpy(message, "challenge ");
    strcat(message, user);

    int messageLen = strlen(message) + 1;
    int ret = securityManager.sendEncrypted(
            this->servSock,
            (const void*)message,
            messageLen,
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );
    if(ret < messageLen) {
        cerr<<"couldn't send the challenge properly. Aborting...";
        return -1;
    }
    return 0;
}

int FourRowClient::challengeReceived(const char *user){
    cout<<"You receive a challenge from "<<user<<endl;
    cout<<"Type 1 to accept, 0 otherwise > ";
    int numericResponse;
    string response;
    bool goodDecision = false;
    //SANITIZED
    while(!goodDecision)
    {
        getline(cin,response);
        try{
            numericResponse = stoi(response);
        }catch (exception &err){
            cerr << "You must answer with a number"<<endl;
            cout << "> ";
            goodDecision=false;
            continue;
        }
        if ((numericResponse != 0 && numericResponse != 1 ) || !cin) {
            cout << "Please type a valid number > ";
        }
        else {
            goodDecision = true;
        }
    }
    cin.clear();
    return numericResponse;
}

int FourRowClient::sendStatus(int decision){
    char stat[12];
    if(decision == 0) {
        strcpy(stat, "waiting");
    }
    else if (decision == 1) {
        strcpy(stat,"challenging");
    }
    else {
        strcpy(stat,"quit");
    }

    int statusLen = strlen(stat) + 1;
    int ret = SecurityManager::sendEncrypted(
            this->servSock,
            (const void*)
            stat,
            statusLen,
            keyWithServer,
            iv,
            this->seq_num++
            );
    if(ret < statusLen) {
        cerr<<"couldn't send the status properly. Aborting...";
        close(this->servSock);
        return -1;
    }
    return 0;
}


int FourRowClient::testStatusAndHandle() {

    int ret;

    switch(this->status) {
        case WAITING_INIT:
            ret = handleWAITING_INIT();
            break;
        case TO_BE_ASKED:
            ret = handleTO_BE_ASKED();
            break;
        case WAITING:
            ret = handleWAITING();
            break;
        case CHALLENGED:
            ret = handleCHALLENGED();
            break;
        case CHALLENGING:
            ret = handleCHALLENGING();
            break;
        case WAITING_RESPONSE:
            ret = handleWAITING_RESPONSE();
            break;
        case RESPONSE_ARRIVED:
            ret = handleRESPONSE_ARRIVED();
            break;
        case HANDSHAKE_CHALLENGER:
            ret = handleHANDSHAKE_CHALLENGER();
            break;
        case HANDSHAKE_CHALLENGED:
            ret = handleHANDSHAKE_CHALLENGED();
            break;
        case HANDSHAKE_PREPARATION:
            ret = handleHANDSHAKE_PREPARATION();
            break;
        case PLAYING:
            ret = handlePLAYING();
            break;
        case GAME_OVER:
            ret = handleGAME_OVER();
            break;
        case QUITTING:
            cout<<"Quitting the application"<<endl;
            close(this->servSock);
            ret = -1;
            break;
        default:
            ret = -1;
            break;
    }

    return ret;
}

int FourRowClient::handleWAITING_INIT() {
    if(!waitForInitialize())
        this->status = QUITTING;
    else
        this->status = TO_BE_ASKED;

    return 1;
}

int FourRowClient::handleTO_BE_ASKED() {

    //ask user what he/she wants to do
    int decision = waitOrChallenge();

    //tell the server the decision outcome ("waiting, "challenging" or "quit");
    sendStatus(decision);

    //update the user status
    this->status = (decision == 0) ? WAITING : (decision == 1) ? CHALLENGING : QUITTING;

    return 1;

}

int FourRowClient::handleCHALLENGING() {

    this->isChallenger = true;

    //receive from server list of active users
    char buffer[MAX_USERS_TO_SEND * USERNAME_MAXSIZE];
    int len = MAX_USERS_TO_SEND * USERNAME_MAXSIZE;
    int ret = securityManager.receiveDecrypted(
            this->servSock,
            (void*)buffer,
            len,
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );
    if(ret <= 0 || (ret % USERNAME_MAXSIZE != 0)) {
        cerr<<"error while reading or socket has been closed. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }
    this->activeUsersSize = ret / USERNAME_MAXSIZE;
    for(int i = 0; i<this->activeUsersSize; ++i) {
        //SANITIZING
        this->activeUsers[i][USERNAME_MAXSIZE-1]='\0';
        strcpy(this->activeUsers[i], buffer + i*USERNAME_MAXSIZE);
    }

    //Send a challenge request to the server. Format: "challenge $username"
    int challengedUser = showAndPromptUsers();
    if (challengedUser == -1) {
        this->status = QUITTING;
        return 1;
    }

    //here the user is challenging another user: "challenge $username"
    ret = challenge(activeUsers[challengedUser]);

    if (ret == -1) {
        //error during challenge
        this->status = QUITTING;
        return 1;
    }

    strcpy(opponent, activeUsers[challengedUser]); //save the opponent username

    this->status = WAITING_RESPONSE;

    return 1;

}

int FourRowClient::handleWAITING_RESPONSE() {
    int ret;

    cout<<"Waiting for a response by the challenged user..."<<endl;

    //waiting for the response to the challenge just sent
    char responseToSentChallenge[11];//ok->challenge accepted, ko-> challenge refused, initialize-> opponent is now offline
    int responseToSentChallengeLen = 11;

    ret = securityManager.receiveDecrypted(
            this->servSock,
            (void *) responseToSentChallenge,
            responseToSentChallengeLen,
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );
    responseToSentChallenge[10] = '\0';
    if (ret <= 1) {
        cerr << "error while receiving a response for the sent challenge. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    if(isInitializeMsg(responseToSentChallenge)) {
        cout<<"The user you challenged is now offline and cannot be challenged."<<endl;
        this->status = TO_BE_ASKED;
        return 1;
    }


    if (strcmp("ok", responseToSentChallenge) == 0) {
        this->status = RESPONSE_ARRIVED;
        return 1;
    }

    else if (strcmp("ko", responseToSentChallenge) == 0) {
        //challenge refused
        cout<<"The opponent refused your challenge."<<endl;
        this->status = WAITING_INIT;
        return 1;
    }

    else if (strcmp("error", responseToSentChallenge) == 0) {
        cout<< "The user that you want to challenge cannot receive challenges at the moment"<< endl;
        cout << "Try to challenge another user" << endl;
        this->status = WAITING_INIT;
        return 1;
    }

    //format error
    cerr << "wrong result message format. Aborting..." << endl;
    this->status = QUITTING;
    return 1;



}

int FourRowClient::handleRESPONSE_ARRIVED() {

    cout<<"The challenge has been accepted! Communicating our address to the opponent..."<<endl;

    //response arrived and challenge was accepted
    //preparing a new structure for p2p communication
    //and sending this structure to the server
    int p2pSocket = socket(AF_INET, SOCK_STREAM, 0);
    char address[16];
    uint16_t port = 0;
    sockaddr_in addrP2p;
    strcpy(address,"127.0.0.1");
    memset(&addrP2p, 0, sizeof(addrP2p));
    addrP2p.sin_family = AF_INET;
    addrP2p.sin_port = htons(port);
    inet_pton(AF_INET, address, &addrP2p.sin_addr);

    int ret = bind(p2pSocket, (sockaddr * ) & addrP2p, sizeof(addrP2p));
    if (ret != 0) {
        cerr << "Couldn't bind p2p socket. Closing..." << endl;
        this->status = QUITTING;
        return 1;

    }
    /*Setting the socket in listening mode for connections*/
    ret = listen(p2pSocket, 10);
    if (ret != 0) {
        cerr << "Couldn't set the socket in listening mode. Closing..." << endl;
        this->status = QUITTING;
        return 1;
    }

    socklen_t socklen = sizeof(addrP2p);
    if(getsockname(p2pSocket, (sockaddr *)&addrP2p, &socklen) == -1) {
        cerr<<"Could not retrieve the P2P listening address and port. Aborting...";
        this->status = QUITTING;
        return 1;
    }

    char cl_addr_str [INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(addrP2p.sin_addr), cl_addr_str, INET_ADDRSTRLEN);
    //cout<<"Sending to the server my IP address: "<<cl_addr_str<<endl; //DEBUG
    //cout<<"And port: "<<ntohs(addrP2p.sin_port)<<endl;

    ret = securityManager.sendEncrypted(
            this->servSock,
            (const void *) &addrP2p,
            sizeof(addrP2p),
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );
    if (ret < sizeof(addrP2p)) {
        cerr << "Error in sending the addrP2p. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    this->status = HANDSHAKE_PREPARATION;
    this->listeningSock = p2pSocket;
    return 1;

}

int FourRowClient::handleHANDSHAKE_PREPARATION() {

    int ret;
    int MAX_MSG_SIZE = SecurityManager::NONCE_LENGTH;
    MAX_MSG_SIZE += SERIAL_KEY_SIZE > DH_PARAMS_SIZE ? SERIAL_KEY_SIZE : DH_PARAMS_SIZE;
    unsigned char buffer[MAX_MSG_SIZE]; //utility buffer to store incoming messages
    unsigned char* msg = buffer;

    //generate the sequence number (nonce)
    int game_nonce_len;
    unsigned char *game_nonce = (unsigned char*)SecurityManager::generateNonce(game_nonce_len);

    if(!seq_num || game_nonce_len != SecurityManager::NONCE_LENGTH) {
        cerr<<"Could not generate sequence number. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }
    ret = SecurityManager::sendEncrypted(
                servSock,
                (const void*)game_nonce,
                game_nonce_len,
                keyWithServer,
                iv,
                this->seq_num++
            );
    if(ret < game_nonce_len) {
        cerr<<"Could not send the nonce to the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }
    this->myNonce = new unsigned char[game_nonce_len];
    memcpy((void*)myNonce,game_nonce,game_nonce_len);
    myNonceLength = game_nonce_len;

    //waiting for the message containing the address for p2p communication
    sockaddr_in playerAddress;
    int len = sizeof(playerAddress); //"initialize" is always shorter than sizeof(sockaddr_in)

    ret = securityManager.receiveDecrypted(
                this->servSock,
                (void *) buffer,
                len,
                this->keyWithServer,
                this->iv,
                this->seq_num++
            );

    //check if an initialize message arrived
    if(ret >= strlen("initialize") + 1) {
        if (isInitializeMsg((const char *) buffer)) {
            this->status = TO_BE_ASKED;
            return 1;
        }
    }

    if (ret < len) {
        cerr << "error while receiving the other player address. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    //copy the ip address in a sockaddr_in structure
    memcpy((void*)&playerAddress, (const void*) msg, sizeof(playerAddress));

    this->oppoAddr = playerAddress; //save the player address

    //now wait for the public key of the other user
    len = SERIAL_KEY_SIZE;
    ret = securityManager.receiveDecrypted(servSock, buffer, len, keyWithServer, iv, this->seq_num++);
    if(ret < len) {
        cerr<<"Could not receive the opponent public key from the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }


    BIO* pkey_bio;
    EVP_PKEY* oppo_key = securityManager.deserializeKey(msg, ret, pkey_bio);
    if(!oppo_key) {
        cerr<<"The key received from the server could not be deserialized. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    opponent_key = oppo_key;
    oppo_pkey_bio = pkey_bio;


    //now wait for the P2P IV, sent by the server
    len = ivLength;
    ret = securityManager.receiveDecrypted(servSock, buffer, len, keyWithServer, iv, this->seq_num++);
    if(ret < len) {
        cerr<<"Could not receive IV from the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }


    //save the iv received from the server
    memcpy((void*)this->iv_client, (const void*)msg, ivLength);


    //wait for Diffie Hellman parameters
    len = DH_PARAMS_SIZE;
    ret = securityManager.receiveDecrypted(servSock, buffer, len, keyWithServer, iv, this->seq_num++);
    if(ret < len) {
        cerr<<"Could not receive DH parameters from the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    BIO* dh_bio;
    DH* dh = securityManager.deserializeDHParams(msg, ret, dh_bio);
    if(!dh) {
        cerr<<"The DH params received from the server could not be deserialized. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    securityManager.initDHParams(dh, dh_bio);


    //waiting for other peer nonce
    len = SecurityManager::NONCE_LENGTH;
    ret = securityManager.receiveDecrypted(servSock, buffer, len, keyWithServer, iv, this->seq_num++);
    if(ret < len) {
        cerr<<"Could not receive the other peer nonce. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    /*
    //DEBUG
    cout<<endl<<"my nonce: ";
    for(int i = 0; i<SecurityManager::NONCE_LENGTH; ++i) {
        cout<<(int)(this->myNonce[i])<<" ";
    }
    cout<<endl;

    cout<<"other peer nonce: ";
    for(int i = 0; i<SecurityManager::NONCE_LENGTH; ++i) {
        cout<<(int)(buffer[i])<<" ";
    }
    cout<<endl<<endl;
    //DEBUG
     */

    this->opponentNonce = new unsigned char[SecurityManager::NONCE_LENGTH];
    memcpy((void*)this->opponentNonce, buffer, SecurityManager::NONCE_LENGTH);

    if(isChallenger)
        status = HANDSHAKE_CHALLENGER;
    else
        status = HANDSHAKE_CHALLENGED;
    return 1;
}

int FourRowClient::handleHANDSHAKE_CHALLENGER() {
    //accept connection from the other peer on the listening socket
    sockaddr_in opponent_addr;
    int opponent_addr_len = sizeof(opponent_addr);
    cout<<"Waiting for the opponent..."<<endl;
    int new_sock = accept(this->listeningSock, (sockaddr *) &opponent_addr, (socklen_t*)&opponent_addr_len);
    if (new_sock == -1) {
        cerr << "A problem occurred while accepting a connection from the opponent. Closing..." << endl;
        this->status = QUITTING;
        return 1;
    }
    this->gameSocket = new_sock;


    //first thing: check the IP address against the one provided by the server
    if(oppoAddr.sin_addr.s_addr != opponent_addr.sin_addr.s_addr) {
        char wrongAddr[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(oppoAddr.sin_addr), wrongAddr, INET_ADDRSTRLEN);
        cerr<<"Opponent ip address does not match the one provided by the server."<<endl;
        cerr<<"Expected: "<<wrongAddr<<endl;
        inet_ntop(AF_INET, &(opponent_addr.sin_addr), wrongAddr, INET_ADDRSTRLEN);
        cerr<<"Got: "<<wrongAddr<<endl;
        cerr<<"Aborting..."<<endl;

        this->status = QUITTING;
        return 1;
    }

    /*******************************
     * Begin Auth DHKE
     ******************************/

    //generate the private key
    securityManager.generate_DH_privKey();

    //get the serialized public key
    long dh_pubkey_len;
    unsigned char* serial_dh_pubkey = (unsigned char *)securityManager.getSerializedDH_pubkey(dh_pubkey_len);
    if(!serial_dh_pubkey) {
        cerr<<"Could not serialize the DH public key. Aborting...";
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    //creating message
    int signatureLength;



    //creating digest:my public key + other peer nonce
    unsigned int digestLen1;
    if(!securityManager.digestInit()) {
        cerr<<"Could not initialize digest context for DH auth"<<endl;
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    //update digest with my public key (along with its length)

    uint32_t dhLen_standard = dh_pubkey_len;
    if(!securityManager.digestUpdate((unsigned char*)&dhLen_standard, sizeof(dhLen_standard))) {
        cerr<<"Could not update final digest with my DH public key length"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }

    if(!securityManager.digestUpdate(serial_dh_pubkey, dh_pubkey_len)) {
        cerr<<"Could not update final digest with my DH public key"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    //update the digest with opponent nonce
    if(!securityManager.digestUpdate(this->opponentNonce, this->myNonceLength)) {
        cerr<<"Could not update final digest with the nonce"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    unsigned char* digest1 = (unsigned char *)securityManager.digestFinal(digestLen1);
    if(!digest1) {
        cerr << "Could not retrieve the final digest. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    unsigned char* signature = SecurityManager::signature(this->priv_key,digest1,digestLen1,signatureLength);

    unsigned char* finalMessage = new unsigned char[signatureLength+dh_pubkey_len];
    memcpy((void*)finalMessage,serial_dh_pubkey,dh_pubkey_len);
    memcpy((void*)(finalMessage+dh_pubkey_len),signature,signatureLength);

    //We wait for opponent serialized DH public key
    int dhKeyMaxLength = EVP_PKEY_size(this->opponent_key);

    //since it has variable length, we wait for an uint32_t with the key length:
    uint32_t oppo_dh_pubkey_len;
    int ret = recv(gameSocket, (void*)&oppo_dh_pubkey_len, sizeof(oppo_dh_pubkey_len), MSG_WAITALL);
    if(ret < sizeof(oppo_dh_pubkey_len) || oppo_dh_pubkey_len > 2048) {
        close(gameSocket);
        cerr<<"Could not receive opponent DH public key length. Returning to main menu..."<<endl;
        this->status = GAME_OVER;
        return 1;
    }

    //and then we wait for the real dh key
    unsigned char buffer[oppo_dh_pubkey_len+signatureLength];
    ret = recv(gameSocket, (void*)buffer, oppo_dh_pubkey_len+signatureLength, MSG_WAITALL);
    //cout<<"Expected: "<<dh_pubkey_len+signatureLength<<", received: "<<ret<<endl; //DEBUG
    if(ret <= 0) {
        close(gameSocket);
        cerr<<"Could not receive opponent DH public key. Returning to main menu..."<<endl;
        this->status = GAME_OVER;
        return 1;
    }
    //verify the signature
    unsigned char* signatureReceived = new unsigned char[signatureLength];
    unsigned char peer_dh_pubkey[oppo_dh_pubkey_len];

    memcpy((void*)peer_dh_pubkey,buffer,oppo_dh_pubkey_len);
    memcpy((void*)signatureReceived,(void*)(buffer+oppo_dh_pubkey_len),signatureLength);

    //creating digest: public key of other peer + my nonce
    unsigned int digestLen;
    if(!securityManager.digestInit()) {
        cerr<<"Could not initialize digest context for DH auth"<<endl;
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    if(!securityManager.saveOpponentDH_pubkey(peer_dh_pubkey, oppo_dh_pubkey_len)) {
        cerr<<"opponent public key format not acceptable. Returning to main menu..."<<endl;
        securityManager.digestFinal(digestLen); //free the context
        close(gameSocket);
        this->status = GAME_OVER;
        return 1;
    }
    //update digest with opponent public key
    if(!securityManager.digestUpdate((unsigned char*)&oppo_dh_pubkey_len, sizeof(oppo_dh_pubkey_len))) {
        cerr<<"Could not update final digest with opponent DH public key length"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }

    if(!securityManager.digestUpdate(peer_dh_pubkey, oppo_dh_pubkey_len)) {
        cerr<<"Could not update final digest with opponent DH public key"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    //update the digest with my nonce
    if(!securityManager.digestUpdate(myNonce, myNonceLength)) {
        cerr<<"Could not update final digest with the iv"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    unsigned char* digest = (unsigned char *)securityManager.digestFinal(digestLen);
    if(!digest) {
        cerr<<"Could not retrieve the final digest. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    /*
    //DEBUG
    cout<<"Expected digest: ";
    for(int i = 0; i<digestLen; ++i) {
        cout<<(int)(digest[i])<<" ";
    }
    cout<<endl;
    cout<<"received DH pubkey ("<<dh_pubkey_len<<" bytes): ";
    for(int i = 0; i<dh_pubkey_len; ++i) {
        cout<<(int)(peer_dh_pubkey[i])<<" ";
    }
    cout<<endl;
    //DEBUG
     */


    if(!securityManager.verifySignature(this->opponent_key,signatureReceived, signatureLength, digest, digestLen)){
        cerr<<"Error in verifying the signature received from the other peer"<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }

    //send the opponent this message (created before): pub_key_len, our public key, digitalSignature(public key+opponent nonce)

    //first we send the length of our public key
    uint32_t dh_pubkey_len_std = dh_pubkey_len;
    ret = send(gameSocket, (const void*)&dh_pubkey_len_std, sizeof(dh_pubkey_len_std), 0);
    if(ret < sizeof(dh_pubkey_len_std)) {
        cerr<<"Could not send your serialized DH public key length to the opponent. Returning to mein menu"<<endl;
        close(gameSocket);
        this->status = GAME_OVER;
        return 1;
    }

    //and then the rest of the message
    ret = send(gameSocket, (const void*)finalMessage, signatureLength+dh_pubkey_len, 0);
    if(ret < signatureLength+dh_pubkey_len) {
        cerr<<"Could not send your serialized DH public key to the opponent. Returning to main menu"<<endl;
        close(gameSocket);
        this->status = GAME_OVER;
        return 1;
    }


    if(!securityManager.deriveDH_SharedSecret()) {
        cerr<<"Could not derive the shared secret. Aborting..."<<endl;
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }


    unsigned int dh_key_len;
    unsigned char* p2p_key = (unsigned char *)securityManager.getDH_SymmetricKey(dh_key_len);
    if(dh_key_len < keyClientLen) {
        cerr<<"The generated DH key is too short. Aborting...";
        close(gameSocket);
        this->status = QUITTING;
    }

    keyWithClient = p2p_key;


    //free the opponent key by freeing the BIO
    BIO_free(oppo_pkey_bio);
    opponent_key = NULL;
    //free the DHKE context
    securityManager.DH_CTX_free();


    /******************************
     * End Auth DHKE
     *****************************/


    this->status = PLAYING;
    return 1;
}

int FourRowClient::handleHANDSHAKE_CHALLENGED() {

    /* Socket creation */
    this->gameSocket = socket(AF_INET, SOCK_STREAM, 0);

    //Connect to the other client
    int ret = connect(this->gameSocket, (sockaddr*)&oppoAddr, sizeof(oppoAddr));
    if(ret != 0) {
        cerr<<"Couldn't connect with the opponent. Closing..."<<endl;
        this->status = GAME_OVER;
        return 1;
    }

    /*******************************
     * Begin Auth DHKE
     ******************************/

    //generate the private key
    securityManager.generate_DH_privKey();

    //get the serialized public key
    long dh_pubkey_len;
    unsigned char* serial_dh_pubkey = (unsigned char *)securityManager.getSerializedDH_pubkey(dh_pubkey_len);
    uint32_t dh_pubkey_len_std = dh_pubkey_len;
    if(!serial_dh_pubkey) {
        cerr<<"Could not serialize the DH public key. Aborting...";
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    //send the opponent this message: our pubkey length, our public key, digitalSignature(public key+opponent nonce)

    int signatureLength;


    //creating digest: pubkey length + my public key + other peer nonce
    unsigned int digestLen1;
    if(!securityManager.digestInit()) {
        cerr<<"Could not initialize digest context for DH auth"<<endl;
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    //update digest with my public key length
    if(!securityManager.digestUpdate((unsigned char*)&dh_pubkey_len_std, sizeof(dh_pubkey_len_std))) {
        cerr<<"Could not update final digest with opponent DH public key length"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }

    //update digest with my public key
    if(!securityManager.digestUpdate(serial_dh_pubkey, dh_pubkey_len)) {
        cerr<<"Could not update final digest with opponent DH public key"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    //update the digest with opponent nonce
    if(!securityManager.digestUpdate(this->opponentNonce, this->myNonceLength)) {
        cerr<<"Could not update final digest with the iv"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    unsigned char* digest1 = (unsigned char *)securityManager.digestFinal(digestLen1);
    if(!digest1) {
        cerr << "Could not retrieve the final digest. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    unsigned char* signature = SecurityManager::signature(this->priv_key,digest1,digestLen1,signatureLength);

    unsigned char* finalMessage = new unsigned char[signatureLength+dh_pubkey_len];

    memcpy((void*)finalMessage,(const void*)serial_dh_pubkey,dh_pubkey_len);
    memcpy((void*)(finalMessage+dh_pubkey_len),(const void*)signature,signatureLength);

    /*
    //DEBUG
    cout<<"Sending signed digest: ";
    for(int i = 0; i<digestLen1; ++i) {
        cout<<(int)(digest1[i])<<" ";
    }
    cout<<endl;
    cout<<"for the following public key ("<<dh_pubkey_len<<" bytes): ";
    for(int i = 0; i<dh_pubkey_len; ++i) {
        cout<<(int)(serial_dh_pubkey[i])<<" ";
    }
    cout<<endl;
    //DEBUG
     */

    //send the length of the public key and then the key + signature
    ret = send(gameSocket, (const void*)&dh_pubkey_len_std, sizeof(dh_pubkey_len_std), 0);
    if(ret < sizeof(dh_pubkey_len_std)) {
        cerr<<"Could not send your serialized DH public key to the opponent. Returning to main menu"<<endl;
        close(gameSocket);
        this->status = GAME_OVER;
        return 1;
    }

    ret = send(gameSocket, (const void*)finalMessage, signatureLength+dh_pubkey_len, 0);
    if(ret < signatureLength+dh_pubkey_len) {
        cerr<<"Could not send your serialized DH public key to the opponent. Returning to main menu"<<endl;
        close(gameSocket);
        this->status = GAME_OVER;
        return 1;
    }

    //We wait for opponent serialized DH public key

    //first we wait for the key length
    uint32_t oppo_dh_pubkey_len;
    ret = recv(gameSocket, (void*)&oppo_dh_pubkey_len, sizeof(oppo_dh_pubkey_len), MSG_WAITALL);
    if(ret <= 0 || oppo_dh_pubkey_len > 2048) {
        close(gameSocket);
        cerr<<"Could not receive opponent DH public key length. Returning to main menu..."<<endl;
        this->status = GAME_OVER;
        return 1;
    }

    unsigned char buffer[oppo_dh_pubkey_len+signatureLength];
    ret = recv(gameSocket, (void*)buffer, oppo_dh_pubkey_len+signatureLength, MSG_WAITALL);
    if(ret <= 0) {
        close(gameSocket);
        cerr<<"Could not receive opponent DH public key. Returning to main menu..."<<endl;
        this->status = GAME_OVER;
        return 1;
    }
    //verify the signature
    unsigned char* signatureReceived = new unsigned char[signatureLength];
    unsigned char peer_dh_pubkey[dh_pubkey_len];

    memcpy((void*)peer_dh_pubkey,(const void*)buffer,oppo_dh_pubkey_len);
    memcpy((void*)signatureReceived,(void*)(buffer+oppo_dh_pubkey_len),signatureLength);

    //creating digest: public key of other peer + my nonce
    unsigned int digestLen;
    if(!securityManager.digestInit()) {
        cerr<<"Could not initialize digest context for DH auth"<<endl;
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    if(!securityManager.saveOpponentDH_pubkey(peer_dh_pubkey, dh_pubkey_len)) {
        cerr<<"opponent public key format not acceptable. Returning to main menu..."<<endl;
        securityManager.digestFinal(digestLen); //free the context
        close(gameSocket);
        this->status = GAME_OVER;
        return 1;
    }

    //update digest with opponent public key length
    if(!securityManager.digestUpdate((unsigned char*)&oppo_dh_pubkey_len, sizeof(oppo_dh_pubkey_len))) {
        cerr<<"Could not update final digest with opponent DH public key length"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }

    //update digest with opponent public key
    if(!securityManager.digestUpdate(peer_dh_pubkey, oppo_dh_pubkey_len)) {
        cerr<<"Could not update final digest with opponent DH public key"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    //update the digest with my nonce
    if(!securityManager.digestUpdate(myNonce, myNonceLength)) {
        cerr<<"Could not update final digest with the iv"<<endl;
        this->status = QUITTING;
        close(gameSocket);
        return 1;
    }
    unsigned char* digest = (unsigned char *)securityManager.digestFinal(digestLen);
    if(!digest) {
        cerr<<"Could not retrieve the final digest. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    if(!securityManager.verifySignature(this->opponent_key,signatureReceived, signatureLength, digest, digestLen)){
        cerr<<"Error in verifying the signature received from the other peer"<<endl;
        close(this->servSock);
        this->status = QUITTING;
        return false;
    }


    if(!securityManager.deriveDH_SharedSecret()) {
        cerr<<"Could not derive the shared secret. Aborting..."<<endl;
        securityManager.digestFinal(digestLen); //free the context
        close(gameSocket);
        this->status = QUITTING;
        return 1;
    }

    unsigned int dh_key_len;
    unsigned char* p2p_key = (unsigned char *)securityManager.getDH_SymmetricKey(dh_key_len);
    if(dh_key_len < keyClientLen) {
        cerr<<"The generated DH key is too short. Aborting...";
        securityManager.digestFinal(digestLen); //free the context
        close(gameSocket);
        this->status = QUITTING;
    }

    keyWithClient = p2p_key;

    //we can now use the BIO to free opponent public key
    BIO_free(oppo_pkey_bio);
    opponent_key = NULL;

    //free the DHKE context
    securityManager.DH_CTX_free();

    /******************************
     * End Auth DHKE
     *****************************/

    this->status = PLAYING;
    return 1;
}

int FourRowClient::handleWAITING() {
    int ret;

    cout<<"Waiting for someone to challenge you..."<<endl;

    this->isChallenger = false;

    //user is waiting for a challenge
    char challengeBuffer[13 + USERNAME_MAXSIZE]; // The longest string possible is "challengedBy $username"
    int challengeLen = 13 + USERNAME_MAXSIZE;
    //At this point we wait for a challenge
    ret = securityManager.receiveDecrypted(
            this->servSock,
            (void *) challengeBuffer,
            challengeLen,
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );
    if (ret <= 0) {
        cerr << "error while waiting for a challenge. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }
    challengeBuffer[challengeLen-1]='\0';

    if(isInitializeMsg(challengeBuffer)) { //timeout expired
        cout<<endl<<"Ops! Seems like no one challenged you. Try again if you want!"<<endl<<endl;
        this->status = TO_BE_ASKED;
        return 1;
    }

    //use strings to have useful methods
    string challengeMsg(challengeBuffer);

    //cout<<"challenge msg: "<<challengeBuffer<<endl; //DEBUG
    string delimiter = " ";
    string opcode = challengeMsg.substr(0, challengeMsg.find(delimiter));
    //cout<<"opcode: "<<opcode<<endl; //DEBUG
    if (opcode.compare("challengedBy") != 0) {
        cerr << "wrong format of challengedBy. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }
    string otherUser = challengeMsg.substr(challengeMsg.find(delimiter) + 1, challengeMsg.length());


    if (otherUser == "" || otherUser.length() >= USERNAME_MAXSIZE) { //format error
        cerr << "server did not send a correct challenge format" << endl;
        this->status = QUITTING;
        return 1;
    }

    this->status = CHALLENGED;
    strcpy(this->opponent, otherUser.c_str());
    return 1;
}

int FourRowClient::handleCHALLENGED() {

    //challenge received, ask the user if he wants to accept it or not
    int challengeAccepted = challengeReceived(this->opponent); //ask user how to respond to the challenge

    //creating the message response for the challenge
    char response[7 + USERNAME_MAXSIZE]; //"accept $username" or "refuse $username"
    int responseLen;
    if (challengeAccepted == 1) {
        strcpy(response, "accept ");
    } else {
        strcpy(response, "refuse ");
    }
    strcat(response, this->opponent);
    responseLen = strlen(response) + 1;
    //sending the response

    int ret = securityManager.sendEncrypted(
            this->servSock,
            (const void *) response,
            responseLen,
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );
    if (ret < responseLen) {
        cerr << "Error in sending the response. Aborting..." << endl;
        this->status = QUITTING;
        return 1;
    }

    if (challengeAccepted == 1) {
        this->status = HANDSHAKE_PREPARATION;
    }
    else {
        this->status = WAITING_INIT;
    }
    return 1;
}


int FourRowClient::handlePLAYING() {

    //first of all reset p2p sequence number:
    this->p2p_seq_num = 0;

    field = new PlayField();
    int i = 0;
    if(isChallenger) {
        //cout<<"Hello, I am the challenger and I am playing!"<<endl; //DEBUG
        while(field->playing) {
            //challenging Player -> waits for the first move of the adversary
            field->print();
            int res;
            cout << "Waiting for the move of the adversary...." << endl;
            res = receiveMove();
            if (res < 0) {
                cerr << "received an invalid column. Aborting..." << endl;
                close(gameSocket);
                this->status=GAME_OVER;
                return 1;
            } else {
                if (res == 0) {
                    //keep playing
                    field->print();
                    res = sendMove();
                    if (res < 0) {
                        cerr << "error in sending the column. Aborting..." << endl;
                        close(gameSocket);
                        this->status=GAME_OVER;
                        return 1;
                    }
                }
            }
        }
    }else{
        //cout<<"Hello, I am the challenged user and I am playing!"<<endl; //DEBUG
        while(field->playing) {
            field->print();
            //the waiting player starts the game
            int res;
            res = sendMove();
            if (res < 0) {
                cerr << "error in sending the column. Aborting..." << endl;
                close(gameSocket);
                this->status=GAME_OVER;
                return 1;
            } else {
                if (res == 0) {
                    if (field->playing) {
                        //keep playing
                        field->print();
                        cout << "Waiting for the move of the adversary...." << endl;
                        int result = receiveMove();
                        if (result < 0) {
                            cerr << "error in receivings..." << endl;
                            close(gameSocket);
                            this->status=GAME_OVER;
                            return 1;
                        }
                    }
                }
            }
        }
    }
    field->print();
    delete field;
    this->status = GAME_OVER;
    return 1;

}

int FourRowClient::checkInputColumn(){
    //SANITIZED
    int numericColumn;
    string column;
    bool goodDecision = false;
    cout<<"In which column do you want to insert the token?"<<endl;
    cout<<"> ";
    while(!goodDecision)
    {
        getline(cin,column);
        try{
            numericColumn = stoi(column);
        }catch (exception &err){
            cerr << "You must answer with a number"<<endl;
            cout << "> ";
            goodDecision=false;
            continue;
        }
        if(!cin){
            cout << "Please type a valid column"<<endl;
            cout << "> ";
            continue;
        }
        if (field->insertToken(numericColumn, playerSymbol1) >= 0){
            goodDecision = true;
        }
    }
    return numericColumn;

}

int FourRowClient::sendMove(){
    int column = checkInputColumn();

    char columnMessage[10];//10==strlen(column: $column)+1
    strcpy(columnMessage, "column: ");
    strcat(columnMessage, to_string(column).c_str());

    int columnMessageLength = strlen(columnMessage) + 1;
    int ret = SecurityManager::sendEncrypted(
            gameSocket,
            (const void*) columnMessage,
            columnMessageLength,
            this->keyWithClient,
            this->iv_client,
            this->p2p_seq_num++
            );
    if (ret < columnMessageLength) {
        cerr << "Error in sending the column Message. Aborting..." << endl;
        close(gameSocket);
        return -1;
    }
    return 0;
}

int FourRowClient::receiveMove(){
    char columnMessage[10]; // The longest string possible is "column: $column"
    int columnMessageLength = 10;
    int ret = SecurityManager::receiveDecrypted(
            gameSocket,
            (void *) columnMessage,
            columnMessageLength,
            this->keyWithClient,
            this->iv_client,
            this->p2p_seq_num++
            );
    columnMessage[columnMessageLength-1]='\0';
    if (ret < columnMessageLength) {
        cerr << "error while receiving the move from the adversary for a challenge. Aborting..." << endl;
        close(gameSocket);
        return -1;
    }
    string columnMsg(columnMessage);
    //cout<<"column Msg: "<<columnMessage<<endl;//DEBUG
    string delimiter = " ";
    string firstWord = columnMsg.substr(0,columnMsg.find(delimiter));
    if(firstWord.compare("column:")!=0){
        cerr<<"wrong column message format. Aborting connection..."<<endl;
        close(gameSocket);
        return -1;
    }
    int column = stoi(columnMsg.substr(columnMsg.find(delimiter)+1, columnMsg.size()));
    return field->insertToken(column, playerSymbol2);
}


int FourRowClient::handleGAME_OVER() {

    //close all p2p connections
    if(isChallenger) {
        close(listeningSock);
    }
    close(gameSocket);

    //the game is over and server must be notified
    const char* gameOverMsg = "game over";
    int len = strlen(gameOverMsg) + 1;
    int ret = securityManager.sendEncrypted(
            this->servSock,
            (const void*)gameOverMsg,
            len,
            this->keyWithServer,
            this->iv,
            this->seq_num++
            );

    if(ret < len) {
        cerr<<"couldn't send game over message to the server. Aborting..."<<endl;
        this->status = QUITTING;
        return 1;
    }

    this->status = WAITING_INIT; //server always sends an init message after a game ends
    return 1;

}


bool FourRowClient::isInitializeMsg(const char* msg) {
    return (strncmp(msg, "initialize",strlen("initialize")+1) == 0);
}

bool FourRowClient::waitForInitialize() {
    //cout<<"hello, I am waiting for init message"<<endl; //DEBUG
    char initMsg[11];
    int  initLen = 11;
    int ret = SecurityManager::receiveDecrypted(
            this->servSock,
            (void*)initMsg,
            initLen,
            keyWithServer,
            iv,
            this->seq_num++
            );
    initMsg[initLen-1]='\0';
    if(ret < 11)
        return false;
    return !strcmp("initialize", initMsg);
}




























