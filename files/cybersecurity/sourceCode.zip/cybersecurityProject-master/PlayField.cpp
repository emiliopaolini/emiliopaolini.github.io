//
// Created by emilio on 20/06/20.
//

#include "PlayField.h"
#include <iostream>
#include "color.h"
using namespace std;

PlayField::PlayField() {
    playing = true;
    for(int i = 0; i < NROWS; i ++) {
        for(int j = 0; j < NCOLUMNS; j ++) {
            playField[i][j] = ' ';
        }
    }
}
void PlayField::print(){
    for(int i = 0; i < NROWS; i ++) {
        for(int j = 0; j < NCOLUMNS; j ++) {
            cout<<BOLDGREEN<<"|"<<RESET<<" "<<BOLDRED<<playField[i][j]<<" "<<RESET;
        }
        cout<<BOLDGREEN<<"|"<<endl<<RESET;

    }
    for(int i = 0; i < NCOLUMNS; i ++) {
        cout<<BOLDBLUE<<"  "<<i<<" "<<RESET;
    }
    cout<<endl;
}

bool PlayField::isColumnFull(int column){
    return playField[0][column] != ' ';
}

int PlayField::insertToken(int column,char playerSymbol){
    if(column >= NCOLUMNS || column < 0) {
        cout<<"The column doesn't exist"<<endl;
        cout<<"Choose another column > ";
        return -1;
    }
    if(isColumnFull(column)) {
        cout<<"Cannot insert the token since the column is full!"<<endl;
        cout<<"Choose another column > ";
        return -1;
    }
    for(int i = NROWS-1; i >= 0; i --) {
        if( playField[i][column] == ' ') {
            playField[i][column] = playerSymbol;
            if(checkField(i, column, playerSymbol)){
                cout<<"Partita finita"<<endl;
                playing = false;
                return 1;
            }
            return 0;
        }
    }
    return -1;
}

bool PlayField::checkField(int row,int column,char playerSymbol) {
    //check for a win

    //check for a win horizontally
    for(int i=0; i < NROWS; i++){

        for(int j=0; j < NCOLUMNS - 3; j++){
            if(playField[i][j] != ' ' && playField[i][j]== playField[i][j+1] &&
               playField[i][j]== playField[i][j+2] && playField[i][j]== playField[i][j+3]) {
                if(playerSymbol1 == playerSymbol){
                    cout<<"VINTO"<<endl;
                } else {
                    cout<<"PERSO"<<endl;
                }
                return true;
            }

        }
    }

    //check for a win vertically
    for(int j=0; j < NCOLUMNS ; j++){
        for(int i=0; i < NROWS - 3; i++){
            if(playField[i][j] != ' ' && playField[i][j]== playField[i+1][j] &&
               playField[i][j]== playField[i+2][j] && playField[i][j]== playField[i+3][j]) {
                if(playerSymbol1 == playerSymbol){
                    cout<<"VINTO"<<endl;
                } else {
                    cout<<"PERSO"<<endl;
                }
                return true;
            }

        }
    }

    //check for a win diagonally
    for(int i=0;i<NROWS-3;i++) {
        for (int j = 0; j < NCOLUMNS - 3; j++) {
            if (playField[i][j] != ' ' && playField[i][j] == playField[i + 1][j + 1] &&
                playField[i][j] == playField[i + 2][j + 2] && playField[i][j] == playField[i + 3][j + 3]) {
                if (playerSymbol1 == playerSymbol) {
                    cout << "VINTO" << endl;
                } else {
                    cout << "PERSO" << endl;
                }
                return true;
            }
        }
    }
    for(int i=0;i<NROWS-3;i++) {
        for (int j = 3; j < NCOLUMNS ; j++) {
            if (playField[i][j] != ' ' && playField[i][j] == playField[i + 1][j - 1] &&
                playField[i][j] == playField[i + 2][j - 2] && playField[i][j] == playField[i + 3][j - 3]) {
                if (playerSymbol1 == playerSymbol) {
                    cout << "VINTO" << endl;
                } else {
                    cout << "PERSO" << endl;
                }
                return true;
            }
        }
    }

    return false;
}