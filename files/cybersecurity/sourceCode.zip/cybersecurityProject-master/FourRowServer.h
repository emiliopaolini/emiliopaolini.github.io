//
// Created by baccios on 20/06/20.
//

#ifndef CYBERSECURITYPROJECT_NEWFOURROWSERVER_H
#define CYBERSECURITYPROJECT_NEWFOURROWSERVER_H


#include <sys/types.h>
#include <sys/param.h>
#include <unistd.h>
#include <map>
#include <string>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include "user.h"
#include "SecurityManager.h"
#include "constants.h"

using namespace std;
/*
 * This class implements the server of the application.
*/
class FourRowServer {

private:

    static EVP_PKEY* server_pkey;
    static mutex* privkey_mtx;

    //port and listening IP address, in dotted notation (e.g. 192.168.1.1)
    char address[16];
    uint16_t port;
    int listeningSocket;

    //registered users
    vector<user> *users;

    //active users (map to retrieve them faster (O(logn)))
    map<string, user*> activeUsers;
    mutex activeUsersMutex;

    /*Put the server online and listening for connections, automatically called by the constructor*/
    void launch();
    /*Handle a connection through a data listeningSocket*/
    void handleConnection(int dataSocket, sockaddr_in cl_addr);

    /*called in an infinite while loop inside "handleConnection" after the user is correctly logged in*/
    int testStatusAndHandle(user* currentUser, sockaddr_in &cl_addr);

    /*
     * SECURITY METHODS
     */
    EVP_PKEY* loadPublicKey(const char* username);


    /*
     * UTILITY HANDLERS
     */
    int handleTO_BE_ASKED(user* currentUser);
    int handleWAITING(user* currentUser, unique_lock<mutex>& lock);
    int handleCHALLENGED(user* currentUser);
    int handleCHALLENGING(user* currentUser, sockaddr_in &cl_addr);
    int handleWAITING_RESPONSE(user* currentUser, unique_lock<mutex>& lock);
    int handleRESPONSE_ARRIVED(user* currentUser);
    int handleWAITING_FOR_P2P_ADDRESS(user* currentUser, unique_lock<mutex>& lock);
    int handleHANDSHAKE_PREPARATION(user* currentUser);
    int handlePLAYING(user* currentUser);

    //set a timeout on a waiting user
    void setTimeout();

    //check if a user is online by its username and if so save a reference in dest
    bool isOnline(const char* username, user* &dest);

    //get the server private key
    static EVP_PKEY* get_privkey();

    //clean heap in case of errors during FRAH
    static void cleanHeap(unsigned char* NonceB, unsigned char* premaster, unsigned char* digest,
            unsigned char* digestSign, unsigned char* enc_key, EVP_PKEY* user_pub);

    /*
     * UTILITY INLINE METHODS
     */

    /*Close the user socket and log him/her out in thread safe mode. Optional parameter is an eventual user whose connection to be reinitialized*/
    int closeAndLogOut(user* usr, user* toBeInitialized = NULL);

public:
    //The constructor initializes the server and opens a listening listeningSocket
    FourRowServer(const char* addr, uint16_t port, const char *userFileNam);

    /**************
     * Security interface
     **************/

    /**
     * perform the Four Row Authentication Handshake, server side.
     * @param dataSocket the socket on which the method can send and receive data
     * @param username output parameter where is saved the client username
     * @param symmetric_key output parameter containing a pointer to the symmetric key data stream
     * @return true if the user was authenticated
     */
    bool performFRAH(int dataSocket, user* &currentUser, unsigned char* &symmetric_key);
};


#endif //CYBERSECURITYPROJECT_NEWFOURROWSERVER_H
