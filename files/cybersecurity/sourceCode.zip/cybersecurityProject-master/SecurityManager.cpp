//
// Created by emilio on 29/06/20.
//

#include "SecurityManager.h"
#include "constants.h"
#include <iostream>
#include <cstring>
#include <sys/socket.h>

using namespace std;

bool SecurityManager::PRNG_seeded = false;
const EVP_CIPHER* const SecurityManager::DIGITAL_ENVELOP_CIPHER = EVP_aes_256_cbc();
const EVP_CIPHER* const SecurityManager::SYMMETRIC_CIPHER = EVP_aes_256_gcm();



void* SecurityManager::hash(const void * buffer, int length, unsigned int& len) {
    int ret;

    EVP_MD_CTX* ctx;
    unsigned char* hash = new unsigned char[32];
    unsigned int digestLen;

    ctx = EVP_MD_CTX_new();

    ret = EVP_DigestInit(ctx, EVP_sha256());
    if(!ret) {
        cerr<<"Couldn't initialize digest. returning NULL pointer"<<endl; //DEBUG
        return NULL;
    }
    ret = EVP_DigestUpdate(ctx, (unsigned char*) buffer, length);
    if(!ret) {
        cerr<<"Couldn't update digest. returning NULL pointer"<<endl; //DEBUG
        return NULL;
    }
    ret = EVP_DigestFinal(ctx, hash, &digestLen);
    if(!ret) {
        cerr<<"Couldn't finalize digest. returning NULL pointer"<<endl; //DEBUG
        return NULL;
    }

    EVP_MD_CTX_free(ctx);

    len = digestLen;
    return (void*) hash;

}


bool SecurityManager::digestInit() {
    hash_ctx = EVP_MD_CTX_new();
    return  EVP_DigestInit(hash_ctx, EVP_sha256());
}

bool SecurityManager::digestUpdate(const void *buffer, int length) {
    return EVP_DigestUpdate(hash_ctx, (unsigned char *)buffer, length);
}

void* SecurityManager::digestFinal(unsigned int &len) {

    int ret = EVP_DigestFinal(hash_ctx, digest, &len);
    unsigned char * result;
    if(ret) {
        result = new unsigned char[32];
        memcpy(result,digest,32);
    } else
        result = NULL;

    EVP_MD_CTX_free(hash_ctx);

    return (void*)result;

}

void* SecurityManager::generateKey(void* nonceClient, void* nonceServer, int nonceLen, void* premaster, int premasterLen, int& len) {

    const int DERIVED_KEY_LEN = 48; //256 + 128 bits (symmetric key and IV)
    size_t key_length = DERIVED_KEY_LEN;

    unsigned char* derived = new unsigned char[DERIVED_KEY_LEN]; //256 + 128 bits (symmetric key and IV)

    EVP_PKEY_CTX *kctx = EVP_PKEY_CTX_new_id(EVP_PKEY_HKDF, NULL);
    if (kctx == NULL) {
        cerr<<"Couldn't allocate a kdf context"<<endl;
        return NULL;
    }


    if (EVP_PKEY_derive_init(kctx) <= 0){
        cerr<<"error in derive init"<<endl;
        return NULL;
    }

    //Define the hash function to use
    if(EVP_PKEY_CTX_set_hkdf_md(kctx, EVP_sha256()) <= 0) {
        cerr<<"Couldn't define kdf hash function"<<endl;
        return NULL;
    }

    //Define the nonce (salt) used in kdf algorithm. In our case it's NA XOR NB
    unsigned char* salt = new unsigned char[nonceLen];
    for(int i = 0; i<nonceLen; ++i) {
        salt[i] = ((unsigned char*) nonceClient)[i] ^ ((unsigned char*) nonceServer)[i];
    }

    if(EVP_PKEY_CTX_set1_hkdf_salt(kctx, salt, nonceLen) <= 0) {
        cerr<<"Couldn't define kdf salt"<<endl;
        return NULL;
    }

    delete[] salt;

    //Define the key material from which derive the key (pre master secret)
    if(EVP_PKEY_CTX_set1_hkdf_key(kctx, (unsigned char *)premaster, premasterLen) <= 0) {
        cerr<<"Couldn't define kdf secret"<<endl;
        return NULL;
    }

    //Define the info in kdf context
    const unsigned char * info = (const unsigned char *)"pre master secret";
    int infoLen = strlen((const char *)info) + 1;
    if(EVP_PKEY_CTX_add1_hkdf_info(kctx, info, infoLen) <= 0) {
        cerr<<"Couldn't define kdf info"<<endl;
        return NULL;
    }

    /* Do the derivation */
    if (EVP_PKEY_derive(kctx, derived, &key_length) <= 0) {
        cerr<<"Couldn't generate the symmetric key"<<endl;
        return NULL;
    }
    len = key_length;
    EVP_PKEY_CTX_free(kctx);

    return derived;
}

void* SecurityManager::randomStream(const int length) {
    if (!PRNG_seeded)
    {
        RAND_poll();
        PRNG_seeded = true;
    }

    unsigned char* ret = new unsigned char[length] ;
    RAND_bytes(ret,length);
    return (void*)ret;

}

void* SecurityManager::generateNonce(int& len){
    len = NONCE_LENGTH;
    return randomStream(NONCE_LENGTH);
}

void* SecurityManager::generateIV(int& len){
    len = EVP_CIPHER_iv_length(SYMMETRIC_CIPHER);
    return randomStream(len);
}

void* SecurityManager::generatePreMasterSecret(int& len) {
    len = PREMASTER_LENGTH;
    return randomStream(PREMASTER_LENGTH);
}

void* SecurityManager::RSA_encrypt(const void* plaintext, int plainLen, EVP_PKEY* key, unsigned char* &encrypted_symmetric_key, int &enc_sym_key_len,  unsigned char* &iv, int& len, EVP_CIPHER_CTX* &ctx){
    //utility variables
    const EVP_CIPHER* cipher = DIGITAL_ENVELOP_CIPHER;
    encrypted_symmetric_key = NULL;
    int encrypted_key_len = EVP_PKEY_size(key);

    // context
    ctx = EVP_CIPHER_CTX_new();
    if(!ctx){
        cerr << "Error: EVP_CIPHER_CTX_new returned NULL"<<endl;
        return 0;
    }

    encrypted_symmetric_key = (unsigned char*)malloc(encrypted_key_len);
    iv = (unsigned char*)malloc(EVP_CIPHER_iv_length(cipher));
    if(!encrypted_symmetric_key || !iv) {
        cerr << "Error: malloc returned NULL "<<endl;
        return 0;
    }

    //buffer for ciphertext
    unsigned char* ciphertext = new unsigned char[plainLen+16];
    //encryption
    int ret = EVP_SealInit(ctx, cipher, &encrypted_symmetric_key, &enc_sym_key_len, iv, &key, 1);
    if(ret<=0){
        cerr<<"Error in EVP_SealInit"<<endl;
        return 0;
    }
    int bytesEncryptedAtEachChunk = 0;
    int totalEncryptedBytes = 0;
    ret = EVP_SealUpdate(ctx, ciphertext, &bytesEncryptedAtEachChunk,(unsigned char*)plaintext, plainLen);
    if(ret == 0){
        cerr << "Error in EVP_SealUpdate "<<endl;
        return 0;
    }
    totalEncryptedBytes += bytesEncryptedAtEachChunk;
    ret = EVP_SealFinal(ctx, ciphertext + totalEncryptedBytes, &bytesEncryptedAtEachChunk);
    if(ret == 0){
        cerr << "Error in EVP_SealFinal returned " <<endl;
        return 0;
    }
    totalEncryptedBytes += bytesEncryptedAtEachChunk;
    len = totalEncryptedBytes;

    return (void*)ciphertext;
}

void* SecurityManager::RSA_decrypt(const void* ciphertext, int cipherLen, EVP_PKEY* key, unsigned char* encrypted_symmetric_key, int enc_sym_key_len, unsigned char* iv, int& len, EVP_CIPHER_CTX* &ctx){

    const EVP_CIPHER* cipher = DIGITAL_ENVELOP_CIPHER;

    ctx = EVP_CIPHER_CTX_new();
    if(!ctx){
        cerr<<"Error in initializing ctx"<<endl;
        return 0;
    }

    int ret = EVP_OpenInit(ctx, cipher, encrypted_symmetric_key, enc_sym_key_len, iv, key);
    if(ret==0){
        cerr<<"Error in OpenInit"<<endl;
        return 0;
    }

    int nd = 0; // bytes decrypted at each chunk
    int ndtot = 0; // total decrypted bytes



    //buffer for decrypted message
    unsigned char* clear_buf = new unsigned char[cipherLen];

    ret = EVP_OpenUpdate(ctx, clear_buf, &nd, (unsigned char*)ciphertext, cipherLen);
    if(ret==0){
        cerr<<"Error in OpenUpdate"<<endl;
        return 0;
    }
    ndtot += nd;

    ret = EVP_OpenFinal(ctx, clear_buf + ndtot, &nd);
    if(ret == 0){
        cout<<"Error in OpenFinal"<<endl;
        return 0;
    }
    ndtot += nd;
    len = ndtot;

    return (void*)clear_buf;
}

void* SecurityManager::generateDigEnvelope(const void* plaintext, int plainLen, EVP_PKEY* key, int &len) {
    unsigned char* iv;
    int iv_len = EVP_CIPHER_iv_length(DIGITAL_ENVELOP_CIPHER);
    int symmetric_key_len;
    unsigned char* symmetric_key;
    int ciphertext_len;
    unsigned char* ciphertext;
    EVP_CIPHER_CTX *enc_ctx;

    //generating all the parts of the envelope
    ciphertext = (unsigned char*)RSA_encrypt(plaintext, plainLen, key, symmetric_key, symmetric_key_len, iv, ciphertext_len, enc_ctx);
    if(!ciphertext) {
        cerr<<"could not generate envelope for internal errors"<<endl;
        if(enc_ctx)
            EVP_CIPHER_CTX_free(enc_ctx);
        if(symmetric_key)
            free(symmetric_key);
        return NULL;
    }

    //Envelope: (IV, key_size, encrypted_key, encrypted_message)
    len = iv_len + ciphertext_len + symmetric_key_len + 2;
    unsigned char* envelope = new unsigned char[len];

    memcpy((void*)envelope, (const void *) iv, iv_len);
    memcpy((void*)(envelope + iv_len), (const void *) &symmetric_key_len, 2); //two bytes is enough
    memcpy((void*)(envelope + iv_len + 2), (const void *) symmetric_key, symmetric_key_len);
    memcpy((void*)(envelope + iv_len + 2 + symmetric_key_len), (const void *) ciphertext, ciphertext_len);


    EVP_CIPHER_CTX_free(enc_ctx);
    free(symmetric_key);
    return envelope;
}

void* SecurityManager::decryptDigEnvelope(const void* envelope, int envLen, EVP_PKEY* key, int &len) {
    int iv_len = EVP_CIPHER_iv_length(DIGITAL_ENVELOP_CIPHER);

    if(envLen < iv_len + 4) { //minimum size
        return NULL;
    }

    unsigned char* iv = (unsigned char *)envelope;
    unsigned int symmetric_key_len = *(uint16_t *)((unsigned char *)envelope + iv_len); //SANITIZED

    int ciphertext_len = envLen - 2 - iv_len - symmetric_key_len;
    unsigned char* symmetric_key = (unsigned char *)envelope + iv_len + 2;
    if(ciphertext_len <= 0 || ciphertext_len % EVP_CIPHER_block_size(DIGITAL_ENVELOP_CIPHER) != 0) {
        cerr<<"ciphertext format is not valid"<<endl;
        return NULL;
    }

    unsigned char* ciphertext = (unsigned char *)envelope + iv_len + 2 + symmetric_key_len;


    //At this point we can decrypt the message
    EVP_CIPHER_CTX* dec_ctx;
    unsigned char* plaintext =
            (unsigned char *)RSA_decrypt(
                ciphertext,
                ciphertext_len,
                key,
                symmetric_key,
                symmetric_key_len,
                iv,
                len,
                dec_ctx
            );
    if(dec_ctx)
        EVP_CIPHER_CTX_free(dec_ctx);
    return plaintext;
}

EVP_PKEY* SecurityManager::readPublicKey(string fileName) {
    if(!checkWhitelist(fileName)){
        cerr<<"The name contains not admitted char"<<endl;
        return NULL;
    }
    FILE* pubkey_file = fopen(fileName.c_str(), "r");
    if(!pubkey_file){
        cerr << "Error in reading public key file.."<<endl;
        return 0;
    }
    EVP_PKEY* pubkey = PEM_read_PUBKEY(pubkey_file, NULL, NULL, NULL);
    fclose(pubkey_file);
    if(!pubkey){
        cerr << "Error in reading the public key from the file"<<endl;
        return 0;
    }
    return pubkey;
}

EVP_PKEY* SecurityManager::readPrivateKey(string fileName,void* password) {

    if(!checkWhitelist(fileName)){
        cerr<<"The name contains not admitted char"<<endl;
        return NULL;
    }
    FILE* privkey_file = fopen(fileName.c_str(), "r");
    if(!privkey_file){
        cerr << "Error in reading private key file.."<<endl;
        return 0;
    }

    EVP_PKEY* privkey;
    if(!password)
        privkey = PEM_read_PrivateKey(privkey_file, NULL, NULL, NULL);
    else
        privkey = PEM_read_PrivateKey(privkey_file, NULL, NULL, password);
    fclose(privkey_file);
    if(!privkey){
        cerr << "Error in reading the private key from the file"<<endl;
        return 0;
    }
    return privkey;
}




bool SecurityManager::compareKeys(EVP_PKEY* a, EVP_PKEY* b) {
    return EVP_PKEY_cmp(a, b);
}

bool SecurityManager::compareNonces(unsigned char *na, unsigned char *nb) {
    if(!na || !nb)
        return false;

    for(int i = 0; i<NONCE_LENGTH; ++i) {
        if(na[i] != nb[i])
            return false;
    }
    return true;
}

char* SecurityManager::serializeKey(EVP_PKEY* key,long& len,BIO*& bio){
    BIO* mbio = BIO_new(BIO_s_mem());
    PEM_write_bio_PUBKEY(mbio,key);
    char* key_buf = NULL;

    len = BIO_get_mem_data(mbio,&key_buf);
    bio = mbio;
    return key_buf;
}

EVP_PKEY* SecurityManager::deserializeKey(unsigned char* key,long key_size,BIO*& bio){
    BIO* mbio = BIO_new(BIO_s_mem());
    BIO_write(mbio,key,key_size);
    EVP_PKEY* pubkey = PEM_read_bio_PUBKEY(mbio,NULL,NULL,NULL);
    bio = mbio;
    return pubkey;
}

char* SecurityManager::serializeDHParams(DH *params, long &len, BIO *&bio) {
    BIO* mbio = BIO_new(BIO_s_mem());
    PEM_write_bio_DHparams(mbio,params);
    char* params_buf = NULL;

    len = BIO_get_mem_data(mbio,&params_buf);
    bio = mbio;
    return params_buf;
}

DH* SecurityManager::deserializeDHParams(unsigned char *params, long paramsSize, BIO *&bio) {
    BIO* mbio = BIO_new(BIO_s_mem());
    BIO_write(mbio,params,paramsSize);
    DH* params_deserialized = NULL;
    params_deserialized = PEM_read_bio_DHparams(mbio,NULL,NULL,NULL);
    bio = mbio;
    return params_deserialized;
}

X509* SecurityManager::readCertificate(string fileName) {
    if(!checkWhitelist(fileName)){
        cerr<<"The name contains not admitted char"<<endl;
        return NULL;
    }
    FILE* cert_file = fopen(fileName.c_str(), "r");
    if(!cert_file){
        cerr << "Error in reading certificate file..";
        return 0;
    }
    X509* cert = PEM_read_X509(cert_file, NULL, NULL, NULL);
    fclose(cert_file);
    if(!cert){
        cerr << "Error in reading the certificate from the file.."<<endl;
        return 0;
    }

    return cert;
}

X509_CRL* SecurityManager::readCRL(string fileName){
    if(!checkWhitelist(fileName)){
        cerr<<"The name contains not admitted char"<<endl;
        return NULL;
    }
    FILE* crl_file = fopen(fileName.c_str(), "r");
    if(!crl_file){
        cerr << "Error in reading crl file..";
        return 0;
    }
    X509_CRL* crl = PEM_read_X509_CRL(crl_file, NULL, NULL, NULL);
    fclose(crl_file);
    if(!crl){
        cerr<<"Error in reading the crl from the file.."<<endl;
        return 0;
    }
    return crl;
}

bool SecurityManager::verifyCertificate(X509* CA_cert,X509_CRL* crl,X509* certificate){
    if(!CA_cert){
        cerr<<"CA cert null.."<<endl;
        return false;
    }
    if(!crl){
        cerr<<"crl null.."<<endl;
        return false;
    }
    if(!certificate){
        cerr<<"certificate to verify null.."<<endl;
        return false;
    }
    X509_STORE* store = X509_STORE_new();
    if(!store){
        cerr<<"Error in creating the store.."<<endl;
        return false;
    }
    X509_STORE_add_cert(store,CA_cert);
    X509_STORE_add_crl(store,crl);
    X509_STORE_set_flags(store,X509_V_FLAG_CRL_CHECK);

    X509_STORE_CTX* certvfy_ctx = X509_STORE_CTX_new();
    if(!certvfy_ctx) {
        cerr<<"error in creating the store to verify"<<endl;
        return false;
    }
    int ret = X509_STORE_CTX_init(certvfy_ctx, store, certificate, NULL);
    if(ret != 1) {
        cerr<<"error in store init"<<endl;
        return false;
    }
    ret = X509_verify_cert(certvfy_ctx);
    if(ret != 1) {
        cerr<<"error in verifying the certificate.."<<endl;
        return false;
    }
    X509_STORE_free(store);
    return true;

}


char* SecurityManager::serializeCert(X509* cert, long& len,BIO*& bio){
    BIO* mbio = BIO_new(BIO_s_mem());
    PEM_write_bio_X509(mbio,cert);
    char* cert_buf = NULL;
    len = BIO_get_mem_data(mbio,&cert_buf);
    bio = mbio;
    return cert_buf;
}


X509* SecurityManager::deserializeCert(unsigned char* cert, long certSize,BIO*& bio){
    BIO* mbio = BIO_new(BIO_s_mem());
    BIO_write(mbio,cert,certSize);
    X509* certificate = PEM_read_bio_X509(mbio,NULL,NULL,NULL);
    bio = mbio;
    return certificate;
}


unsigned char* SecurityManager::signature(EVP_PKEY* privKey,unsigned char* messageToSign,int lenMessageToSign,int &signature_len){

    EVP_PKEY_CTX *ctx;
    unsigned char *sig;
    size_t siglen;

    ctx = EVP_PKEY_CTX_new(privKey, NULL );
    if (!ctx){
        cerr<<"error in allocating the context"<<endl;
        return NULL;
    }
    if (EVP_PKEY_sign_init(ctx) <= 0){
        cerr<<"error in initializing the context"<<endl;
        return NULL;
    }
    if (EVP_PKEY_CTX_set_rsa_padding(ctx, RSA_PKCS1_PADDING) <= 0){
        cerr<<"error in setting the padding"<<endl;
        return NULL;
    }

    if (EVP_PKEY_CTX_set_signature_md(ctx, EVP_sha256()) <= 0){
        cerr<<"error in setting the hashing type"<<endl;
        return NULL;
    }

    //used to determine the buffer length->siglen
    if (EVP_PKEY_sign(ctx, NULL, &siglen, messageToSign, lenMessageToSign) <= 0){
        cerr<<"error in determining the buffer length"<<endl;
        return NULL;
    }

    sig = new unsigned char[siglen];

    //used to sign the message
    if (EVP_PKEY_sign(ctx, sig, &siglen, messageToSign, lenMessageToSign) <= 0){
        cerr<<"Error in signing the message"<<endl;
        return NULL;
    }
    signature_len = siglen;
    EVP_PKEY_CTX_free(ctx);
    return sig;
}

bool SecurityManager::verifySignature(EVP_PKEY* pubKey,unsigned char* signature,int signatureLen, unsigned char* md, int md_len) {

    EVP_PKEY_CTX* ctx = EVP_PKEY_CTX_new(pubKey, NULL);
    if(!ctx) {
        cerr<<"error in allocating the context to verify a signature"<<endl;
        return false;
    }

    if (EVP_PKEY_verify_init(ctx) <= 0) {
        cerr<<"error while initializing a context for a signature verify"<<endl;
        return false;
    }

    if (EVP_PKEY_CTX_set_rsa_padding(ctx, RSA_PKCS1_PADDING) <= 0) {
        cerr<<"Error specifying the RSA padding in a signature verify"<<endl;
        return false;
    }

    if (EVP_PKEY_CTX_set_signature_md(ctx, EVP_sha256()) <= 0) {
        cerr<<"Error specifying the hash algorithm in a signature verify"<<endl;
        return false;
    }

    int ret = EVP_PKEY_verify(ctx, signature, signatureLen, md, md_len);

    EVP_PKEY_CTX_free(ctx);

    return ret > 0;

    /* ret == 1 indicates success, 0 verify failure and < 0 for some
     * other error.
     */
}

unsigned char* SecurityManager::symmetricEncryption(unsigned char* key,unsigned char* iv,unsigned char* messageToEncrypt,int messageLength, unsigned int seq_num,int &cipherLength, unsigned char* tag){

    const EVP_CIPHER* cipher = SYMMETRIC_CIPHER;
    int block_size = EVP_CIPHER_block_size(cipher);

    EVP_CIPHER_CTX *ctx;
    ctx = EVP_CIPHER_CTX_new();
    if(!ctx){
        cerr<<"Encrypt: Error in creating the context"<<endl;
        return NULL;
    }

    //allocating the buffer for the ciphertext
    int enc_buffer_size = messageLength + block_size;
    unsigned char* cphr_buf = new unsigned char[enc_buffer_size];

    int ret = EVP_EncryptInit(ctx, cipher, key, iv);
    if(ret != 1){
        cerr <<"Error in encrypt init"<<endl;
        return NULL;
    }
    int update_len = 0; // bytes encrypted at each chunk
    int total_len = 0; // total encrypted bytes

    //first of all we add seq number in aad
    unsigned char* aad = (unsigned char*)&seq_num;
    int aad_len = sizeof(unsigned int);
    ret = EVP_EncryptUpdate(ctx, NULL, &update_len, aad, aad_len);
    if(ret != 1){
        cerr <<"Error in encrypt update (AAD)"<<endl;
        return NULL;
    }

    ret = EVP_EncryptUpdate(ctx, cphr_buf, &update_len, messageToEncrypt, messageLength);
    if(ret != 1){
        cerr <<"Error in encrypt update"<<endl;
        return NULL;
    }
    total_len += update_len;

    ret = EVP_EncryptFinal(ctx, cphr_buf + total_len, &update_len);
    if(ret != 1){
        cerr <<"Error in encrypt final"<<endl;
        return NULL;
    }
    total_len += update_len;
    cipherLength = total_len;

    //copy the tag
    unsigned char temp_tag[SYMMETRIC_TAG_LEN];
    ret = EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_GET_TAG, SYMMETRIC_TAG_LEN, temp_tag);
    if( ret != 1) {
        cerr<<"Error while retrieving the tag of the ciphertext"<<endl;
        return NULL;
    }

    memcpy(tag, temp_tag, SYMMETRIC_TAG_LEN); //This is to avoid tag to be erased by the CTX_free

    EVP_CIPHER_CTX_free(ctx);
    return cphr_buf;
}

unsigned char* SecurityManager::symmetricDecryption(unsigned char* key,unsigned char* iv,unsigned char* cipherText,int cipherLen, unsigned int seq_num,int &messageLength, unsigned char* tag){
    const EVP_CIPHER* cipher = SYMMETRIC_CIPHER;

    EVP_CIPHER_CTX *ctx;
    ctx = EVP_CIPHER_CTX_new();
    if(!ctx){
        cerr <<"Decrypt: Error in creating the context"<<endl;
        return NULL;
    }

    int ret = EVP_DecryptInit(ctx, cipher, key, iv);
    if(ret != 1){
        cerr <<"Error in decrypt init"<<endl;
        return NULL;
    }

    int update_len = 0; // bytes decrypted at each chunk
    int total_len = 0; // total decrypted bytes
    unsigned char* plainText = new unsigned char[cipherLen];

    //first of all we add seq number in aad
    int aad_len = sizeof(unsigned int);
    ret = EVP_DecryptUpdate(ctx, NULL, &update_len, (unsigned char*)&seq_num, aad_len);
    if(ret != 1){
        cerr <<"Error in Decrypt update (AAD)"<<endl;
        return NULL;
    }

    ret = EVP_DecryptUpdate(ctx, plainText, &update_len, cipherText, cipherLen);
    if(ret != 1){
        cerr <<"Error in decrypt update"<<endl;
        return NULL;
    }
    total_len += update_len;

    ret = EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_TAG, SYMMETRIC_TAG_LEN, tag);
    if(!ret) {
        cerr<<"could not set the tag."<<endl;
        return NULL;
    }


    ret = EVP_DecryptFinal(ctx, plainText + total_len, &update_len);
    if(ret != 1){
        cerr <<"Error in decrypt final"<<endl;
        return NULL;
    }
    total_len += update_len;
    messageLength = total_len;
    EVP_CIPHER_CTX_free(ctx);
    return plainText;
}

void SecurityManager::updateIV(unsigned char* iv) {

    //using an LCG to deterministically update the iv
    int length = EVP_CIPHER_iv_length(SYMMETRIC_CIPHER)/4;
    uint32_t* int_iv = (uint32_t*) iv;
    for(int i = 0; i<length; ++i) {
        int_iv[i] = LCG_A*int_iv[i] + LCG_C;
    }

}

int SecurityManager::sendEncrypted(int socket, const void* messageToSend, int messageToSendLength, unsigned char* key, unsigned char* iv, uint16_t seq_num){
    int length = 0;
    unsigned char tag[SYMMETRIC_TAG_LEN];
    updateIV(iv); //each time we update the iv before sending a new message
    unsigned char* cipherText = symmetricEncryption(key,iv,(unsigned char *)messageToSend,messageToSendLength,seq_num,length, tag);
    unsigned char *envelope = new unsigned char[SYMMETRIC_TAG_LEN + SEQ_NUM_LEN + CIPHERTEXT_LEN_LEN + length];

    //creating the envelope to be sent (tag | seq_num | ciph_len | ciphertext)
    memcpy(envelope,tag, sizeof(tag));
    memcpy(envelope + sizeof(tag), (unsigned char*)&seq_num, SEQ_NUM_LEN);
    ((uint32_t*)(envelope + sizeof(tag) + SEQ_NUM_LEN))[0] = length;
    memcpy(envelope + sizeof(tag) + SEQ_NUM_LEN + CIPHERTEXT_LEN_LEN, cipherText, length);
    int env_len = length + sizeof(tag) + SEQ_NUM_LEN + CIPHERTEXT_LEN_LEN;
    delete [] cipherText;

    int ret = send(socket, (const void*) envelope, env_len, 0);
    if(ret < length) {
        return 0;
    }

    delete [] envelope;
    return messageToSendLength;
}

int SecurityManager::receiveDecrypted(int socket, void* messageReceived, int length, unsigned char* key,unsigned char* iv, uint16_t seq_num){

    int max_len = maxEncryptedLength(length);
    unsigned char* buffer = new unsigned char[max_len];

    //wait for message header (tag | seq_num | cip_len)
    int ret = recv(socket, (void *) buffer, SYMMETRIC_TAG_LEN + SEQ_NUM_LEN + CIPHERTEXT_LEN_LEN, MSG_WAITALL);
    if(ret <= 0) {
        cerr<<"Could not receive the next message"<<endl;
        return 0;
    }

    //unwrap the header
    unsigned char * tag = buffer;
    uint16_t recv_seq_num = ((uint16_t *)(buffer + SYMMETRIC_TAG_LEN))[0];
    uint32_t ciphertext_len = ((uint32_t *)(buffer + SYMMETRIC_TAG_LEN + SEQ_NUM_LEN))[0];

    if(ciphertext_len + SEQ_NUM_LEN + CIPHERTEXT_LEN_LEN + SYMMETRIC_TAG_LEN > max_len) {
        cout<<"The incoming message is bigger than the maximum specified length.";
        return -1;
    }

    //unwrap the envelope
    unsigned char * ciphertext = buffer + SYMMETRIC_TAG_LEN + SEQ_NUM_LEN + CIPHERTEXT_LEN_LEN;

    //now we receive the ciphertext
    ret = recv(socket, (void *) ciphertext, (int)ciphertext_len, MSG_WAITALL);
    if(ret <= 0) {
        cerr<<"Could not receive the ciphertext of a message."<<endl;
        return 0;
    }

    if(recv_seq_num != seq_num) {
        cerr<<"Sequence numbers do not match. Error."<<endl;
        return 0;
    }

    updateIV(iv); //we update the iv before decrypting a new message
    unsigned char* plainText = symmetricDecryption(key, iv, ciphertext, (int)ciphertext_len, seq_num,length, tag);
    if(!plainText) {
        cerr<<"could not decrypt an encrypted message"<<endl;
        return 0;
    }
    delete [] buffer;
    memcpy(messageReceived, plainText, length);
    delete [] plainText;

    return length;
}

void SecurityManager::generate_DH_privKey() {

    //first of all we get DH parameters
    dh_params_pkey = EVP_PKEY_new();
    EVP_PKEY_set1_DH(dh_params_pkey, dh_params);

    //then we generate our private key
    ctx_prv = EVP_PKEY_CTX_new(dh_params_pkey, NULL);
    dh_prv_key = NULL;
    EVP_PKEY_keygen_init(ctx_prv);
    EVP_PKEY_keygen(ctx_prv, &dh_prv_key);

}

bool SecurityManager::saveOpponentDH_pubkey(unsigned char* opponent_pubkey, long len) {
    oppo_pubkey = deserializeKey(opponent_pubkey, len, oppo_pubkey_bio);
    return opponent_pubkey != NULL;
}

bool SecurityManager::deriveDH_SharedSecret() {

    derivation_ctx = EVP_PKEY_CTX_new(dh_prv_key, NULL);
    if(derivation_ctx == NULL) {
        cerr<<"Could not init a DH secret derivation context"<<endl;
        return false;
    }
    if(EVP_PKEY_derive_init(derivation_ctx) <= 0) {
        cerr<<"EVP_PKEY_derive_init returned error"<<endl;
        return false;
    }
    if(EVP_PKEY_derive_set_peer(derivation_ctx, oppo_pubkey) <= 0) {
        cerr<<"EVP_PKEY_derive_set_peer returned error"<<endl;
        return false;
    }

    //derive secret length
    if(EVP_PKEY_derive(derivation_ctx, NULL, &secretLen) <= 0) {
        cerr<<"EVP_PKEY_derive to get the length returned error"<<endl;
        return false;
    }

    //derive the secret itself
    secret = new unsigned char[secretLen];
    if(EVP_PKEY_derive(derivation_ctx, secret, &secretLen) <= 0) {
        cerr<<"EVP_PKEY_derive returned error"<<endl;
        return false;
    }

    return secret != NULL; //check for eventual malloc errors

}

void SecurityManager::initDHParams(DH* const params, BIO* const bio) {
    dh_params = params;
    dh_params_bio = bio;

    dh_params_pkey = NULL;
    ctx_prv = NULL;
    dh_prv_key = NULL;

    serialized_key_bio = NULL;

    oppo_pubkey = NULL;
    oppo_pubkey_bio = NULL;

    derivation_ctx = NULL;
    secret = NULL;
    secretLen = 0;
}

void SecurityManager::DH_CTX_free() {
    if(dh_params) DH_free(dh_params);
    if(dh_params_bio) BIO_free(dh_params_bio);
    if(dh_params_pkey) EVP_PKEY_free(dh_params_pkey);
    if(ctx_prv) EVP_PKEY_CTX_free(ctx_prv);
    if(dh_prv_key) EVP_PKEY_free(dh_prv_key);
    if(serialized_key_bio) BIO_free(serialized_key_bio);
    if(oppo_pubkey) EVP_PKEY_free(oppo_pubkey);
    if(oppo_pubkey_bio) BIO_free(oppo_pubkey_bio);
    if(derivation_ctx) EVP_PKEY_CTX_free(derivation_ctx);
    if(secret) delete[] secret;
}

void* SecurityManager::deriveIV(void *nonceClient, void *nonceServer) {

    int len = EVP_CIPHER_iv_length(SYMMETRIC_CIPHER);
    unsigned char* iv = new unsigned char[len];
    for(int i = 0; i<len; ++i) {
        iv[i] = ((unsigned char*) nonceClient)[i] ^ ((unsigned char*) nonceServer)[i];
    }
    return (void*)iv;
}