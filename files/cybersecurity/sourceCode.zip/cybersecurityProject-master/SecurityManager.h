//
// Created by emilio on 29/06/20.
//

#ifndef CYBERSECURITYPROJECT_SECURITYMANAGER_H
#define CYBERSECURITYPROJECT_SECURITYMANAGER_H

#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/rand.h>
#include <openssl/pem.h>
#include <openssl/x509_vfy.h>
#include <string>
#include "constants.h"

using namespace std;
class SecurityManager {
private:
    static bool PRNG_seeded;

    static void* randomStream(const int length);

    EVP_MD_CTX* hash_ctx;
    unsigned char digest[32]; //256 bits (sha256)

    //USED BY THE CLIENT IN DHKE (context)

    DH* dh_params; //DH parameters for p2p
    BIO* dh_params_bio; //BIO pointer to free dh_params when needed

    EVP_PKEY* dh_params_pkey;
    EVP_PKEY_CTX* ctx_prv;
    EVP_PKEY* dh_prv_key;

    BIO* serialized_key_bio;

    EVP_PKEY* oppo_pubkey;
    BIO* oppo_pubkey_bio;

    EVP_PKEY_CTX* derivation_ctx;
    unsigned char* secret;
    size_t secretLen;

    //END DHKE context


public:
    static const int NONCE_LENGTH = 32;
    static const int PREMASTER_LENGTH = 48;
    static const EVP_CIPHER * const DIGITAL_ENVELOP_CIPHER;
    static const EVP_CIPHER * const SYMMETRIC_CIPHER;
    static const int SYMMETRIC_KEY_LEN = 32;
    static const int SYMMETRIC_TAG_LEN = 16;

    //SECURITY UTILITY FUNCTIONS

    /**
     * Check if a string contains only admitted characters
     * @param s the string that needs to be checked
     * @return true if the string contains only admitted characters, false otherwise
     */
    static bool checkWhitelist(string s) {
        return s.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-./") == string::npos;
    }


    /*********************************
     * SYMMETRIC ENCRYPTION INTERFACE
     *********************************/

    /**
     * Compute the Initialization vector to use for the next message
     * @param iv the old initialization vector
     */
    static void updateIV(unsigned char* iv);

    /**
     * Send a message through a socket and encrypt it using a symmetric key in GCM
     * @param socket the socket on which to send the message
     * @param messageToSend the message that needs to be sent in an encrypted way
     * @param messageToSendLength the length of the message
     * @param key the key used in the encrypted communication
     * @param iv the initialization vector (to be automatically updated)
     * @param seq_num the sequence number of the message
     * @return the number of byted sent, <=0 in case of error
     */
    static int sendEncrypted(int socket, const void* messageToSend,int messageToSendLength, unsigned char* key,unsigned char* iv, uint16_t seq_num);


    /**
     * Receive an envelope from a socket and decrypt it with a symmetric key in Galois Counter Mode
     * @param socket the socket on which to receive the message
     * @param key the key used in the encrypted communication
     * @param iv the initialization vector
     * @param length parameter containing the length of the messageReceived
     * @param seq_num the sequence number of the message
     * @return the number of bytes received, <=0 in case of error
     */
    static int receiveDecrypted(int socket, void* messageReceived, int length, unsigned char* key,unsigned char* iv, uint16_t seq_num);

    /**
     * Encrypt a message using a symmetric key in Galois Counter Mode
     * @param key the symmetric key used to encrypt
     * @param iv the iv used in encryption
     * @param messageToEncrypt the message that needs to be encrypted
     * @param messageLength the length of the message that needs to be encrypted
     * @param seq_num the sequence number of the message
     * @param cipherLength output parameter containing the length of the cipher
     * @param tag pre allocated buffer in which will be copied the ciphertext tag
     * @return cipher text
     */
    static unsigned char* symmetricEncryption(unsigned char* key,unsigned char* iv,unsigned char* messageToEncrypt,int messageLength, unsigned int seq_num, int &cipherLength, unsigned char* tag);

    /**
     * Decrypt a message using a symmetric key
     * @param key the symmetric key used to decrypt
     * @param iv the iv used in decryption
     * @param cipherText the ciphertext that needs to be decrypted
     * @param cipherLen the ciphertext length
     * @param messageLength output parameter containing the length of the plaintext
     * @param seq_num the sequence number of the message
     * @param tag pre allocated buffer in which will be copied the gcm tag
     * @return plaintext/decrypted message
     */
    static unsigned char* symmetricDecryption(unsigned char* key,unsigned char* iv,unsigned char* cipherText,int cipherLen, unsigned int seq_num, int &messageLength, unsigned char* tag);



    /**
     * Get the max size of the received message from the plaintext length
     * @param len the plaintext length
     * @return the max message length
     */
    static int maxEncryptedLength(int len) {
        return len+SYMMETRIC_TAG_LEN+SEQ_NUM_LEN+CIPHERTEXT_LEN_LEN;
    }


    /***************************************
     * END OF SYMMETRIC ENCRYPTION INTERFACE
     ***************************************/


    /*********************************
     * UTILITY OPENSSL METHODS
     *********************************/

    /**
     * Sign an sha256 digest
     * @param privKey the private key used to sign the message
     * @param messageToSign the message to sign
     * @param lenMessageToSign the length of the message to sign
     * @param signature_len output parameter containing the length of the signature
     * @return the signature of the message
     */
    static unsigned char* signature(EVP_PKEY* privKey,unsigned char* messageToSign,int lenMessageToSign,int &signature_len);

    /**
     * Verify a signature on a sha256 digest
     * @param pubKey the public key to decrypt the signature
     * @param signature the signature byte stream
     * @param signatureLen the length of the signature
     * @param md the digest on which the signature must be verified
     * @param md_len the digest length
     * @return true if the digest signature was verified
     */
    static bool verifySignature(EVP_PKEY* pubKey,unsigned char* signature,int signatureLen, unsigned char* md, int md_len);

    /**
     * read a public key from a pem file
     * @param fileName the name of the pem file containing the public key
     * @return A pointer to the key, NULL if an error occurred
     */
    static EVP_PKEY* readPublicKey(string fileName);

    /**
     * read a private key from a pem file
     * @param fileName the name of the pem file containing the private key
     * @param password a pointer to the passphrase to access the file (optional)
     * @return A pointer to the key, NULL if an error occurred
     */
     static EVP_PKEY* readPrivateKey(string fileName,void* password=NULL);

    /**
     * serializes a key and returns it
     * @param key the key that needs to be serialized
     * @param len output parameter in which is saved the length of serialized key
     * @return the serialized key
     */
    static char* serializeKey(EVP_PKEY* key, long& len,BIO*& bio);

    /**
     * deserializes a key from a char array and returns it
     * @param key the key that needs to be deserialized
     * @param keySize the length of the buffer containing the key to be deserialized
     * @return the deserialized key
     */
    static EVP_PKEY* deserializeKey(unsigned char* key, long keySize,BIO*& bio);

    /**
     * read a certificate from a pem file
     * @param fileName the name of the pem file containing the certificate
     * @return A pointer to the certificate, NULL if an error occurred
     */
    static X509* readCertificate(string fileName);

    /**
    * read a certificate revocation list from a pem file
    * @param fileName the name of the pem file containing the certificate revocation list
    * @return A pointer to the certificate revocation list, NULL if an error occurred
    */
    static X509_CRL* readCRL(string fileName);

    /**
    * verify the certificate
    * @param CA_CERT the CA certificate
    * @param crl the CA crl
    * @param certificate the certificate that needs to be verified
    * @return TRUE in case of a successful verification, FALSE otherwise
    */
    static bool verifyCertificate(X509* CA_cert,X509_CRL* crl,X509* certificate);

    /**
     * serializes a cert and returns it
     * @param cert the cert that needs to be serialized
     * @param len output parameter in which is saved the length of serialized cert
     * @return the serialized cert
     */
    static char* serializeCert(X509* cert, long& len,BIO*& bio);

    /**
     * deserializes a cert from a char array and returns it
     * @param cert the cert that needs to be deserialized
     * @param certSize the length of the buffer containing the cert to be deserialized
     * @return the deserialized cert
     */
    static X509* deserializeCert(unsigned char* cert, long certSize,BIO*& bio);

    /**
     * Serialize DH params
     * @param params params to be serialized
     * @param len output parameter for the output length
     * @param bio the bio to use to deallocate the output
     * @return the serial output stream
     */
    static char* serializeDHParams(DH* params, long& len, BIO* &bio);

    /**
     * Deserialize DH params
     * @param params the params to be deserialized
     * @param paramsSize the length of params
     * @param bio the bio to use to deallocate the result
     * @return the deserialized parameters
     */
    static DH* deserializeDHParams(unsigned char* params, long paramsSize, BIO* &bio);


    /**
     * Compare two asymmetric keys
     * @param a one of the two keys
     * @param b the other key
     * @return 1 if they are equal, 0 otherwise
     */
     static bool compareKeys(EVP_PKEY* a, EVP_PKEY* b);

     /**
      * Compare two preallocated nonces
      * @param na the first nonce
      * @param nb the second nonce
      * @return true if they are equal
      */
     static bool compareNonces(unsigned char* na, unsigned char* nb);


    /*********************************
    * END OF UTILITY OPENSSL METHODS
    *********************************/

    /**********************************************************
     * FOUR ROW AUTHENTICATION HANDSHAKE (FRAH) IMPLEMENTATION
     **********************************************************/

    /**
     * Generate a nonce (used in M1 and M2)
     * @param len output parameter in which is saved the nonce length in bytes
     * @return a pointer to the nonce byte stream
     */
    static void* generateNonce(int& len);

    /**
     * Generate a IV
     * @param len output parameter in which is saved the IV length in bytes
     * @return a pointer to the IV byte stream
     */
    static void* generateIV(int& len);

    /**
     * Generate a pre master secret (used in M5)
     * @param len output parameter in which is saved the pre master length in bytes
     * @return a pointer to the pre master byte stream
     */
    static void* generatePreMasterSecret(int& len);

    /**
     * Initialize the generation of a digest using an incremental approach
     * @return false in case of errors
     */
    bool digestInit();

    /**
     * Update the status of the hashing context with a portion of the byte stream
     * @param buffer the pointer to the stream to hash
     * @param length the length in bytes of buffer
     * @return false in case of errors
     */
    bool digestUpdate(const void * buffer, int length);

    /**
     * @param len output parameter in which is saved the digest length in bytes
     * @return the pointer to the digest byte stream, NULL in case of errors
     */
    void* digestFinal(unsigned int &len);

    /**
     * Hash a data stream in one shot
     * @param buffer the data stream to be hashed
     * @param length the length in bytes of the data stream
     * @param len output parameter containing the length of the digest
     * @return a pointer to the hashed data stream, NULL in case of errors
     */
    static void* hash(const void* buffer, int length, unsigned int &len);

    /**
     * Encrypt a plaintext with a public or private key using RSA algorithm in a digital envelope.
     * Used in M5,M6,M7,M8
     * @param plaintext the message to be encrypted
     * @param plainLen the length in bytes of plaintext
     * @param key the public or private key to encode the message
     * @param encrypted_symmetric_key output variable used to retrieve the symmetric key used
     * @param enc_sym_key_len output variable containing the real length of the encrypted symmetric key
     * @param iv output variable containing the initialization vector used to encrypt the plaintext
     * @param len output parameter in which is saved the ciphertext length in bytes
     * @param ctx output variable containing the context to be freed after all further operations
     * @return a pointer to the ciphertext byte stream
     */
    static void* RSA_encrypt(const void* plaintext, int plainLen, EVP_PKEY* key, unsigned char* &encrypted_symmetric_key, int &enc_sym_key_len,  unsigned char* &iv, int& len, EVP_CIPHER_CTX* &ctx);

    /**
     * Decrypt a digital envelope with a public or private key using RSA algorithm.
     * Used to decrypt M6,M7,M8
     * @param ciphertext the message to be decrypted
     * @param cipherLen the length in bytes of ciphertext
     * @param key the public or private key to decode the ciphertext
     * @param encrypted_symmetric_key used to receive from the encrypt the symmetric key used
     * @param enc_sym_key_len The effective length of the encrypted symmetric key
     * @param iv the iv used to encrypt the ciphertext
     * @param len output parameter in which is saved the plaintext length in bytes
     * @param ctx output variable containing the context to be freed after all further operations
     * @return a pointer to the plaintext byte stream
     */
    static void* RSA_decrypt(const void* ciphertext, int cipherLen, EVP_PKEY* key, unsigned char* encrypted_symmetric_key, int enc_sym_key_len, unsigned char* iv, int& len, EVP_CIPHER_CTX* &ctx);

    /**
     * Generate an RSA-encrypted digital envelope from a plaintext, ready to be sent in FRAH M6,M7,M8
     * @param plaintext the message to be encrypted
     * @param plainLen the length in bytes of plaintext
     * @param key key the public or private key to encode the message
     * @param len output parameter in which is saved the digital envelope length in bytes
     * @return A pointer to the digital envelope byte stream
     */
    static void* generateDigEnvelope(const void* plaintext, int plainLen, EVP_PKEY* key, int &len);

    /**
     * Decrypt a digital envelope and return its plaintext.
     * @param envelope The envelope to decrypt
     * @param envLen the envelope length
     * @param key the asymmetric key to be used in decryption
     * @param len output parameter in which is saved the plaintext length in bytes
     * @return a pointer to the plaintext byte stream
     */
    static void* decryptDigEnvelope(const void* envelope, int envLen, EVP_PKEY* key, int &len);

    /**
     * Generate the symmetric key with two nonces and a pre master secret. The bytes returned can be split
     * in two parts to obtain both key and initialization vector
     * @param nonceClient the client side nonce
     * @param nonceServer the server side nonce
     * @param nonceLen the length in bytes of the two nonces
     * @param premaster the premaster secret byte stream
     * @param premasterLen the length in bytes of the pre master secret
     * @param len output parameter in which is saved the symmetric key length in bytes
     * @return a pointer to the symmetric key byte stream
     */
    static void* generateKey(void* nonceClient, void* nonceServer, int nonceLen, void* premaster, int premasterLen, int& len);

    static void* deriveIV(void* nonceClient, void*nonceServer);


    /************************
    * END FRAH IMPLEMENTATION
    ************************/

    /************************
     * BEGIN AUTH DHKE
     ***********************/

    /**
     * Initialize DH params for DHKE
     * @param params params to use for initialization
     * @param bio the bio pointer to use for the deallocation
     */
    void initDHParams(DH* const params, BIO* const bio = NULL);

    /**
     * Free a DHKE context after the handshake
     */
    void DH_CTX_free();

    /**
     * Generate a private key for DHKE
     */
    void generate_DH_privKey();

    /**
     * Get a serialized version of the DH public key
     * @param len output parameter containing the output stream length
     * @return the output stream
     */
    void* getSerializedDH_pubkey(long &len) {
        return serializeKey(dh_prv_key, len, serialized_key_bio);
    }

    /**
     * Save the opponent public key in the context.
     * @param opponent_pubkey the serialized opponent public key
     * @param len the opponent key length
     * @return true if the key was correctly deserialized and stored in the context
     */
    bool saveOpponentDH_pubkey(unsigned char* opponent_pubkey, long len);

    /**
     * Derive the DH shared secret from the context
     * @return true if the secret was correctly derived
     */
    bool deriveDH_SharedSecret();

    /**
     * Get the symmetric key
     * @param len output parameter containing the key length
     * @return the key byte stream
     */
    void* getDH_SymmetricKey(unsigned int &len) {
        return hash(secret, secretLen, len);
    }

    /************************
     * END AUTH DHKE
     ***********************/
};

#endif //CYBERSECURITYPROJECT_SECURITYMANAGER_H
