//
// Created by baccios on 24/06/20.
//

#ifndef CYBERSECURITYPROJECT_CONSTANTS_H
#define CYBERSECURITYPROJECT_CONSTANTS_H
#include <string>

const unsigned int USERNAME_MAXSIZE = 16;
const unsigned int MAX_USERS_TO_SEND = 64;

enum client_status  { //to represent client status
        WAITING_INIT, //used only on client
        TO_BE_ASKED,
        WAITING,
        CHALLENGED,
        CHALLENGING,
        WAITING_RESPONSE,
        RESPONSE_ARRIVED,
        HANDSHAKE_PREPARATION,
        HANDSHAKE_CHALLENGER, //used only on client
        HANDSHAKE_CHALLENGED, //used only on client
        WAITING_FOR_P2P_ADDRESS, //used only on server
        PLAYING,
        GAME_OVER, //used only on client
        QUITTING //used only on client
};

const int PRIVKEY_PSW_MAXSIZE = 33;
const int SERVER_CERTIFICATE_MAX_SIZE = 2048;
const std::string CA_CERTIFICATE_NAME = "Baccios_CA_cert.pem";
const std::string CA_CRL_NAME = "Baccios_crl.pem";
const int SERIAL_KEY_SIZE = 625;
const int DH_PARAMS_SIZE = 773;
const int SERIAL_DH_KEY_MAX_SIZE = 2048;

const unsigned int LCG_A =  1664525;
const unsigned int LCG_C = 1013904223;

const unsigned int SEQ_NUM_LEN = 2;
const unsigned int CIPHERTEXT_LEN_LEN = 4;


const int MAX_IV_LEN = 16;

#endif //CYBERSECURITYPROJECT_CONSTANTS_H
