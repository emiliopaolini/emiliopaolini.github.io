import requests
import json
import csv


TOKEN = "Bearer "+"BQAVG9bbS0uhWFDnyGnoN2P0wnLiMdY6QIvME3c1V4nEOgSBTpqt2dbQ6z31VYdLF78asuchOvGmEfpODfb1RdZdhLZbCrSqCkoxwROhQWtFM3tPo5Wg498SJlPNeeVoe6LSpk6xwPX6GJf7vgpuWYMLkPW-MCw"

headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': TOKEN,
}

params = (
    ('fields', 'items(track(id))'),
    ('limit', '100'),
)



playlist_id = "37i9dQZF1DX1HUbZS4LEyL"
response = requests.get('https://api.spotify.com/v1/playlists/'+playlist_id+'/tracks', headers=headers, params=params)

data = response.json()


#creo csv
csvFile = open('tabella.csv', 'w', newline='') 
csvWriter = csv.writer(csvFile)
#popularity',
csvWriter.writerow(['Length','Danceability','Acousticness','Energy','liveness','loudness','speechiness','valence','tempo'])


numberOfSongs=100
i = 0
for song in data['items']:
	#per ogni canzone ottengo i suoi dati
	headers = {
    	'Accept': 'application/json',
    	'Content-Type': 'application/json',
    	'Authorization': TOKEN,
	}

	response = requests.get('https://api.spotify.com/v1/audio-features/'+song['track'].get('id'), headers=headers)
	song_data = response.json()


	headers = {
    	'Accept': 'application/json',
    	'Content-Type': 'application/json',
    	'Authorization': TOKEN,
	}



	
	
	csvWriter.writerow([song_data['duration_ms'],song_data['danceability'],song_data['acousticness'],song_data['energy'],song_data['liveness'],song_data['loudness'],song_data['speechiness'],song_data['valence'],song_data['tempo']])
	i +=1
	print("Percentage: "+str((i/numberOfSongs)*100)+"%")
print("File creato")