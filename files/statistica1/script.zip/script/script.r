tabella = read.csv("tabella.csv")
#visualizzazione dei dati -> scatterplot e correlazioni
plot(tabella,pch=19)
round(cor(tabella),2)

#PCA
tabella = scale(tabella)
tabella = data.frame(tabella)
tabella.pca = princomp(tabella)
summary(tabella.pca)
plot(cumsum(tabella.pca$sdev^2)/sum(tabella.pca$sdev^2),type="b",ylim=c(0,1))
#fine PCA

#REGRESSIONE LINEARE
tabella = read.csv("tabella.csv")
tabella.lm = lm(Energy ~ .,data = tabella)
summary(tabella.lm)

#riduzione modello
matriceVarianze = matrix(ncol=2,nrow=6)
summary(tabella.lm)
matriceVarianze[1,] = c(summary(tabella.lm)$r.squared,summary(tabella.lm)$adj.r.squared)

tabella.lm2 = lm(Energy ~ .-tempo,data = tabella)
summary(tabella.lm2)
matriceVarianze[2,] = c(summary(tabella.lm2)$r.squared,summary(tabella.lm2)$adj.r.squared)

tabella.lm3 = lm(Energy ~ .-tempo-liveness,data = tabella)
summary(tabella.lm3)
matriceVarianze[3,] = c(summary(tabella.lm3)$r.squared,summary(tabella.lm3)$adj.r.squared)

tabella.lm4 = lm(Energy ~ .-tempo-liveness-Length,data = tabella)
summary(tabella.lm4)
matriceVarianze[4,] = c(summary(tabella.lm4)$r.squared,summary(tabella.lm4)$adj.r.squared)

tabella.lm5 = lm(Energy ~ .-tempo-liveness-Length-speechiness,data = tabella)
summary(tabella.lm5)
matriceVarianze[5,] = c(summary(tabella.lm5)$r.squared,summary(tabella.lm5)$adj.r.squared)

tabella.lm6 = lm(Energy ~ .-tempo-liveness-Length-speechiness-Danceability,data = tabella)
summary(tabella.lm6)
matriceVarianze[6,] = c(summary(tabella.lm6)$r.squared,summary(tabella.lm6)$adj.r.squared)

#disegno grafico andamento varianze
ymin = min(matriceVarianze)
ymax = max(matriceVarianze)
plot(matriceVarianze[,1],pch=19,type="b",col="red",ylab="matrice Varianze",ylim=c(ymin,ymax))
lines(matriceVarianze[,2],pch=19,type="b",col="blue")
legend("topright", legend=c("R^2", "ADJ R^2"),col=c("red", "blue"), lty=1:1, cex=1.5)


tabella.lm = lm(Energy ~ .-tempo-liveness-Length, data=tabella)
summary(tabella.lm)

#fine riduzione modello

#analisi dei residui
tabella.lm.res=resid(tabella.lm)
plot(predict(tabella.lm),tabella.lm.res,pch=19)
#skewness->deve essere vicina a 0 -> piu vicina a 0 piu distribuzione è simmetrica -> viene -0.34
mean(((tabella.lm.res-mean(tabella.lm.res))/sd(tabella.lm.res))^3)
#kurtosis->deve essere vicino a 3 per le distribuzioni normali -> viene 2.75
mean(((tabella.lm.res-mean(tabella.lm.res))/sd(tabella.lm.res))^4)
#istogramma
tabella = read.csv("tabella.csv")
tabella = scale(tabella)
tabella = data.frame(tabella)
tabella.lm = lm(Energy ~ .-tempo-liveness-Length, data=tabella)
tabella.lm.res=resid(tabella.lm)
hist(tabella.lm.res,15,freq=F,xlab = "Residui")
lines(density(tabella.lm.res),col="red")
lines(sort(tabella.lm.res),dnorm(sort(tabella.lm.res),mean(tabella.lm.res),sd(tabella.lm.res)))
legend("topright", legend=c("Densita' Empirica", "Densita' Teorica"),col=c("red", "black"), lty=1:1, cex=1)
#funzione cumulativa di probabilit�
plot(ecdf(tabella.lm.res),pch=".")
m=mean(tabella.lm.res)
s=sd(tabella.lm.res)
y=seq(m-3*s,m+3*s,6*s/100)
lines(y,pnorm(y,m,s),col="red")
legend("topleft", legend=c("Funzione cumulativa di probabilita' Empirica", "Funzione cumulativa di probabilita' Teorica"),col=c("black", "red"), lty=1:1, cex=1)

#qq plotqqline(pa.lm.res)
qqnorm(tabella.lm.res,pch=19,xlab="Quantili Teorici",ylab="Quantili Empirici")
qqline(tabella.lm.res)
#test Shapiro Wilk
shapiro.test(tabella.lm.res)
#FINE ANALISI RESIDUI

#VALUTAZIONE MODELLO
#visualizzazione grafica dati predetti vs dati attuali
tabella = read.csv("tabella.csv")
dataTestSet = read.csv("testSet.csv")
trainingSet <- tabella
tabella.lm = lm(Energy~.-liveness-tempo-Length,data = trainingSet)

testSetIndexes <-sort(sample(100,50))
testSet <- dataTestSet[testSetIndexes,]
tabella.lm.p =predict(tabella.lm,testSet)

plot(testSet$Energy,pch=20,ylab="Valori")
points(tabella.lm.p,col="blue",pch=20)
legend("topleft",inset=0.02,c("dati","dati predetti"),col=c("black","blue"),pch=c(19,19),bg="gray",cex=.8)



#intervalli di confidenza e previsione per 5 campioni estratti casualmente dal testSet
set.seed(544485)

testSetIndexes <-sort(sample(100,5))
testSet <- dataTestSet[testSetIndexes,]
tabella.lm.p =predict(tabella.lm,testSet)
tabella.lm.ci=predict(tabella.lm,testSet,interval="confidence")
tabella.lm.pi=predict(tabella.lm,testSet,interval="prediction")
plot(testSet$Energy,pch=19,col="red",ylim=c(min(tabella.lm.pi[,2]),max(tabella.lm.pi[,3])))
x=1:5
points(x-0.05,tabella.lm.ci[,1],pch=19,col="blue")
segments(x-0.05,tabella.lm.ci[,2],x-0.05,tabella.lm.ci[,3],col="blue")
points(x+0.05,tabella.lm.pi[,1],pch=19,col="green3")
segments(x+0.05,tabella.lm.pi[,2],x+0.05,tabella.lm.pi[,3],col="green3")
legend("topleft",inset=0.02,c("Valori dati","Intervalli di confidenza","Intervalli di predizione"),col=c("red","blue","green3"),pch=c(19,19),bg="gray",cex=.8)



n=50
vettoreErrori = rep(0,n)
tabella = read.csv("tabella.csv")

trainingSet <- tabella
dataTestSet = read.csv("testSet.csv")

for(i in 1:n){
  #costruzione modello: ogni volta con 80 campioni casuali della Playlist del 2018
  trainingSet <- tabella[sort(sample(100,80)),]
  tabella.lm = lm(Energy~.-liveness-tempo-Length,data = trainingSet)
  #costruzione testSet con 20 campioni casuali della Playlist del 2014
  testSetIndexes <-sort(sample(100,20))
  testSet <- dataTestSet[testSetIndexes,]
  tabella.lm.p =predict(tabella.lm,testSet)
  vettoreErrori[i]=mean((tabella.lm.p-testSet$Energy)^2)/mean(testSet$Energy)^2
}
mean(vettoreErrori)
sd(vettoreErrori)


#FINE VALUTAZIONE MODELLO