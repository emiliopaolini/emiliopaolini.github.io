import requests
import json
import csv


TOKEN = "Bearer "+"NUOVO TOKEN QUI"

headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': TOKEN,
}

params = (
    ('fields', 'items(track(id,name))'),
    ('limit', '100'),
)


generi = ["HEAVYMETAL","ACOUSTIC","ROCK","POP","JAZZ","TRAP"]
playlist_id = ["6yIGwQ7pz2lHxGW6tTcnpL","37i9dQZF1DWY8U6Zq7nvbE","0o4sywrnfAQNwJYhfStjEz","1YiL6Vk1GWWbltklCI3rak","1Qo24xMWid1WhoxFoUN18z","2lSMaKr1LruXmunrwANv96"]



#creo csv
csvFile = open('tabella.csv', 'w')
csvWriter = csv.writer(csvFile)
#popularity',
csvWriter.writerow(['Length','Key','Mode','time_signature','Danceability','Acousticness','Energy','liveness','loudness','speechiness','valence','tempo','Genere','Classe'])


totalSongNumber = 600

j =0
i =0
for x in playlist_id:
	response = requests.get('https://api.spotify.com/v1/playlists/'+x+'/tracks', headers=headers, params=params)
	data = response.json()
	
	for song in data['items']:
		#per ogni canzone ottengo i suoi dati
		headers = {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'Authorization': TOKEN,
		}
		print(song['track'].get("id"))

		response2 = requests.get('https://api.spotify.com/v1/audio-features/'+song['track'].get('id'),headers=headers)
		song_data = response2.json()
		csvWriter.writerow([song_data['duration_ms'],song_data['key'],song_data['mode'],song_data['time_signature'],song_data['danceability'],song_data['acousticness'],song_data['energy'],song_data['liveness'],song_data['loudness'],song_data['speechiness'],song_data['valence'],song_data['tempo'],generi[j],j])
		i+=1	
		print("Percentage: "+str(round(i/totalSongNumber*100,2))+"%")
	j += 1
print("File creato")
