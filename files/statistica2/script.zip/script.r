tabella = read.csv("tabella.csv")
tabella = tabella[,-13]
head(tabella)
#valuto i fattori che piu influiscono sulla classe attraverso la correlazione
round(cor(tabella),2)

#proviamo con REGRESSIONE LINEARE LOGISTICA
#trasformo in classificazione binaria
#1 HEAVY METAL contro tutti
for(i in 1:600){
  if(tabella[i,13]==0)
    tabella[i,13]=1
  else
    tabella[i,13]=0
}

tabella.glm = glm(Classe~.,data=tabella,family=binomial)
summary(tabella.glm)
tabella.glm.p=predict(tabella.glm,type="response") 
sum((tabella.glm.p>0.5)==(tabella$Classe>0.5))/length(tabella$Classe) # ottengo un'accuratezza del 92%
source("mr_cmroc.r")
mconfmat(tabella$Classe,tabella.glm.p) 
mconfmat(tabella$Classe,tabella.glm.p,0.4)
sum((tabella.glm.p>0.4)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.3)
sum((tabella.glm.p>0.3)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.2)
sum((tabella.glm.p>0.2)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.1)
sum((tabella.glm.p>0.1)==(tabella$Classe>0.5))/length(tabella$Classe)

#2 ACOUSTIC contro tutti
tabella = read.csv("tabella.csv")
tabella = tabella[,-13]
for(i in 1:600){
  if(tabella[i,13]==1)
    tabella[i,13]=1
  else
    tabella[i,13]=0
}

tabella.glm = glm(Classe~.,data=tabella,family=binomial)
tabella.glm.p=predict(tabella.glm,type="response")
sum((tabella.glm.p>0.5)==(tabella$Classe>0.5))/length(tabella$Classe)#92% -> stessa cosa di prima, ne classifica bene 73 su 100!
mconfmat(tabella$Classe,tabella.glm.p)
mconfmat(tabella$Classe,tabella.glm.p,0.4)
sum((tabella.glm.p>0.4)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.3)
sum((tabella.glm.p>0.3)==(tabella$Classe>0.5))/length(tabella$Classe) #migliore soglia 0.3

#3 ROCK contro tutti
tabella = read.csv("tabella.csv")
tabella = tabella[,-13]
for(i in 1:600){
  if(tabella[i,13]==2)
    tabella[i,13]=1
  else
    tabella[i,13]=0
}

tabella.glm = glm(Classe~.,data=tabella,family=binomial)
tabella.glm.p=predict(tabella.glm,type="response")
sum((tabella.glm.p>0.5)==(tabella$Classe>0.5))/length(tabella$Classe)#88% 
mconfmat(tabella$Classe,tabella.glm.p)
# indovino solo 50 su 100 della classe rock 
mconfmat(tabella$Classe,tabella.glm.p,0.4)
sum((tabella.glm.p>0.4)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.3)
sum((tabella.glm.p>0.3)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.2)
sum((tabella.glm.p>0.2)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.25)
sum((tabella.glm.p>0.25)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.1)
sum((tabella.glm.p>0.1)==(tabella$Classe>0.5))/length(tabella$Classe)
#migliore soglia 0.25 

#4 POP contro tutti
tabella = read.csv("tabella.csv")
tabella = tabella[,-13]
for(i in 1:600){
  if(tabella[i,13]==3)
    tabella[i,13]=1
  else
    tabella[i,13]=0
}

tabella.glm = glm(Classe~.,data=tabella,family=binomial)
tabella.glm.p=predict(tabella.glm,type="response")
sum((tabella.glm.p>0.5)==(tabella$Classe>0.5))/length(tabella$Classe) #86%
mconfmat(tabella$Classe,tabella.glm.p) #ne classifica bene troppe poche del pop -> solo 33 su 100!
mconfmat(tabella$Classe,tabella.glm.p,0.4)
sum((tabella.glm.p>0.4)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.3)
sum((tabella.glm.p>0.3)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.2)
sum((tabella.glm.p>0.2)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.1)
sum((tabella.glm.p>0.1)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.25)#migliore soglia -> ne classifica bene 68 su 100 
sum((tabella.glm.p>0.25)==(tabella$Classe>0.5))/length(tabella$Classe)#81% di accuratezza


#5 JAZZ contro tutti
tabella = read.csv("tabella.csv")
tabella = tabella[,-13]
for(i in 1:600){
  if(tabella[i,13]==4)
    tabella[i,13]=1
  else
    tabella[i,13]=0
}

tabella.glm = glm(Classe~.,data=tabella,family=binomial)
tabella.glm.p=predict(tabella.glm,type="response")
sum((tabella.glm.p>0.5)==(tabella$Classe>0.5))/length(tabella$Classe) #89%
mconfmat(tabella$Classe,tabella.glm.p) #ne classifica bene troppe poche -> solo 55 su 100!
mconfmat(tabella$Classe,tabella.glm.p,0.4)
sum((tabella.glm.p>0.4)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.3)
sum((tabella.glm.p>0.3)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.2)
#soglia migliore 0.2
sum((tabella.glm.p>0.2)==(tabella$Classe>0.5))/length(tabella$Classe)#84% accuratezza


#6 TRAP contro tutti
tabella = read.csv("tabella.csv")
tabella = tabella[,-13]
for(i in 1:600){
  if(tabella[i,13]==5)
    tabella[i,13]=1
  else
    tabella[i,13]=0
}

tabella.glm = glm(Classe~.,data=tabella,family=binomial)
tabella.glm.p=predict(tabella.glm,type="response")
sum((tabella.glm.p>0.5)==(tabella$Classe>0.5))/length(tabella$Classe) #93%
mconfmat(tabella$Classe,tabella.glm.p) #ne classifica bene 73 su 100
mconfmat(tabella$Classe,tabella.glm.p,0.4)
sum((tabella.glm.p>0.4)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.3)
sum((tabella.glm.p>0.3)==(tabella$Classe>0.5))/length(tabella$Classe)
mconfmat(tabella$Classe,tabella.glm.p,0.2)
sum((tabella.glm.p>0.2)==(tabella$Classe>0.5))/length(tabella$Classe)
#migliore soglia 0.3, con accuratezza di 92%


#ANALISI DISCRIMINANTE
library(MASS)
tabella = read.csv("tabella.csv")
tabella = tabella[,-14]
tabella.lda = lda(Genere~.,data=tabella,prior=c(1/6,1/6,1/6,1/6,1/6,1/6))
tabella.lda.p = predict(tabella.lda)
sum((tabella.lda.p$class)==(tabella$Genere))/length(tabella$Genere)


#rappresentazione del risultato
plot(tabella.lda.p$x,pch=16,col=as.numeric(tabella$Genere)+8)


tabella.pca=princomp(subset(tabella,select=-Genere))
tabella.pca.pt=predict(tabella.pca)
plot(tabella.pca.pt,col=as.numeric(tabella$Genere)+8,pch=19)


#CONFRONTO MODELLI

library(MASS)
tabella = read.csv("tabella.csv")

set.seed(54485)
numeroDiProve =30
accuratezzaGlm=rep(0,numeroDiProve)
accuratezzaLda=rep(0,numeroDiProve)

sampleNumber = 60
l=nrow(tabella)

for(j in 1:30){
  
  idx=sample(l,sampleNumber)
  trainingSet=tabella[-idx,]
  testSet=tabella[idx,]
  
  
  #costruisco i vari modelli della regressione logistica
  trainingSet2 = trainingSet
  trainingSet2=trainingSet2[,-13]
  for(i in 1:540){
    if(trainingSet2[i,13]==0)
      trainingSet2[i,13]=1
    else
      trainingSet2[i,13]=0
  }
  tabella.glmHeavyMetal = glm(Classe~.,data=trainingSet2,family=binomial)
  tabella.glm.pHeavyMetal=predict(tabella.glmHeavyMetal,newdata=testSet,type="response")
  
  
  trainingSet2 = trainingSet
  trainingSet2=trainingSet2[,-13]
  for(i in 1:540){
    if(trainingSet2[i,13]==1)
      trainingSet2[i,13]=1
    else
      trainingSet2[i,13]=0
  }
  tabella.glmAcoustic = glm(Classe~.,data=trainingSet2,family=binomial)
  tabella.glm.pAcoustic=predict(tabella.glmAcoustic,newdata=testSet,type="response") 
  
  
  
  trainingSet2 = trainingSet
  trainingSet2=trainingSet2[,-13]
  for(i in 1:540){
    if(trainingSet2[i,13]==2)
      trainingSet2[i,13]=1
    else
      trainingSet2[i,13]=0
  }
  tabella.glmRock = glm(Classe~.,data=trainingSet2,family=binomial)
  tabella.glm.pRock=predict(tabella.glmRock,newdata=testSet,type="response") 
  
  
  
  trainingSet2 = trainingSet
  trainingSet2=trainingSet2[,-13]
  for(i in 1:540){
    if(trainingSet2[i,13]==3)
      trainingSet2[i,13]=1
    else
      trainingSet2[i,13]=0
  }
  tabella.glmPop = glm(Classe~.,data=trainingSet2,family=binomial)
  tabella.glm.pPop=predict(tabella.glmPop,newdata=testSet,type="response") 
  
  
  
  trainingSet2 = trainingSet
  trainingSet2=trainingSet2[,-13]
  for(i in 1:540){
    if(trainingSet2[i,13]==4)
      trainingSet2[i,13]=1
    else
      trainingSet2[i,13]=0
  }
  tabella.glmJazz = glm(Classe~.,data=trainingSet2,family=binomial)
  tabella.glm.pJazz=predict(tabella.glmJazz,newdata=testSet,type="response") 
  
  
  
  trainingSet2 = trainingSet
  trainingSet2=trainingSet2[,-13]
  for(i in 1:540){
    if(trainingSet2[i,13]==5)
      trainingSet2[i,13]=1
    else
      trainingSet2[i,13]=0
  }
  tabella.glmTrap = glm(Classe~.,data=trainingSet2,family=binomial)
  tabella.glm.pTrap=predict(tabella.glmTrap,newdata=testSet,type="response") 
  
  
  matriceProbabilita = cbind(tabella.glm.pHeavyMetal,tabella.glm.pAcoustic,tabella.glm.pRock,
                             tabella.glm.pPop,tabella.glm.pJazz,tabella.glm.pJazz)
  vettoreIndiceMassimi = apply(matriceProbabilita, 1, which.max)
  
  matches =0
  for(k in 1:sampleNumber){
    if((vettoreIndiceMassimi[k]-1)==testSet[k,14])
      matches = matches+1
  }
  accuratezzaGlm[j] = matches/sampleNumber
  
  
  
  testSet=testSet[,-14]
  trainingSet = trainingSet[,-14]
  training.lda = lda(Genere~.,data=trainingSet,CV=F)
  test.pt=predict(training.lda,newdata=testSet)$class
  accuratezzaLda[j] = sum(test.pt==tabella$Genere[idx])/sampleNumber
}

mean(accuratezzaLda)
sd(accuratezzaLda)
mean(accuratezzaGlm)
sd(accuratezzaGlm)




